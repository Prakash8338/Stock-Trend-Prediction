import pandas as pd
feedback_data = pd.read_csv("feedback_data.csv")
