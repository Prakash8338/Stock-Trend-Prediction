import os
import sys
import pandas as pd
from typing import List
import openai
import os
import requests
import urllib3
import ssl
import json
import re
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
import httpx
from langchain_core.caches import BaseCache 
from langchain_core.callbacks import Callbacks 
from langgraph.graph import StateGraph, END
from dotenv import load_dotenv

load_dotenv()
os.environ["OPENAI_API_KEY"] = os.getenv("OPENAI_API_KEY")
httpx_client = httpx.Client(http2=True, verify=False)
MODEL = "gpt-4o"

def generate_text(df: pd.DataFrame, prompt: str, model: str = "gpt-4o", openai_api_key=None):
    # Prepare test set
    eval_df = pd.DataFrame(columns=["Data Format", "Data raw"])
    data_json = df.to_json(orient='records')
    eval_df.loc[len(eval_df)] = ["JSON", data_json]
    input_prompt = prompt

    def response_test(question: str, context: str, model: str = "gpt-4o"):
        # Use LangChain's ChatOpenAI wrapper
        ChatOpenAI.model_rebuild(_types_namespace={'BaseCache': BaseCache, 'Callbacks': Callbacks})
        llm = ChatOpenAI(model=model, http_client=httpx_client)
        messages = [
            SystemMessage(content=context),
            HumanMessage(content=question)
        ]
        response = llm(messages)
        content = response.content
        content = content.strip('\n2').replace('Title:','').replace('Insights:','').strip('\n1').strip('\n3').strip('\n4').strip('  ').strip('\t').replace('"','')
        # Clean response (optional, can be tailored)
        #for ch in ['\n1', '\n2', '\n3', '\n4', 'Title:', 'Insights:', '  ', '\t', '"']:
            #content = content.replace(ch, '')
        return content.strip()

    def run_question_test(query: str, eval_df: pd.DataFrame):
        eval_df_str = eval_df.to_string()
        response = response_test(query, eval_df_str, model=model)
        return response
    result_df1 = run_question_test(input_prompt, eval_df.copy())
    insights_list = []
    insights_list = result_df1.split('\n')
    insights_list = [insights for insights in insights_list if insights.strip()]
    insights_list = [insights for insights in insights_list if insights not in ('  ')]
    print('Answer_list: ', insights_list)
    return insights_list


