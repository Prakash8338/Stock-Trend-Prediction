def get_review_prompt(column_data,summary,slide_number):
    if slide_number == 1: 
        slide_1_review_prompt = f"""
        You are a financial data analysis expert. Your task is to strictly review the following generated summary of financial data to ensure it complies with all the rules and instructions provided in the prompt below. Carefully check the summary for any of these issues:

        - Any rules from the prompt that were NOT followed.
        - Any formatting, ordering, or instruction errors (see rules).
        - Any incorrect use of metrics, terminology, or comparisons.
        - Any redundant, vague, or generic statements.
        - Any other mistakes or deviations.

        If ANY issue is found, return a specific and actionable feedback message listing the problem(s) found (e.g. "Rule 8 violated: decimal values not converted to percentages", "Rule 5: Issuer Name mentioned"). If multiple violations, enumerate them clearly. Return every issue seperately in new line. Do not combine two rules violation together.
 
        If the summary is fully correct and follows ALL rules strictly, reply with only: "OK".

        PROMPT:
        -----------------
        Make use of the field definitions from field_context provided below while generating title and insights.
        In the field_context, we have given meaning to each term. Try to understand the significance of it and generate title and insights according to that.
        Look on the value significance of field details carefully as some field having higher value signifies lower performance and high security measures for example fraud rates.

        <field_context>
        {column_data}
        </field_context>

        1.While summarizing, multiply decimal values by 100 to make it in percent form(e.g., 0.09 becomes 9%). Do not multiply by 1000 and show the value in percent form only and percent can have negative values also.
        2.Summarize data concisely in complete sentences, using 30 to 40 words.
        3.Ensure each insight is meaningful and adds value.
        4.Limit the title to 10 words, avoiding peer-related storylines.
        5.Use relevant finance jargon for the title, reflecting the data content.
        6.Do not mention "Insights" before insight lines.
        7.Be specific about metrics or trends, avoiding generic terms.
        8.For each insight, always attach numerical data for the better exaplanation.
        9.Please refer to field context above to get an idea about fields. Some fields may have higher value but it do not signify higher performance.
        10.Do not confuse by higher value of a field to be better performance, look at field context above to get better understanding and give accurate insights.
        11.The disengagement cardholders in slide 1 means what is the impact of disengaged cardholders on the spend, if this is more negative then it has a bad impact.
        12.Do not show decimal value instead multiply it by 100 and show it in percent form.
         
        -----------------
        SUMMARY TO REVIEW:
        -----------------
        {summary}
        -----------------
        """

        #Utilize finance vocabulary for precise insights.
        #Avoid vague sentences; start with specific observations.
        #Provide clear, concise analysis for each data point.
        #Less fraud is better and show's positive trend.
        #Always keep in mind to generate title and insight according to above rules.

        return slide_1_review_prompt
    elif slide_number == 2:
        slide_2_review_prompt = f"""
        You are a financial data analysis expert. Your task is to strictly review the following generated summary of financial data to ensure it complies with all the rules and instructions provided in the prompt below. Carefully check the summary for any of these issues:

        - Any rules from the prompt that were NOT followed.
        - Any formatting, ordering, or instruction errors (see rules).
        - Any incorrect use of metrics, terminology, or comparisons.
        - Any redundant, vague, or generic statements.
        - Any other mistakes or deviations.

        If ANY issue is found, return a specific and actionable feedback message listing the problem(s) found (e.g. "Rule 8 violated: decimal values not converted to percentages", "Rule 5: Issuer Name mentioned"). If multiple violations, enumerate them clearly.

        If the summary is fully correct and follows ALL rules strictly, reply with only: "OK".

        PROMPT:
        -----------------
        Make use of the field definitions from field_context provided below while generating title and insights.
        In the field_context, we have given meaning to each term. Try to understand the significance of it and generate title and insights according to that.
        Look on the value significance of field details carefully as some field having higher value signifies lower performance and high security measures for example fraud rates.

        <field_context>
        {column_data}
        </field_context>

        1.While summarizing, multiply decimal values by 100 to make it in percent form(e.g., 0.09 becomes 9%). Do not multiply by 1000 and show the value in percent form only and percent can have negative values also.
        2.Summarize data concisely in complete sentences, using 30 to 40 words.
        3.Ensure each insight is meaningful and adds value.
        4.Limit the title to 10 words, avoiding peer-related storylines.
        5.Use relevant finance jargon for the title, reflecting the data content.
        6.Do not mention "Insights" before insight lines.
        7.Be specific about metrics or trends, avoiding generic terms.
        8.Correct any misinterpretations of issuer vs. peer performance.
        9.For each insight, always attach numerical data for the better exaplanation.
        10.Please refer to field context above to get an idea about fields. Some fields may have higher value but it do not signify higher performance.
        11.Do not confuse by higher value of a field to be better performance, look at field context above to get better understanding and give accurate insights.
        12.Do not show decimal value instead multiply it by 100 and show it in percent form.
        13.Impact on Spend from Cardholder Disengagement in slide 2 means what is the impact of disengaged cardholders on the spend, if this is negative percentage then it has a good impact.
        14.The negative impact on spend from cardholder disengagement is high at 22%, despite a decrease from the previous period by 6%. Here for previous year the value was -16% for issuer and in current year it's -22% this is bad sign as impact on spend has increased from previous year.
         
        -----------------
        SUMMARY TO REVIEW:
        -----------------
        {summary}
        -----------------
        """

        #Utilize finance vocabulary for precise insights.
        #Avoid vague sentences; start with specific observations.
        #Provide clear, concise analysis for each data point.
        #Less fraud is better and show's positive trend.
        #Always keep in mind to generate title and insight according to above rules.

        return slide_2_review_prompt
    elif slide_number == 3: 
        slide_3_review_prompt = f"""
        You are a financial data analysis expert. Your task is to strictly review the following generated summary of financial data to ensure it complies with all the rules and instructions provided in the prompt below. Carefully check the summary for any of these issues:

        - Any rules from the prompt that were NOT followed.
        - Any formatting, ordering, or instruction errors (see rules).
        - Any incorrect use of metrics, terminology, or comparisons.
        - Any redundant, vague, or generic statements.
        - Any other mistakes or deviations.

        If ANY issue is found, return a specific and actionable feedback message listing the problem(s) found (e.g. "Rule 8 violated: decimal values not converted to percentages", "Rule 5: Issuer Name mentioned"). If multiple violations, enumerate them clearly.

        If the summary is fully correct and follows ALL rules strictly, reply with only: "OK".

        PROMPT:
        -----------------
        Make use of the field definitions from field_context provided below while generating title and insights.
        In the field_context, we have given meaning to each term. Try to understand the significance of it and generate title and insights according to that.
        Look on the value significance of field details carefully as some field having higher value signifies lower performance and high security measures for example fraud rates.

        <field_context>
        {column_data}
        </field_context>

        1.While summarizing, multiply decimal values by 100 to make it in percent form(e.g., 0.09 becomes 9%). Do not multiply by 1000 and show the value in percent form only and percent can have negative values also.
        2.Summarize data concisely in complete sentences, using 30 to 40 words.
        3.Ensure each insight is meaningful and adds value.
        4.Limit the title to 10 words, avoiding peer-related storylines.
        5.Use relevant finance jargon for the title, reflecting the data content.
        6.Do not mention "Insights" before insight lines.
        7.Be specific about metrics or trends, avoiding generic terms.
        8.For each insight, always attach numerical data for the better exaplanation.
        9.Please refer to field context above to get an idea about fields. Some fields may have higher value but it do not signify higher performance.
        10.Do not confuse by higher value of a field to be better performance, look at field context above to get better understanding and give accurate insights.
        11.Do not show decimal value instead multiply it by 100 and show it in percent form.
        12.In world KPIs, Higher the fraud rate the bad it is, higher fraud rate means that there are more fraud transactions.
         
        -----------------
        SUMMARY TO REVIEW:
        -----------------
        {summary}
        -----------------
        """

        #Utilize finance vocabulary for precise insights.
        #Avoid vague sentences; start with specific observations.
        #Provide clear, concise analysis for each data point.
        #Less fraud is better and show's positive trend.
        #Always keep in mind to generate title and insight according to above rules.

        return slide_3_review_prompt
