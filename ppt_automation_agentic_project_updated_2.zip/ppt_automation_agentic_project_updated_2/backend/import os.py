import pandas as pd 
df = pd.read_csv("issuer_data.csv")
print(df.loc[(df['Peerset'] == 0) & (df['chart_type'] == 'world') & (df['Category'] == 'Apac PV'),'value'])