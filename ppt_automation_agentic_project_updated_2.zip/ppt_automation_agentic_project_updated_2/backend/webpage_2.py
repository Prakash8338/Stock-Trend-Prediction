import streamlit as st
import streamlit.components.v1 as components
import pandas as pd
import numpy as np
import pptx
import zipfile
from pptx import presentation
#from ppt_generator import generate_ppt
#from ppt_generator_v2 import generate_ppt
from ppt_generator import generate_ppt_2
#from ppt_generator_v4 import generate_ppt_2
import os
import base64
from PIL import Image, ImageDraw
#from spire.presentation import *
#from spire.presentation.common import *
import shutil
from pptx import Presentation
from pptx.util import Inches
from PIL import Image, ImageDraw, ImageFont
import io
import matplotlib.pyplot as plt
import cv2
#import win32com.client
import os
#from pdf2image import convert_from_path
import fitz
import subprocess 
# import comtypes.client
# import pythoncom
# pythoncom.CoInitialize()
from column_data import column_data
from prompt import get_prompt
from summary_agent import summary_agent
from ppt_generator import update_slide_insight
from feedback import feedback_data
def ppt_to_pdf(ppt_file):
    pdf_file = ppt_file.replace('.pptx', '.pdf')
    try:
        # Use LibreOffice to convert PPTX to PDF
        subprocess.run([
            "soffice",
            "--headless",
            "--convert-to", "pdf",
            ppt_file,
            "--outdir", os.path.dirname(ppt_file)
        ], check=True)
        return pdf_file
    except Exception as e:
        raise RuntimeError(f"Failed to convert PPT to PDF: {e}")

def pdf_to_images(pdf_file):
    images = []
    document = fitz.open(pdf_file)
    zoom = 1 # Increase for higher resolution (2 = 144 DPI, 3 = 216 DPI, etc.)
    mat = fitz.Matrix(zoom, zoom)
    for page_num in range(len(document)):
        page = document.load_page(page_num)
        pix = page.get_pixmap(matrix=mat)
        img_path = f"page_{page_num + 1}.png"
        pix.save(img_path)
        images.append(img_path)
    document.close()
    return images

def zip_files(folder_path,zip_name):
    with zipfile.ZipFile(zip_name,'w',zipfile.ZIP_DEFLATED) as zipf:
        for root, _,files in os.walk(folder_path):
            for file in files:
                file_path = os.path.join(root,file)
                zipf.write(file_path,os.path.relpath(file_path,folder_path))

def update_feedback_data(slide_key, insight, score):
    """
    Update feedback_data.csv with the latest feedback for a slide.
    If the slide already exists, it will be overwritten.
    """
    # Load existing feedback
    try:
        feedback_df = pd.read_csv("feedback_data.csv")
    except FileNotFoundError:
        feedback_df = pd.DataFrame(columns=['Slide', 'Insight', 'Score'])

    # Add the new feedback
    new_row = {'Slide': slide_key, 'Insight': insight, 'Score': score}
    feedback_df = pd.concat([feedback_df, pd.DataFrame([new_row])], ignore_index=True)

    # Save back to CSV
    feedback_df.to_csv("feedback_data.csv", index=False)

def generate_ppt(slide_images,submitted_feedback, feedback, cnt,ppt_file_up, pdf_file, Merchant_filter, final_dict_up):
    if not submitted_feedback:

        #image_placeholders = [st.empty() for _ in slide_images]

        for i, image_path in enumerate(slide_images):

            with st.container():

                #st.image(image_path, caption=f"Page {i + 1}", width='stretch')
                image_placeholder = st.empty()
                image_placeholder.image(image_path, caption=f"Page {i + 1}", use_column_width=True)

                if i == 0:
                    continue

                else:

                    col1, col2 = st.columns(2)


                    with col1:
                    
                        
                        if st.button("👍", key=f"up_{i}", help="Mark this slide as helpful"):
                            #if f"slide{i}" not in feedback:
                            cnt = cnt + 1
                            print(cnt)
                            feedback[f"slide{i}"] = 1
                            update_feedback_data(f"slide{i}", st.session_state.final_dict_up[f"slide{i}"], 1)              
                    
                    with col2:    
                        if st.button("👎", key=f"down_{i}", help="Mark this slide as not helpful"):
                            #if f"slide{i}" not in feedback:
                            cnt = cnt + 1
                            print(cnt)
                            feedback[f"slide{i}"] = 0
                            update_feedback_data(f"slide{i}", st.session_state.final_dict_up[f"slide{i}"], 0)              
                            # Regenerate PPT, PDF, and images for the selected issuer
                            # df = pd.read_csv("issuer_data.csv")
                            # template = 'auto_code_ppt.pptx'
                            # ppt_file, final_dict = generate_ppt_2(df, Merchant_filter, template)
                            # ppt_file_up = os.path.join(os.getcwd(), 'ppt_files', f'{Merchant_filter}_generated_ppt.pptx')
                            # pdf_file = ppt_to_pdf(os.path.abspath(ppt_file_up))
                            # slide_images = pdf_to_images(pdf_file)
                            # final_dict_up = final_dict
                            # st.session_state.ppt_file_up = ppt_file_up
                            # st.session_state.pdf_file = pdf_file
                            # st.session_state.slide_images = slide_images
                            # st.session_state.final_dict_up = final_dict_up
                            # st.info(f"Content refreshed for Slide {i}. Please review the updated insights.")
                            # Generate new insights for this slide
                            filtered_df = pd.read_csv("issuer_data.csv")
                            filtered_df = filtered_df[(filtered_df['issuer'] == Merchant_filter) & (filtered_df['slide'] == i)]
                            columns = ['Category','Metric','time_period']
                            column_dict = {}
                            for col in columns:
                                v = list(filtered_df[col].unique())
                                for key, value in column_data[col].items():
                                    if key in v:
                                        column_dict[key] = value
                            # slide_feedback = feedback_data.get(f"slide{i}", 0)
                            # feedback_data_up = pd.DataFrame([{"Insight": "", "Score": slide_feedback}]).to_json(orient='records')
                            prompt = get_prompt(str(column_dict) , 3, i)
                            output_list = summary_agent(filtered_df, prompt, i)
                            # Update only the insight/title for this slide in the PPT file
                            update_slide_insight(ppt_file_up, i, output_list)
                            # Optionally, update the image for this slide
                            st.session_state.final_dict_up[f"slide{i}"] = output_list
                            # Re-convert PPT to PDF and update slide image
                            pdf_file = ppt_to_pdf(os.path.abspath(ppt_file_up))
                            slide_images = pdf_to_images(pdf_file)
                            st.session_state.pdf_file = pdf_file
                            st.session_state.slide_images = slide_images
                            #st.info(f"Insight/title refreshed for Slide {i}. Please review the updated content.")
                            #show the updated image for this slide in real time
                            #st.image(slide_images[i], caption=f"Updated Page {i + 1}", width='stretch')
                            image_placeholder.image(slide_images[i], caption=f"Updated Page {i + 1}", use_column_width=True)

            
        if st.button("Submit Feedback"):
            # print(feedback)
            # feedback_data_given = []
            # for key in feedback.keys():
            #     score = feedback[key]
            #     summary = st.session_state.final_dict_up[key]
            #     v = {'Slide': key, 'Insight': summary, 'Score':score}
            #     feedback_data_given.append(v)
            # feedback_df = pd.DataFrame(feedback_data_given)
            # initial_feedback_data = pd.read_csv("feedback_data.csv")
            # feedback_data_combine = pd.concat([initial_feedback_data,feedback_df], axis = 0)
            # feedback_data_combine_up = feedback_data_combine.reset_index(drop=True)
            # feedback_data_combine_up.to_csv("feedback_data.csv", index=False)
            # st.write("Feedback received:")
            submitted_feedback = True
            if st.success('Powerpoint Generated Successfully'):
                st.download_button(label='Download Powerpoint Presentation', data=open(ppt_file_up, 'rb').read(), file_name=f"{Merchant_filter}_Generated_ppt.pptx")
                os.remove(ppt_file_up)
                os.remove(pdf_file)
                st.session_state.ppt_generated = True

    return submitted_feedback,feedback,cnt
        
def main():
    if 'ppt_generated' not in st.session_state:
        st.session_state.ppt_generated = False

    if 'submitted_feedback' not in st.session_state:
        st.session_state.submitted_feedback = True

    
    st.title('Automated Powerpoint Generator Demo with GenAI Insights')
    st.subheader('Developed by EXL')
    df = pd.read_csv("issuer_data.csv")
    template = 'auto_code_ppt.pptx'
    st.sidebar.title("Options")
    st.sidebar.subheader('Filter Options')
    Merchant_options = df['issuer'].unique().tolist()
    Merchant_filter = st.sidebar.selectbox('Select Issuer:',Merchant_options)
    st.sidebar.title('Search Option')
    search_query = st.sidebar.text_input("Enter the issuer name")
    if search_query:
        st.write(f'Search Results for "{search_query}": ')
        issuer = [word for word in Merchant_options if search_query.lower() in word.lower()]
        st.write('Search results:')
        for result in issuer:
            if st.button(result):
                issuer = st.empty()
                st.write(f"You Selected: {result}")
                st.success("Generating the Power Point Presentation...")
                Merchant_filter = result
                generate_ppt(df,Merchant_filter,template)
    st.sidebar.subheader("Customized Options")  
    st.sidebar.warning("Custom template should have same shape names as default template")
    input_template = st.sidebar.file_uploader("Upload different Template", type = ["pptx"])
    st.sidebar.download_button(label = 'Download Default Template', data = open(template,'rb').read(),file_name = f"template_ppt.pptx")
    if input_template:
        template = input_template
    if st.session_state.ppt_generated:
        # Feedback buttons
        st.subheader("Insights Feedback")  # Heading above the buttons
        col1, col2 = st.columns(2)
        with col1:
            if st.button("👍"):
                st.success("Thank you for your feedback! 👍")
                st.session_state.ppt_generated = False  # Reset after feedback
        with col2:
            if st.button("👎"):
                st.error("We're sorry to hear that. 👎")
                st.session_state.ppt_generated = False  # Reset after feedback
    if st.button('Download Powerpoint Presentation for all Issuers'):
        with st.spinner("Creating PPTs and zipping...."):
            output_dir = "ppt_files"
            if not os.path.exists(output_dir):
                os.makedirs(output_dir)
            for Merchant_filter in Merchant_options:
                generate_ppt(df,Merchant_filter,template)
            zip_name= "All_Merchants_Presentations.zip" 
            zip_files(output_dir,zip_name)
            with open(zip_name,"rb") as f:
                st.download_button("Download ZIP",f,file_name = zip_name)
            print('Removing')
            shutil.rmtree(output_dir)
            os.remove(zip_name)
    if st.button('Generate Power Point Presentation for a Single Issuer'):
        st.empty()
        ppt_file, final_dict = generate_ppt_2(df, Merchant_filter, template)

        st.session_state.ppt_file_up = os.path.join(
        os.getcwd(),
        'ppt_files',
        f'{Merchant_filter}_generated_ppt.pptx'
     )

        st.session_state.final_dict_up = final_dict
   
        st.session_state.pdf_file = ppt_to_pdf(os.path.abspath(st.session_state.ppt_file_up))

        st.session_state.slide_images = pdf_to_images(st.session_state.pdf_file)

        
        st.session_state.submitted_feedback = False


        st.session_state.feedback = {}  # Store feedback for each slide
        st.session_state.cnt = 0

        st.session_state.key1 = 0



        
                    
                    




        

    if not st.session_state.submitted_feedback:
        st.session_state.submitted_feedback, st.session_state.feedback,  st.session_state.cnt = generate_ppt(st.session_state.slide_images,st.session_state.submitted_feedback,st.session_state.feedback,st.session_state.cnt,st.session_state.ppt_file_up,st.session_state.pdf_file, Merchant_filter, st.session_state.final_dict_up)
    
    if st.sidebar.button('Regenerate'):
        st.rerun()
if __name__ == '__main__':
    main()