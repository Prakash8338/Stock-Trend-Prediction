from flask import Blueprint, jsonify

bp = Blueprint('issuers', __name__, url_prefix='/api/issuers')


@bp.route('', methods=['GET'])
def get_issuers():
    """Get list of all available issuers"""
    issuers = [
        {'id': 1, 'name': 'Bank of America', 'code': 'BOA'},
        {'id': 2, 'name': 'Navy Federal Credit Union', 'code': 'NFCU'},
    ]
    return jsonify(issuers), 200


@bp.route('/<int:issuer_id>', methods=['GET'])
def get_issuer(issuer_id):
    """Get specific issuer details"""
    issuers = {
        1: {'id': 1, 'name': 'Bank of America', 'code': 'BOA', 'details': 'Bank of America fraud detection report'},
        2: {'id': 2, 'name': 'Navy Federal Credit Union', 'code': 'NFCU', 'details': 'Navy Federal Credit Union fraud detection report'},
    }
    
    issuer = issuers.get(issuer_id)
    if not issuer:
        return jsonify({'error': 'Issuer not found'}), 404
    
    return jsonify(issuer), 200
