import streamlit as st
import streamlit.components.v1 as components
import pandas as pd
import numpy as np
import pptx
import zipfile
from pptx import presentation
#from ppt_generator import generate_ppt
#from ppt_generator_v2 import generate_ppt
from ppt_generator import generate_ppt_2
#from ppt_generator_v4 import generate_ppt_2
import os
import base64
from PIL import Image, ImageDraw
#from spire.presentation import *
#from spire.presentation.common import *
import shutil
from pptx import Presentation
from pptx.util import Inches
from PIL import Image, ImageDraw, ImageFont
import io
import matplotlib.pyplot as plt
import cv2
def convert_slide_to_image(slide):
    padding = 20  # Padding around text and images
    shapes = []

    # Gather all shapes and their dimensions
    for shape in slide.shapes:
        if shape.has_text_frame:
            text_width, text_height = get_text_size(shape.text)
            shapes.append({
                'type': 'text',
                'text': shape.text,
                'left': shape.left.pt,
                'top': shape.top.pt,
                'width': text_width,
                'height': text_height
            })
        elif shape.shape_type == 13:  # Picture
            img_stream = io.BytesIO(shape.image.blob)
            image = Image.open(img_stream)
            shapes.append({
                'type': 'image',
                'image': image,
                'left': shape.left.pt,
                'top': shape.top.pt,
                'width': image.width,
                'height': image.height
            })

    # Calculate canvas size
    max_width = max(shape['left'] + shape.get('width', 0) + padding for shape in shapes) + padding
    max_height = max(shape['top'] + shape.get('height', 0) + padding for shape in shapes) + padding + 100  # Extra height for better layout

    # Create a blank image
    img = Image.new('RGB', (int(max_width), int(max_height)), color='white')
    draw = ImageDraw.Draw(img)

    # Load font
    try:
        font = ImageFont.truetype("arial.ttf", 24)
    except IOError:
        font = ImageFont.load_default()

    # Draw shapes onto the image
    for shape in shapes:
        if shape['type'] == 'text':
            x = int(shape['left']) + padding // 2
            y = int(shape['top']) + padding // 2
            draw.text((x, y), shape['text'], fill='black', font=font)
        elif shape['type'] == 'image':
            img_left = int(shape['left']) + padding // 2
            img_top = int(shape['top']) + padding // 2

            # Maintain aspect ratio while resizing
            aspect_ratio = shape['image'].height / shape['image'].width
            new_width = min(shape['width'], max_width - img_left - padding)
            new_height = int(new_width * aspect_ratio)
            shape['image'] = shape['image'].resize((new_width, new_height), Image.LANCZOS)
            img.paste(shape['image'], (img_left, img_top))

    return img

def get_text_size(text):
    # Measure the text size
    dummy_image = Image.new('RGB', (1, 1))
    draw = ImageDraw.Draw(dummy_image)
    try:
        font = ImageFont.truetype("arial.ttf", 24)
    except IOError:
        font = ImageFont.load_default()
    text_bbox = draw.textbbox((0, 0), text, font=font)
    width = text_bbox[2] - text_bbox[0]
    height = text_bbox[3] - text_bbox[1]
    return width, height

def load_presentation(file_path):
    prs = Presentation(file_path)
    slide_images = []

    for slide in prs.slides:
        img = convert_slide_to_image(slide)
        slide_images.append(img)

    return slide_images

def zip_files(folder_path,zip_name):
    with zipfile.ZipFile(zip_name,'w',zipfile.ZIP_DEFLATED) as zipf:
        for root, _,files in os.walk(folder_path):
            for file in files:
                file_path = os.path.join(root,file)
                zipf.write(file_path,os.path.relpath(file_path,folder_path))



def generate_ppt(df, Merchant_filter, template):
    st.empty()
    ppt_file = generate_ppt_2(df, Merchant_filter, template)

    slide_images = load_presentation(ppt_file)

    if slide_images:
        feedback = {}
        for idx, image in enumerate(slide_images):
            # Convert the image to bytes for Streamlit
            img_byte_arr = io.BytesIO()
            image.save(img_byte_arr, format='PNG')
            img_byte_arr.seek(0)

            # Display the image
            st.image(img_byte_arr, caption=f"Slide {idx + 1}", use_column_width=True)
            
            # Create columns for feedback buttons
            col1, col2 = st.columns(2)
            with col1:
                if st.button("👍", key=f"up_{idx}"):
                    feedback[f"Slide {idx + 1}"] = "Thumbs Up"
            with col2:
                if st.button("👎", key=f"down_{idx}"):
                    feedback[f"Slide {idx + 1}"] = "Thumbs Down"
        
        # Button to submit feedback
        if st.button("Submit Feedback"):
            st.write("Feedback received:")
            for slide, value in feedback.items():
                st.write(f"{slide}: {value}")

    
    if st.success('Powerpoint Generated Successfully'):
        st.download_button(label='Download Powerpoint Presentation', data=open(ppt_file, 'rb').read(), file_name=f"{Merchant_filter}_Generated_ppt.pptx")
        os.remove(ppt_file)

        # Set a flag in session state
        st.session_state.ppt_generated = True
def main():
    if 'ppt_generated' not in st.session_state:
        st.session_state.ppt_generated = False
    st.title('Automated Powerpoint Generator Demo with GenAI Insights')
    st.subheader('Developed by EXL')
    df = pd.read_csv("issuer_data.csv")
    template = 'auto_code_ppt.pptx'
    st.sidebar.title("Options")
    st.sidebar.subheader('Filter Options')
    Merchant_options = df['issuer'].unique().tolist()
    Merchant_filter = st.sidebar.selectbox('Select Issuer:',Merchant_options)
    st.sidebar.title('Search Option')
    search_query = st.sidebar.text_input("Enter the issuer name")
    if search_query:
        st.write(f'Search Results for "{search_query}": ')
        issuer = [word for word in Merchant_options if search_query.lower() in word.lower()]
        st.write('Search results:')
        for result in issuer:
            if st.button(result):
                issuer = st.empty()
                st.write(f"You Selected: {result}")
                st.success("Generating the Power Point Presentation...")
                Merchant_filter = result
                generate_ppt(df,Merchant_filter,template)
    st.sidebar.subheader("Customized Options")  
    st.sidebar.warning("Custom template should have same shape names as default template")
    input_template = st.sidebar.file_uploader("Upload different Template", type = ["pptx"])
    st.sidebar.download_button(label = 'Download Default Template', data = open(template,'rb').read(),file_name = f"template_ppt.pptx")
    if input_template:
        template = input_template
    if st.session_state.ppt_generated:
        # Feedback buttons
        st.subheader("Insights Feedback")  # Heading above the buttons
        col1, col2 = st.columns(2)
        with col1:
            if st.button("👍"):
                st.success("Thank you for your feedback! 👍")
                st.session_state.ppt_generated = False  # Reset after feedback
        with col2:
            if st.button("👎"):
                st.error("We're sorry to hear that. 👎")
                st.session_state.ppt_generated = False  # Reset after feedback
    if st.button('Download Powerpoint Presentation for all Issuers'):
        with st.spinner("Creating PPTs and zipping...."):
            output_dir = "ppt_files"
            if not os.path.exists(output_dir):
                os.makedirs(output_dir)
            for Merchant_filter in Merchant_options:
                generate_ppt(df,Merchant_filter,template)
            zip_name= "All_Merchants_Presentations.zip" 
            zip_files(output_dir,zip_name)
            with open(zip_name,"rb") as f:
                st.download_button("Download ZIP",f,file_name = zip_name)
            print('Removing')
            shutil.rmtree(output_dir)
            os.remove(zip_name)
    if st.button('Generate Power Point Presentation for a Single Issuer'):
        generate_ppt(df,Merchant_filter,template)
    if st.sidebar.button('Regenerate'):
        st.rerun()
if __name__ == '__main__':
    main()