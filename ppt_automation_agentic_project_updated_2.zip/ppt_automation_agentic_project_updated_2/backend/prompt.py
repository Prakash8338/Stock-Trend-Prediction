def get_prompt(column_data,no_of_insights,slide_number):
    if slide_number == 1: 
        slide_1_prompt = f"""
        Examine the financial performance data and suggest a title that best represents the financial health and trends and generate insights by following below rules. 

        Make use of the field definitions from field_context provided below while generating title and insights.
        In the field_context, we have given meaning to each term. Try to understand the significance of it and generate title and insights according to that.
        Look on the value significance of field details carefully as some field having higher value signifies lower performance and high security measures for example fraud rates.

        <field_context>
        {column_data}
        </field_context>

        Please analyze the data and generate a {no_of_insights} insights based on the given rules:
        Rules:
        1. Examine the Bank's Consumer Debit Cardholders data in the dataframe. Suggest a title that best represents the financial health and main trends..
        2. Always keep the title first and then the rest insights should follow.
        3. Generate {no_of_insights} insights of at least 30 to maximum 35 words each.
        4. Dont use Issuer Name in the points, compare issuer vs issuer or issuer vs peers numbers and generate insights based on available metric data.
        5. For rows where `Peerset` equals 0, these values belong to the issuer.
        6. For rows where `Peerset` equals 1, these values belong to the peers.
        7. The slide 1 is Spend Growth Metrics.
        8. Summarize the data and provide numerical data points all under 30 to 40 words and it should be verbal and complete sentance.
        9. While summarizing multiply the decimal values with 100 like 0.09 will become 0.09*100 = 9%.
        10. If peers data is not present for that category then dont compare and generate insight for that category.
        11. Use Metric names not categories if required.
        12. Use finance vocabulary to provide precise insights.
        13. Avoid vague sentences; start with specific observations.
        14. Provide clear and concise analysis for each data point.
        15. Each insight should be meaningful and add value to the overall analysis.
        16. there are few categories Issuer, which means issuer data for the Metrics, similarly Peers and difference which means difference between issuer's metrics and peer's metrics
        17. Dont show Issuer or peers Metric = '22 Q1-22 Q4', but compare 22 Q1-22 Q4 and 23 Q3-23 Q4 numbers and tell the growth like issuer grew by 7% from last year.
        18. Order the {no_of_insights} insights with most relevant at the top or most positive growth point at the top,
            you can also use issuer and peers difference or delta to decide the order for example biggest difference or delta comes first.
        19. Title can be a maximum of 10 words.
        20. Dont use Insights word before the insights lines.
        21. Use finance-related jargon relevant to the data.
        22. Title should not contain peers storyline.
        23. Avoid using generic terms; be specific about the metrics or trends.
        24. The title should use relevant finance jargon.
        25. The title should clearly reflect the data content.
        26. Highlight the time period and the main subject (e.g., "Cardholder Metrics", "Growth Analysis").
        27. Dont mention 100% in slide 1 insights, instead of this you can mention compared to previous year.
        28. Keep the title at the 0th index: Title: "Title content".
        29. The output format should be: Title: "Title content", followed by insights as '1. generated insights', '2. generated insights', etc.
        Mistakes - 
        1. In new active cardholders, the issuer gained 0.19%, while for peers, the gain was 0.2%. - Here 0.19% should be 19%.
        2. Issuer gained 1.0% in 22 Q1-22 Q4, and 1.06% in 23 Q3-23 Q4. Peers gained 1.07% in 23 Q3-23 Q4 - here it should be issuer gained by 6% from previous year while peers gained 7%.
        3. The disengagement cardholders in slide 1 means what is the impact of disengaged cardholders on the spend, if this is more negative then it has a bad impact.
        Error Cleaning- 
        1. Removes the extra lines and tabs and one insight should come in one line with out leaving any lines blank.
        2. Remove word "Title" in title line and dont use 1. or 2. in title line.
        3. Remove any words Attached to insights like "Insights:", "-".
        4. Title should not be in double quotes.

        Stricktly follow the Rules and Generate the title and insights based on these rules, and do not make the above miskates and perform the error cleaning.

        """
        return slide_1_prompt
    elif slide_number == 2:
        slide_2_prompt= f"""
        Examine the financial performance data and suggest a title that best represents the financial health and trends and generate insights by following below rules. 

        Make use of the field definitions from field_context provided below while generating title and insights.
        In the field_context, we have given meaning to each term. Try to understand the significance of it and generate title and insights according to that.
        Look on the value significance of field details carefully as some field having higher value signifies lower performance and high security measures for example fraud rates.

        <field_context>
        {column_data}
        </field_context>

        Please analyze the data and generate a {no_of_insights} insights based on the given rules:
        Rules:
        1. Examine the Bank's Consumer Debit Cardholders data in the dataframe. Suggest a title that best represents the financial health and main trends..
        2. Always keep the title first and then the rest insights should follow.
        3. Generate {no_of_insights} insights of at least 30 to maximum 35 words each.
        4. Dont use Issuer Name in the points, compare issuer vs issuer or issuer vs peers numbers and generate insights based on available metric data.
        5. For rows where `Peerset` equals 0, these values belong to the issuer.
        6. For rows where `Peerset` equals 1, these values belong to the peers.
        7. Summarize the data and provide numerical data points all under 30 to 40 words and it should be verbal and complete sentance.
        8. While summarizing multiply the decimal values with 100 like 0.09 will become 0.09*100 = 9%.
        9. If peers data is not present for that category then dont compare and generate insight for that category.
        10. Use Metric names not categories if required.
        11. Use finance vocabulary to provide precise insights.
        12. Avoid vague sentences; start with specific observations.
        13. Provide clear and concise analysis for each data point.
        14. Each insight should be meaningful and add value to the overall analysis.
        15. there are few categories Issuer, which means issuer data for the Metrics, similarly Peers and difference which means difference between issuer's metrics and peer's metrics
        16. Order the {no_of_insights} insights with most relevant at the top or most positive growth point at the top,
            you can also use issuer and peers difference or delta to decide the order for example biggest difference or delta comes first.
        17. Title can be a maximum of 10 words.
        18. Dont use Insights word before the insights lines.
        19. Use finance-related jargon relevant to the data.
        20. Title should not contain peers storyline.
        21. Avoid using generic terms; be specific about the metrics or trends.
        22. The title should use relevant finance jargon.
        23. The title should clearly reflect the data content.
        24. Impact on Spend from Cardholder Disengagement in slide 2 means what is the impact of disengaged cardholders on the spend, if this is negative percentage then it has a bad impact, the more the negative percentage the more bad impact.
        25. Keep the title at the 0th index: Title: "Title content".
        26. The output format should be: Title: "Title content", followed by insights as '1. generated insights', '2. generated insights', etc.
        Mistakes -
        1. There has been a 5,990 card increase in the "Cards with at least 1 Authorization Decline", hinting a potential downfall in transaction processing efficiency. Here the 5990 is the difference between peers and issuer.
        2. The percentage of the portfolio at risk of disengagement has dropped by 1%, indicating improved cardholder retention. here The 1% is the difference between issuer and peers. 
        3. Impact on Spend from Cardholder Disengagement in slide 2 means what is the impact of disengaged cardholders on the spend, if this is negative percentage then it has a good impact.
        4. The negative impact on spend from cardholder disengagement is high at 22%, despite a decrease from the previous period by 6%. Here for previous year the value was -16% for issuer and in current year it's -22% this is bad sign as impact on spend has increased from previous year. 
        Error Cleaning- 
        1. Removes the extra lines and tabs and one insight should come in one line with out leaving any lines blank.
        2. Remove word "Title" in title line and dont use 1. or 2. in title line.
        3. Remove any words Attached to insights like "Insights:", "-".
        4. Title should not be in double quotes.

        Stricktly follow the Rules and Generate the title and insights based on these rules, and do not make the above miskates and perform the error cleaning.

        """
        return slide_2_prompt
    elif slide_number == 3: 
        slide_3_prompt = f"""
        Examine the financial performance data and suggest a title that best represents the financial health and trends and generate insights by following below rules. 

        Make use of the field definitions from field_context provided below while generating title and insights.
        In the field_context, we have given meaning to each term. Try to understand the significance of it and generate title and insights according to that.
        Look on the value significance of field details carefully as some field having higher value signifies lower performance and high security measures for example fraud rates.

        <field_context>
        {column_data}
        </field_context>

        Please analyze the data and generate a {no_of_insights} insights based on the given rules:
        Rules:
        1. Examine the Bank's Consumer Debit Cardholders data in the dataframe. Suggest a title that best represents the financial health and main trends..
        2. Always keep the title first and then the rest insights should follow.
        3. Generate {no_of_insights} insights of at least 30 to maximum 35 words each.
        4. Dont use Issuer Name in the points, compare issuer vs issuer or issuer vs peers numbers and generate insights based on available metric data.
        5. For rows where `Peerset` equals 0, these values belong to the issuer.
        6. For rows where `Peerset` equals 1, these values belong to the peers.
        7. Summarize the data and provide numerical data points all under 30 to 40 words and it should be verbal and complete sentance.
        8. While summarizing multiply the decimal values with 100 like 0.09 will become 0.09*100 = 9%.
        9. If peers data is not present for that category then dont compare and generate insight for that category.
        10. Use Metric names not categories if required.
        11. Use finance vocabulary to provide precise insights.
        12. Avoid vague sentences; start with specific observations.
        13. Provide clear and concise analysis for each data point.
        14. Each insight should be meaningful and add value to the overall analysis.
        15. there are few categories Issuer, which means issuer data for the Metrics, similarly Peers and difference which means difference between issuer's metrics and peer's metrics
        16. 14. Order the {no_of_insights} insights with most relevant at the top or most positive growth point at the top,
            you can also use issuer and peers difference or delta to decide the order for example biggest difference or delta comes first.
        17. Title can be a maximum of 10 words.
        18. Dont use Insights word before the insights lines.
        19. Use finance-related jargon relevant to the data.
        20. Title should not contain peers storyline.
        21. Avoid using generic terms; be specific about the metrics or trends.
        22. The title should use relevant finance jargon.
        23. The title should clearly reflect the data content.
        24. Slide 3 is world data metrics which consists of fraud kpis and payment volume as an pv specificaly APAC and CEMEA data for Benchmark and issuer.
        35. Keep the title at the 0th index: Title: "Title content".
        26. The output format should be: Title: "Title content", followed by insights as '1. generated insights', '2. generated insights', etc.
        Mistakes -  
        1. In Slide 3 world KPIs, Higher the fraud rate the bad it is, higher fraud rate means that there are more fraud transactions. 
        Error Cleaning- 
        1. Removes the extra lines and tabs and one insight should come in one line with out leaving any lines blank.
        2. Remove word "Title" in title line and dont use 1. or 2. in title line.
        3. Remove any words Attached to insights like "Insights:", "-".
        4. Title should not be in double quotes.

        Stricktly follow the Rules and Generate the title and insights based on these rules, and do not make the above miskates and perform the error cleaning.

        """
        return slide_3_prompt
