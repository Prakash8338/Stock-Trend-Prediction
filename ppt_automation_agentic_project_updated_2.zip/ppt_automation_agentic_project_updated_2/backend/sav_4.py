import streamlit as st
import streamlit.components.v1 as components
import pandas as pd
import numpy as np
import pptx
import zipfile
from pptx import presentation
#from ppt_generator import generate_ppt
#from ppt_generator_v2 import generate_ppt
from ppt_generator import generate_ppt_2
#from ppt_generator_v4 import generate_ppt_2
import os
import base64
from PIL import Image, ImageDraw
#from spire.presentation import *
#from spire.presentation.common import *
import shutil
from pptx import Presentation
from pptx.util import Inches
from PIL import Image, ImageDraw, ImageFont
import io
import matplotlib.pyplot as plt
import cv2
import win32com.client
import os
from pdf2image import convert_from_path
import fitz 
import comtypes.client
def ppt_to_pdf(ppt_file):
    try:
        # Start PowerPoint application
        powerpoint = comtypes.client.CreateObject("PowerPoint.Application")
        powerpoint.Visible = 1  # Optional: make PowerPoint visible

        # Open the PowerPoint file
        presentation = powerpoint.Presentations.Open(ppt_file)

        # Define PDF file path
        pdf_file = ppt_file.replace('.pptx', '.pdf')

        # Save presentation as PDF
        presentation.SaveAs(pdf_file, 32)  # 32 is the format for PDF
        presentation.Close()

        return pdf_file

    except Exception as e:
        raise RuntimeError(f"Failed to convert PPT to PDF: {e}")

    finally:
        # Ensure PowerPoint is closed
        if 'powerpoint' in locals():
            powerpoint.Quit()

def pdf_to_images(pdf_file):
    images = []
    document = fitz.open(pdf_file)
    
    for page_num in range(len(document)):
        page = document.load_page(page_num)
        pix = page.get_pixmap()
        img_path = f"page_{page_num + 1}.png"
        pix.save(img_path)
        images.append(img_path)
    
    document.close()
    return images

def zip_files(folder_path,zip_name):
    with zipfile.ZipFile(zip_name,'w',zipfile.ZIP_DEFLATED) as zipf:
        for root, _,files in os.walk(folder_path):
            for file in files:
                file_path = os.path.join(root,file)
                zipf.write(file_path,os.path.relpath(file_path,folder_path))



def generate_ppt(df, Merchant_filter, template,submitted_feedback):
    if not submitted_feedback:
        st.empty()
        ppt_file = generate_ppt_2(df, Merchant_filter, template)

        ppt_file_up = rf'C:\first_project\fraud_ppt_automation\fraud_ppt_automation\ppt_files\{Merchant_filter}_generated_ppt.pptx'


    
        # Convert PPT to PDF
    try:
        # Convert PPT to PDF
        pdf_file = ppt_to_pdf(os.path.abspath(ppt_file_up))

        # Convert PDF to images
        st.session_state.slide_images = pdf_to_images(pdf_file)

        if len(st.session_state.submitted_feedback) != len(st.session_state.slide_images):
            st.session_state.submitted_feedback = [False] * len(st.session_state.slide_images)

        feedback = {}  # Store feedback for each slide
        

        if st.session_state.slide_images:
            for idx, image_path in enumerate(st.session_state.slide_images):
                st.image(image_path, caption=f"Page {idx + 1}", use_column_width=True)

                # Feedback options
                col1, col2 = st.columns(2)

                with col1:
                    if not st.session_state.submitted_feedback[idx]:  # Check if feedback already submitted
                        if st.button("👍", key=f"up_{idx}"):
                            feedback[f"Slide {idx + 1}"] = 1  # Thumbs Up
                            st.session_state.submitted_feedback[idx] = True  # Mark feedback as submitted

                with col2:
                    if not st.session_state.submitted_feedback[idx]:  # Check if feedback already submitted
                        if st.button("👎", key=f"down_{idx}"):
                            feedback[f"Slide {idx + 1}"] = 0  # Thumbs Down
                            st.session_state.submitted_feedback[idx] = True  # Mark feedback as submitted


        if st.button("Submit Feedback"):
            feedback_df = pd.DataFrame(list(feedback.items()), columns=["Slide", "Feedback"])
            feedback_dir = "feedback"  # Specify the feedback folder
            os.makedirs(feedback_dir, exist_ok=True)  # Create folder if it doesn't exist
            feedback_file_path = os.path.join(feedback_dir, f'feedback_{filter}.csv')
            feedback_df.to_csv(feedback_file_path, index=False)
            
            st.write("Feedback received:")
            #for slide, value in feedback.items():
                #st.write(f"{slide}: {value}")

    except RuntimeError as e:
        st.error(str(e))

    except Exception as e:
        st.error(f"An unexpected error occurred: {e}")

    finally:
        # Cleanup temporary files if needed
        if 'pdf_file' in locals() and os.path.exists(pdf_file):
            os.remove(pdf_file)
        for image_path in st.session_state.slide_images:
            if os.path.exists(image_path):
                os.remove(image_path)

    
    if st.success('Powerpoint Generated Successfully'):
        st.download_button(label='Download Powerpoint Presentation', data=open(ppt_file, 'rb').read(), file_name=f"{Merchant_filter}_Generated_ppt.pptx")
        os.remove(ppt_file)

        # Set a flag in session state
    #if st.session_state.submitted_feedback:
        st.session_state.ppt_generated = True
def main():
    if 'ppt_generated' not in st.session_state:
        st.session_state.ppt_generated = False

    if 'submitted_feedback' not in st.session_state:
        st.session_state.submitted_feedback = []
    
    st.title('Automated Powerpoint Generator Demo with GenAI Insights')
    st.subheader('Developed by EXL')
    df = pd.read_csv("issuer_data.csv")
    template = 'auto_code_ppt.pptx'
    st.sidebar.title("Options")
    st.sidebar.subheader('Filter Options')
    Merchant_options = df['issuer'].unique().tolist()
    Merchant_filter = st.sidebar.selectbox('Select Issuer:',Merchant_options)
    st.sidebar.title('Search Option')
    search_query = st.sidebar.text_input("Enter the issuer name")
    if search_query:
        st.write(f'Search Results for "{search_query}": ')
        issuer = [word for word in Merchant_options if search_query.lower() in word.lower()]
        st.write('Search results:')
        for result in issuer:
            if st.button(result):
                issuer = st.empty()
                st.write(f"You Selected: {result}")
                st.success("Generating the Power Point Presentation...")
                Merchant_filter = result
                generate_ppt(df,Merchant_filter,template)
    st.sidebar.subheader("Customized Options")  
    st.sidebar.warning("Custom template should have same shape names as default template")
    input_template = st.sidebar.file_uploader("Upload different Template", type = ["pptx"])
    st.sidebar.download_button(label = 'Download Default Template', data = open(template,'rb').read(),file_name = f"template_ppt.pptx")
    if input_template:
        template = input_template
    if st.session_state.ppt_generated:
        # Feedback buttons
        st.subheader("Insights Feedback")  # Heading above the buttons
        col1, col2 = st.columns(2)
        with col1:
            if st.button("👍"):
                st.success("Thank you for your feedback! 👍")
                st.session_state.ppt_generated = False  # Reset after feedback
        with col2:
            if st.button("👎"):
                st.error("We're sorry to hear that. 👎")
                st.session_state.ppt_generated = False  # Reset after feedback
    if st.button('Download Powerpoint Presentation for all Issuers'):
        with st.spinner("Creating PPTs and zipping...."):
            output_dir = "ppt_files"
            if not os.path.exists(output_dir):
                os.makedirs(output_dir)
            for Merchant_filter in Merchant_options:
                generate_ppt(df,Merchant_filter,template)
            zip_name= "All_Merchants_Presentations.zip" 
            zip_files(output_dir,zip_name)
            with open(zip_name,"rb") as f:
                st.download_button("Download ZIP",f,file_name = zip_name)
            print('Removing')
            shutil.rmtree(output_dir)
            os.remove(zip_name)
    if st.button('Generate Power Point Presentation for a Single Issuer'):
        generate_ppt(df,Merchant_filter,template,st.session_state.submitted_feedback)
    if st.sidebar.button('Regenerate'):
        st.rerun()
if __name__ == '__main__':
    main()