import pptx
from pptx import Presentation
from pptx.enum.chart import *
from pptx.enum.shapes import *
from pptx.chart.data import * 
import pandas as pd
from pptx.util import Pt,Inches
from pptx.dml.color import RGBColor
import plotly.graph_objs as go
import plotly.io as pio
import os 
from lxml import etree
#import kaleido

from summary_agent import summary_agent
from prompt import get_prompt
from column_data import column_data

def create_waterfall_data(categories,values):
    waterfall_data_2 = []
    for value in values:
        series_data = [value] * len(categories)
        waterfall_data_2.append(series_data)
    return waterfall_data_2
def generate_ppt_2(df,issuer_filter,template):
    filtered_df=df[(df['issuer'] == issuer_filter)]
    prs=Presentation(template)
    slide = prs.slides[0]
    for shape in slide.shapes:
        if shape.name == 'issuer_name':
            shape.text = issuer_filter
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(40)
                        run.font.color.rgb = RGBColor(255,0,0)
    slide = prs.slides[1]
    filtered_df_2=filtered_df[filtered_df['slide'] == 1]
    columns = ['Category','Metric','time_period']
    column_dict = dict()
    for i in columns:
        v = list(filtered_df_2[i].unique())
        for key, value in column_data[i].items():
            if key in v:
                column_dict[key] = value
    # feedback_data_1 = feedback_data[feedback_data['Slide'] == 'slide1'][['Insight', 'Score']].head(2)
    # feedback_data_1_up = feedback_data_1.to_json(orient='records')
    prompt = get_prompt(str(column_dict) , 4, 1)
    output_list=summary_agent(filtered_df_2,prompt,1)
    final_dict = {}
    #output_list = ['Enhanced Security Performance With Lower Overall Fraud Rates', "1. The issuer's overall fraud rate is outperforming peers by 4.1 basis points (bps), indicating stronger security measures being implemented globally. ", "2. In the APAC region, the issuer's Card Present (CP) fraud rate is slightly lower than its peers, suggesting better security in card-present transactions. ", '3. For Card Not Present (CNP) transactions, the issuer has managed to maintain a lower fraud rate worldwide, indicating efficient fraud detection measures in place.']
    final_dict['slide1'] = output_list
    for shape in slide.shapes:
        if shape.name == 'issuer_name':
            shape.text = issuer_filter
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(20,52,203)
        if shape.name == 'chart_1':
            waterfall_df=filtered_df[(filtered_df['chart_type'] == 'Waterfall') & (filtered_df['Peerset'] == 0) & (filtered_df['Category'] != 'Difference')]
            cats=waterfall_df['Metric'].tolist()
            vals=waterfall_df['value'].tolist()
            waterfall_data=create_waterfall_data(cats,vals)
            chart = shape.chart
            chart_data = CategoryChartData()
            chart_data.categories = waterfall_df['Metric']
            #chart_data.add_series('Value', waterfall_df['value'])
            for i,series in enumerate(waterfall_data):
                series_name=f'Series {i + 1}'
                chart_data.add_series(series_name,series)
            chart.replace_data(chart_data)
            chart.has_legend = False
            chart.plots[0].gap_width=50
            #chart.legend.position = XL_LEGEND_POSITION.BOTTOM
            #chart.legend.include_in_layout = False
            for i in range(len(waterfall_data)):
                for j in range(len(waterfall_data)):
                    if i!=j :
                        fill = chart.series[i].points[j].format.fill
                        fill.solid()
                        fill.fore_color.rgb = RGBColor(255,255,255)
                        fill.transparency = 1
                        line = chart.series[i].points[j].format.line
                        line.fill.solid()
                        line.fill.fore_color.rgb = RGBColor(255,255,255)
                        chart.series[i].points[j].data_label.text_frame.text = ""
        if shape.name == 'peers_1':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Waterfall') & (filtered_df['Peerset']==1) & (filtered_df['Metric'] == 'New Active Cardholders'), 'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'peers_2':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Waterfall') & (filtered_df['Peerset']==1) & (filtered_df['Metric'] == 'Existing Cardholders'), 'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'peers_3':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Waterfall') & (filtered_df['Peerset']==1) & (filtered_df['Metric'] == 'Disengaged Cardholders'), 'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'peers_4':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Waterfall') & (filtered_df['Peerset']==1) & (filtered_df['Metric'] == '23 Q3-23 Q4'), 'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'oval_box':
            shape.text=str((filtered_df.loc[filtered_df['chart_type'] == 'Oval','value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'chart_2':
            waterfall_df=filtered_df[(filtered_df['chart_type'] == 'Waterfall' ) & (filtered_df['Peerset'] == 0) & (filtered_df['Category'] == 'Difference')]
            cats=waterfall_df['Metric'].tolist()
            vals=waterfall_df['value'].tolist()
            waterfall_data=create_waterfall_data(cats,vals)
            chart = shape.chart
            chart_data = CategoryChartData()
            chart_data.categories = waterfall_df['Metric']
            #chart_data.add_series('Value', waterfall_df['value'])
            for i,series in enumerate(waterfall_data):
                series_name=f'Series {i + 1}'
                chart_data.add_series(series_name,series)
            chart.replace_data(chart_data)
            chart.has_legend = False
            chart.plots[0].gap_width=50
            #chart.legend.position = XL_LEGEND_POSITION.BOTTOM
            #chart.legend.include_in_layout = False
            for i in range(len(waterfall_data)):
                for j in range(len(waterfall_data)):
                    if i!=j :
                        fill = chart.series[i].points[j].format.fill
                        fill.solid()
                        fill.fore_color.rgb = RGBColor(255,255,255)
                        fill.transparency = 1
                        line = chart.series[i].points[j].format.line
                        line.fill.solid()
                        line.fill.fore_color.rgb = RGBColor(255,255,255)
                        chart.series[i].points[j].data_label.text_frame.text = ""
            #data = go.Waterfall(x=cats,y=vals,increasing = dict(marker=dict(color='green')),decreasing=dict(marker=dict(color='red')),textposition='outside',text=['{:.1f}%'.format(value) for value in vals])
            #layout = go.Layout(title=None, xaxis=dict(tickangle=-45,automargin=True,showticklabels=False),yaxis=dict(tickangle=0,showticklabels=False,title=None,showgrid=False),showlegend=False)
            #fig=go.Figure(data=data,layout=layout)
            #image_file='waterfall_Chart.png'
            #left,top,width,height = shape.left,shape.top,shape.width,shape.height
            #pio.write_image(fig,image_file)
            #slide.shapes._spTree.remove(shape._element)
            #slide.shapes.add_picture(image_file,left,top,width=width,height=height)
        if shape.name == 'title_box':
            shape.text= output_list[0]
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    paragraph.font.bold = True
                    for run in paragraph.runs:
                        run.font.size=Pt(18)
                        run.font.color.rgb = RGBColor(0,0,255)
        if shape.name == 'key_insight_1':
            shape.text= output_list[1]
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(16)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'key_insight_2':
            shape.text= output_list[2]
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(16)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'key_insight_3':
            shape.text= output_list[3]
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(16)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'key_insight_4':
            shape.text= output_list[4]
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(16)
                        run.font.color.rgb = RGBColor(0,0,0)
        #if shape.name == 'key_insight_1':
        #    x=filtered_df.loc[filtered_df['Metric'] == '22 Q1-22 Q4']
        #    y=filtered_df.loc[filtered_df['Metric'] == '23 Q3-23 Q4']
        #    z=filtered_df.loc[(filtered_df['Peerset'] == 1) & (filtered_df['Metric'] == '23 Q3-23 Q4')]
        #    df=pd.concat([x,y,z], axis=0)
        #   shape.text=generate_text(df,1)
        #    if shape.has_text_frame:
        #        for paragraph in shape.text_frame.paragraphs:
        #            for run in paragraph.runs:
        #                run.font.size=Pt(16)
        #                run.font.color.rgb = RGBColor(0,0,0)
        #if shape.name == 'key_insight_2':
        #   x=filtered_df.loc[(filtered_df['Peerset'] == 0) & (filtered_df['Metric'] == 'New Active Cardholders')]
        #    y=filtered_df.loc[(filtered_df['Peerset'] == 1) & (filtered_df['Metric'] == 'New Active Cardholders')]
        #    df=pd.concat([x,y], axis=0)
        #    shape.text=generate_text(df,1)
        #    if shape.has_text_frame:
        #       for paragraph in shape.text_frame.paragraphs:
        #            for run in paragraph.runs:
        #                run.font.size=Pt(16)
        #               run.font.color.rgb = RGBColor(0,0,0)
        #if shape.name == 'key_insight_3': 
        #    x=filtered_df.loc[(filtered_df['Peerset'] == 0) & (filtered_df['Metric'] == 'Existing Cardholders')]
        #    y=filtered_df.loc[(filtered_df['Peerset'] == 1) & (filtered_df['Metric'] == 'Existing Cardholders')]
        #    df=pd.concat([x,y], axis=0)
        #    shape.text=generate_text(df,1)
        #    if shape.has_text_frame:
        #        for paragraph in shape.text_frame.paragraphs:
        #            for run in paragraph.runs:
        #                run.font.size=Pt(16)
        #                run.font.color.rgb = RGBColor(0,0,0)
        #if shape.name == 'key_insight_4':
        #    x=filtered_df.loc[(filtered_df['Peerset'] == 0) & (filtered_df['Metric'] == 'Disengaged Cardholders')]
        #    y=filtered_df.loc[(filtered_df['Peerset'] == 1) & (filtered_df['Metric'] == 'Disengaged Cardholders')]
        #    df=pd.concat([x,y], axis=0)
        #    shape.text=generate_text(df,1)
        #    if shape.has_text_frame:
        #        for paragraph in shape.text_frame.paragraphs:
        #            for run in paragraph.runs:
        #                run.font.size=Pt(16)
        #               run.font.color.rgb = RGBColor(0,0,0)
    slide = prs.slides[2]
    filtered_df_2=filtered_df[filtered_df['slide'] == 2]
    column_dict = dict()
    for i in columns:
        v = list(filtered_df_2[i].unique())
        for key, value in column_data[i].items():
            if key in v:
                column_dict[key] = value
    # feedback_data_2 = feedback_data[feedback_data['Slide'] == 'slide2'][['Insight', 'Score']].head(2)
    # feedback_data_2_up = feedback_data_2.to_json(orient='records')
    prompt = get_prompt(str(column_dict) , 3, 2)
    output_list=summary_agent(filtered_df_2,prompt,2)
    final_dict['slide2'] = output_list
    for shape in slide.shapes:
        if shape.name == 'issuer_name':
            shape.text=issuer_filter
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(20,52,203)
        if shape.name == 'line_chart':
            line_df_client = filtered_df[(filtered_df['chart_type'] == 'Line') & (filtered_df['Peerset'] == 0)]
            line_df_peers = filtered_df[(filtered_df['chart_type'] == 'Line') & (filtered_df['Peerset'] == 1)]
            cats=line_df_client['Metric'].tolist()
            client_val=line_df_client['value'].tolist()
            peer_val=line_df_peers['value'].tolist()
            chart=shape.chart
            chart_data=CategoryChartData()
            chart_data.categories = cats
            chart_data.add_series('Issuer % Cards Attrited',client_val)
            chart_data.add_series('Peers % Cards Attrited',peer_val)
            chart.replace_data(chart_data)
        if shape.name == 'bar_graph':
            line_df_client = filtered_df[(filtered_df['chart_type'] == 'column') & (filtered_df['Peerset'] == 0)]
            line_df_peers = filtered_df[(filtered_df['chart_type'] == 'column') & (filtered_df['Peerset'] == 1)]
            cats=line_df_client['Metric'].tolist()
            client_val=line_df_client['value'].tolist()
            peer_val=line_df_peers['value'].tolist()
            chart=shape.chart
            chart_data=CategoryChartData()
            chart_data.categories = cats
            chart_data.add_series('Issuer PV',client_val)
            chart_data.add_series('Peers PV',peer_val)
            chart.replace_data(chart_data)
        if shape.name == 'Issuer_1':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Impact on Spend from Cardholder Disengagement'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Issuer_2':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Cards With at least 1 Authorization Decline'),'value'].values[0]) / 1000) + 'K'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Issuer_3':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Percent of Portfolio at Risk of Disengagement'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'prev_year_1':
            shape.text='(' + str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Prior') & (filtered_df['Metric'] == 'Impact on Spend from Cardholder Disengagement'),'value'].values[0]) * 100) + '%' + ')'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(10)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'prev_year_2':
            shape.text='(' + str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Prior') & (filtered_df['Metric'] == 'Cards With at least 1 Authorization Decline'),'value'].values[0]) / 1000) + 'K' + ')'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(10)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'prev_year_3':
            shape.text='(' + str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Prior') & (filtered_df['Metric'] == 'Percent of Portfolio at Risk of Disengagement'),'value'].values[0]) * 100) + '%' + ')'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(10)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Peers_1':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 1) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Impact on Spend from Cardholder Disengagement'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Peers_2':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 1) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Cards With at least 1 Authorization Decline'),'value'].values[0]) / 1000) + 'K'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Peers_3':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 1) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Percent of Portfolio at Risk of Disengagement'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Delta_1':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Category'] == 'Difference') & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Impact on Spend from Cardholder Disengagement'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Delta_2':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Category'] == 'Difference') & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Cards With at least 1 Authorization Decline'),'value'].values[0]) / 1000) + 'K'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Delta_3':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Category'] == 'Difference') & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Percent of Portfolio at Risk of Disengagement'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'title_box':
            shape.text= output_list[0]
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(18)
                        run.font.color.rgb = RGBColor(0,0,255)
                        run.font.bold = True
        if shape.name == 'key_insight_1':
            shape.text= output_list[1]
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(16)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'key_insight_2':
            shape.text= output_list[2]
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(16)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'key_insight_3':
            shape.text= output_list[3]
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(16)
                        run.font.color.rgb = RGBColor(0,0,0)
    slide = prs.slides[3]
    filtered_df_2=filtered_df[filtered_df['slide'] == 3]
    column_dict = dict()
    for i in columns:
        v = list(filtered_df_2[i].unique())
        for key, value in column_data[i].items():
            if key in v:
                column_dict[key] = value

    # feedback_data_3 = feedback_data[feedback_data['Slide'] == 'slide3'][['Insight', 'Score']].head(2)
    # feedback_data_3_up = feedback_data_3.to_json(orient='records')
    prompt = get_prompt(str(column_dict) , 2, 3)
    output_list=summary_agent(filtered_df_2,prompt,3)
    final_dict['slide3'] = output_list
    for shape in slide.shapes:
        if shape.name == 'issuer_name':
            shape.text=issuer_filter
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(20,52,203)
        if shape.name == 'world_issuer_pv':
            shape.text=str((filtered_df.loc[(filtered_df['Peerset'] == 0) & (filtered_df['chart_type'] == 'world') & (filtered_df['Category'] == 'World PV'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'world_issuer_approval':
            shape.text=str((filtered_df.loc[(filtered_df['Peerset'] == 0) & (filtered_df['chart_type'] == 'world') & (filtered_df['Category'] == 'World Approval'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'world_issuer_fraud_vol':
            shape.text=str((filtered_df.loc[(filtered_df['Peerset'] == 0) & (filtered_df['chart_type'] == 'world') & (filtered_df['Category'] == 'World Fraud Vol'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'world_issuer_fraud_rate':
            shape.text=str((filtered_df.loc[(filtered_df['Peerset'] == 0) & (filtered_df['chart_type'] == 'world') & (filtered_df['Category'] == 'World Fraud Rate'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'apac_issuer_pv':
            shape.text=str((filtered_df.loc[(filtered_df['Peerset'] == 0) & (filtered_df['chart_type'] == 'world') & (filtered_df['Category'] == 'Apac PV'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'apac_issuer_fraud':
            shape.text=str((filtered_df.loc[(filtered_df['Peerset'] == 0) & (filtered_df['chart_type'] == 'world') & (filtered_df['Category'] == 'Apac Fraud'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'cemea_issuer_pv':
            shape.text=str((filtered_df.loc[(filtered_df['Peerset'] == 0) & (filtered_df['chart_type'] == 'world') & (filtered_df['Category'] == 'CEMEA PV'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'cemea_issuer_fraud':
            shape.text=str((filtered_df.loc[(filtered_df['Peerset'] == 0) & (filtered_df['chart_type'] == 'world') & (filtered_df['Category'] == 'CEMEA Fraud'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        ##PEERSET
        if shape.name == 'world_bench_pv':
            shape.text=str((filtered_df.loc[(filtered_df['Peerset'] == 1) & (filtered_df['chart_type'] == 'world') & (filtered_df['Category'] == 'World PV'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'world_bench_approval':
            shape.text=str((filtered_df.loc[(filtered_df['Peerset'] == 1) & (filtered_df['chart_type'] == 'world') & (filtered_df['Category'] == 'World Approval'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'world_bench_fraud_vol':
            shape.text=str((filtered_df.loc[(filtered_df['Peerset'] == 1) & (filtered_df['chart_type'] == 'world') & (filtered_df['Category'] == 'World Fraud Vol'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'world_bench_fraud_rate':
            shape.text=str((filtered_df.loc[(filtered_df['Peerset'] == 1) & (filtered_df['chart_type'] == 'world') & (filtered_df['Category'] == 'World Fraud Rate'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'apac_bench_pv':
            shape.text=str((filtered_df.loc[(filtered_df['Peerset'] == 1) & (filtered_df['chart_type'] == 'world') & (filtered_df['Category'] == 'Apac PV'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'apac_bench_fraud':
            shape.text=str((filtered_df.loc[(filtered_df['Peerset'] == 1) & (filtered_df['chart_type'] == 'world') & (filtered_df['Category'] == 'Apac Fraud'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'cemea_bench_pv':
            shape.text=str((filtered_df.loc[(filtered_df['Peerset'] == 1) & (filtered_df['chart_type'] == 'world') & (filtered_df['Category'] == 'CEMEA PV'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'cemea_bench_fraud':
            shape.text=str((filtered_df.loc[(filtered_df['Peerset'] == 1) & (filtered_df['chart_type'] == 'world') & (filtered_df['Category'] == 'CEMEA Fraud'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'title':
            shape.text= output_list[0]
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(18)
                        run.font.color.rgb = RGBColor(0,0,255)
                        run.font.bold = True
        if shape.name == 'insights_1':
            shape.text= output_list[1]
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(16)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'insights_2':
            shape.text= output_list[2]
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(16)
                        run.font.color.rgb = RGBColor(0,0,0)
    output_dir='ppt_files'
    if not os.path.exists(output_dir):
        os.mkdir(output_dir)
    ppt_file=f"{output_dir}/{issuer_filter}_generated_ppt.pptx"
    prs.save(ppt_file)
    return ppt_file, final_dict

def update_slide_insight(ppt_file, slide_num, new_insights):
    prs = Presentation(ppt_file)
    slide = prs.slides[slide_num]
    for shape in slide.shapes:
        if hasattr(shape, 'name'):
            if shape.name in ['title_box', 'title'] and len(new_insights) > 0:
                shape.text = new_insights[0]
                if shape.has_text_frame:
                    for paragraph in shape.text_frame.paragraphs:
                        paragraph.font.bold = True
                        for run in paragraph.runs:
                            run.font.size = Pt(18)
                            run.font.color.rgb = RGBColor(0, 0, 255)
            if shape.name in ['key_insight_1', 'insights_1'] and len(new_insights) > 1:
                shape.text = new_insights[1]
                if shape.has_text_frame:
                    for paragraph in shape.text_frame.paragraphs:
                        for run in paragraph.runs:
                            run.font.size = Pt(16)
                            run.font.color.rgb = RGBColor(0, 0, 0)
            if shape.name in ['key_insight_2', 'insights_2'] and len(new_insights) > 2:
                shape.text = new_insights[2]
                if shape.has_text_frame:
                    for paragraph in shape.text_frame.paragraphs:
                        for run in paragraph.runs:
                            run.font.size = Pt(16)
                            run.font.color.rgb = RGBColor(0, 0, 0)
            if shape.name == 'key_insight_3' and len(new_insights) > 3:
                shape.text = new_insights[3]
                if shape.has_text_frame:
                    for paragraph in shape.text_frame.paragraphs:
                        for run in paragraph.runs:
                            run.font.size = Pt(16)
                            run.font.color.rgb = RGBColor(0, 0, 0)
            if shape.name == 'key_insight_4' and len(new_insights) > 4:
                shape.text = new_insights[4]
                if shape.has_text_frame:
                    for paragraph in shape.text_frame.paragraphs:
                        for run in paragraph.runs:
                            run.font.size = Pt(16)
                            run.font.color.rgb = RGBColor(0, 0, 0)
    prs.save(ppt_file)


