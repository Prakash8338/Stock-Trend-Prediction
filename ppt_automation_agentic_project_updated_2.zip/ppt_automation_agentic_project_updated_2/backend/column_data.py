column_data = {
"Category":{
"Issuer": "It stands for Issuer Bank",
"Peers": "It stands for Peers of Issuer Bank",
"Difference": "It stands for Difference",
"Issuer % Cards Fraud": "It stands for Fraud Percentage for Issuer. lesser the Fraud Percentage the better it is",
"Peers % Cards Fraud": "It stands for Fraud Percentage for Peers of Issuer. lesser the Fraud Percentage the better it is",
"Issuer Fraud PV": "It stands for Fraud Payment Volume for Issuer. lesser the Fraud Payment Volume the better it is",
"Peers Fraud PV": "It stands for Fraud Payment Volume for Peers of Issuer. lesser the Fraud Payment Volume the better it is",
"Apac PV": "It stands for Payment Volume for Asia Pacific region. greater the Payment Volume the better it is",
"Apac Fraud": "It stands for Fraud Volume for Asia Pacific region. lesser the Fraud Volume the better it is",
"CEMEA PV": "It stands for Payment Volume for Central Europe, Middle East and Africa region. greater the Payment Volume the better it is",
"CEMEA Fraud": "It stands for Fraud Volume for Central Europe, Middle East and Africa region. lesser the Fraud Volume the better it is",
"World PV": "It stands for Payment Volume for World. greater the Payment Volume the better it is",
"World Fraud Vol": "It stands for Fraud Volume for World. lesser the Fraud Volume the better it is",
"World Fraud Rate": "It stands for Fraud rate for World in terms of percentage. lesser the World Fraud Rate the better it is. for exmaple 103 is good and positive than compared to 104.higher the World Fraud Rate the more negative the trend.",
"World Approval": "It stands for Approvals for World."
},

"Metric": {
"Global": "Includes all countries of the World",
"APAC": "Includes only Asia Pacific region",
"CEMEA": "Includes only Central Europe, Middle East and Africa regions",
"Cards with atleast 1 Fraud transaction": "Credit/Debit cards with atleast 1 Fraud transaction",
"Q4'22": "Quarter 4 of year 2022",
"Q1'23": "Quarter 1 of year 2023",
"Q2'23": "Quarter 2 of year 2023",
"Q3'23": "Quarter 3 of year 2023",
"Q4'23": "Quarter 4 of year 2023",
"Fraud Rate":"lesser the fraud rate the better it is. for exmaple 103 is good and positive than compared to 104.higher the fraud rate the more negative the trend."
},

"time_period":{
"Current": "The ongoing time period",
"Prior": "Previous time period"

}
}