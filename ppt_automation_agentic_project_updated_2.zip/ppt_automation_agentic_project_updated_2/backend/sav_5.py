import streamlit as st
import streamlit.components.v1 as components
import pandas as pd
import numpy as np
import pptx
import zipfile
from pptx import presentation
#from ppt_generator import generate_ppt
#from ppt_generator_v2 import generate_ppt
from ppt_generator import generate_ppt_2
#from ppt_generator_v4 import generate_ppt_2
import os
import base64
from PIL import Image, ImageDraw
#from spire.presentation import *
#from spire.presentation.common import *
import shutil
from pptx import Presentation
from pptx.util import Inches
from PIL import Image, ImageDraw, ImageFont
import io
import matplotlib.pyplot as plt
import cv2
import win32com.client
import os
from pdf2image import convert_from_path
import fitz 
import comtypes.client
def ppt_to_pdf(ppt_file):
    try:
        
        powerpoint = comtypes.client.CreateObject("PowerPoint.Application")
        powerpoint.Visible = 1  # Optional: make PowerPoint visible

       
        presentation = powerpoint.Presentations.Open(ppt_file)

        
        pdf_file = ppt_file.replace('.pptx', '.pdf')

        
        presentation.SaveAs(pdf_file, 32)  # 32 is the format for PDF
        presentation.Close()

        return pdf_file

    except Exception as e:
        raise RuntimeError(f"Failed to convert PPT to PDF: {e}")

    finally:
       
        if 'powerpoint' in locals():
            powerpoint.Quit()

def pdf_to_images(pdf_file):
    images = []
    document = fitz.open(pdf_file)
    
    for page_num in range(len(document)):
        page = document.load_page(page_num)
        pix = page.get_pixmap()
        img_path = f"page_{page_num + 1}.png"
        pix.save(img_path)
        images.append(img_path)
    
    document.close()
    return images

def zip_files(folder_path,zip_name):
    with zipfile.ZipFile(zip_name,'w',zipfile.ZIP_DEFLATED) as zipf:
        for root, _,files in os.walk(folder_path):
            for file in files:
                file_path = os.path.join(root,file)
                zipf.write(file_path,os.path.relpath(file_path,folder_path))



def generate_ppt(slide_images,submitted_feedback, feedback, cnt,key1):
    if not submitted_feedback:
       
        for idx, image_path in enumerate(slide_images):
            st.image(image_path, caption=f"Page {idx + 1}", use_column_width=True)
           
            col1, col2 = st.columns(2)
            key1 = key1 +1
           
        

            with col1:
                
                if st.button("👍", key=f"up_{idx}"):
                    cnt = cnt + 1
                    print(cnt)
                    feedback[f"Slide {idx + 1}"] = 1  
                    
                        
            with col2:
                    
                if st.button("👎", key=f"down_{idx}"):
                    cnt = cnt + 1
                    feedback[f"Slide {idx + 1}"] = 0 
            
        if cnt == len(slide_images):
            print(feedback)
            feedback_df = pd.DataFrame(list(feedback.items()), columns=["Slide", "Feedback"])
            feedback_dir = "feedback"  
            os.makedirs(feedback_dir, exist_ok=True)  
            feedback_file_path = os.path.join(feedback_dir, f'feedback_{filter}.csv')
            feedback_df.to_csv(feedback_file_path, index=False)
            st.write("Feedback received:")
            submitted_feedback = True

    return submitted_feedback,feedback,cnt,key1
        
def main():
    if 'ppt_generated' not in st.session_state:
        st.session_state.ppt_generated = False

    if 'submitted_feedback' not in st.session_state:
        st.session_state.submitted_feedback = True

    
    st.title('Automated Powerpoint Generator Demo with GenAI Insights')
    st.subheader('Developed by EXL')
    df = pd.read_csv("issuer_data.csv")
    template = 'auto_code_ppt.pptx'
    st.sidebar.title("Options")
    st.sidebar.subheader('Filter Options')
    Merchant_options = df['issuer'].unique().tolist()
    Merchant_filter = st.sidebar.selectbox('Select Issuer:',Merchant_options)
    st.sidebar.title('Search Option')
    search_query = st.sidebar.text_input("Enter the issuer name")
    if search_query:
        st.write(f'Search Results for "{search_query}": ')
        issuer = [word for word in Merchant_options if search_query.lower() in word.lower()]
        st.write('Search results:')
        for result in issuer:
            if st.button(result):
                issuer = st.empty()
                st.write(f"You Selected: {result}")
                st.success("Generating the Power Point Presentation...")
                Merchant_filter = result
                generate_ppt(df,Merchant_filter,template)
    st.sidebar.subheader("Customized Options")  
    st.sidebar.warning("Custom template should have same shape names as default template")
    input_template = st.sidebar.file_uploader("Upload different Template", type = ["pptx"])
    st.sidebar.download_button(label = 'Download Default Template', data = open(template,'rb').read(),file_name = f"template_ppt.pptx")
    if input_template:
        template = input_template
    if st.session_state.ppt_generated:
        # Feedback buttons
        st.subheader("Insights Feedback")  # Heading above the buttons
        col1, col2 = st.columns(2)
        with col1:
            if st.button("👍"):
                st.success("Thank you for your feedback! 👍")
                st.session_state.ppt_generated = False  # Reset after feedback
        with col2:
            if st.button("👎"):
                st.error("We're sorry to hear that. 👎")
                st.session_state.ppt_generated = False  # Reset after feedback
    if st.button('Download Powerpoint Presentation for all Issuers'):
        with st.spinner("Creating PPTs and zipping...."):
            output_dir = "ppt_files"
            if not os.path.exists(output_dir):
                os.makedirs(output_dir)
            for Merchant_filter in Merchant_options:
                generate_ppt(df,Merchant_filter,template)
            zip_name= "All_Merchants_Presentations.zip" 
            zip_files(output_dir,zip_name)
            with open(zip_name,"rb") as f:
                st.download_button("Download ZIP",f,file_name = zip_name)
            print('Removing')
            shutil.rmtree(output_dir)
            os.remove(zip_name)
    if st.button('Generate Power Point Presentation for a Single Issuer'):
        st.empty()
        ppt_file = generate_ppt_2(df, Merchant_filter, template)

        ppt_file_up = rf'C:\first_project\fraud_ppt_automation\fraud_ppt_automation\ppt_files\{Merchant_filter}_generated_ppt.pptx'


   
        pdf_file = ppt_to_pdf(os.path.abspath(ppt_file_up))

        st.session_state.slide_images = pdf_to_images(pdf_file)

        
        st.session_state.submitted_feedback = False


        st.session_state.feedback = {}  # Store feedback for each slide
        st.session_state.cnt = 0

        st.session_state.key1 = 0




        st.session_state.submitted_feedback, st.session_state.feedback, st.session_state.cnt, st.session_state.key1 = generate_ppt(st.session_state.slide_images,st.session_state.submitted_feedback,st.session_state.feedback,st.session_state.cnt,st.session_state.key1)

    if not st.session_state.submitted_feedback:
        st.session_state.submitted_feedback, st.session_state.feedback, st.session_state.cnt, st.session_state.key1 = generate_ppt(st.session_state.slide_images,st.session_state.submitted_feedback,st.session_state.feedback,st.session_state.cnt,st.session_state.key1)
    
    if st.sidebar.button('Regenerate'):
        st.rerun()
if __name__ == '__main__':
    main()