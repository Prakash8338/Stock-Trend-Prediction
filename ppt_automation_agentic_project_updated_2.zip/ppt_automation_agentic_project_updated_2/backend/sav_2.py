import streamlit as st
import streamlit.components.v1 as components
import pandas as pd
import numpy as np
import pptx
import zipfile
from pptx import presentation
#from ppt_generator import generate_ppt
#from ppt_generator_v2 import generate_ppt
from ppt_generator import generate_ppt_2
#from ppt_generator_v4 import generate_ppt_2
import os
import base64
from PIL import Image, ImageDraw
#from spire.presentation import *
#from spire.presentation.common import *
import shutil
from pptx import Presentation
from pptx.util import Inches
from PIL import Image, ImageDraw, ImageFont
import io
import matplotlib.pyplot as plt
import cv2
def extract_slide_content(slide):
    content = []
    
    for shape in slide.shapes:
        if shape.has_text_frame:
            content.append({
                'type': 'text',
                'text': shape.text
            })
        elif shape.shape_type == 13:  # Picture
            img_stream = io.BytesIO(shape.image.blob)
            content.append({
                'type': 'image',
                'image': img_stream
            })
    
    return content

def load_presentation(file_path):
    prs = Presentation(file_path)
    slides_content = []

    for slide in prs.slides:
        slide_content = extract_slide_content(slide)
        slides_content.append(slide_content)

    return slides_content

def zip_files(folder_path,zip_name):
    with zipfile.ZipFile(zip_name,'w',zipfile.ZIP_DEFLATED) as zipf:
        for root, _,files in os.walk(folder_path):
            for file in files:
                file_path = os.path.join(root,file)
                zipf.write(file_path,os.path.relpath(file_path,folder_path))



def generate_ppt(df, Merchant_filter, template):
    st.empty()
    ppt_file = generate_ppt_2(df, Merchant_filter, template)

    slides_content = load_presentation(ppt_file)

    if slides_content:
        for idx, slide_content in enumerate(slides_content):
            st.header(f"Slide {idx + 1}")

            for item in slide_content:
                if item['type'] == 'text':
                    st.write(item['text'])
                elif item['type'] == 'image':
                    st.image(item['image'], caption="Image", use_column_width=True)
    
    if st.success('Powerpoint Generated Successfully'):
        st.download_button(label='Download Powerpoint Presentation', data=open(ppt_file, 'rb').read(), file_name=f"{Merchant_filter}_Generated_ppt.pptx")
        os.remove(ppt_file)

        # Set a flag in session state
        st.session_state.ppt_generated = True
def main():
    if 'ppt_generated' not in st.session_state:
        st.session_state.ppt_generated = False
    st.title('Automated Powerpoint Generator Demo with GenAI Insights')
    st.subheader('Developed by EXL')
    df = pd.read_csv("issuer_data.csv")
    template = 'auto_code_ppt.pptx'
    st.sidebar.title("Options")
    st.sidebar.subheader('Filter Options')
    Merchant_options = df['issuer'].unique().tolist()
    Merchant_filter = st.sidebar.selectbox('Select Issuer:',Merchant_options)
    st.sidebar.title('Search Option')
    search_query = st.sidebar.text_input("Enter the issuer name")
    if search_query:
        st.write(f'Search Results for "{search_query}": ')
        issuer = [word for word in Merchant_options if search_query.lower() in word.lower()]
        st.write('Search results:')
        for result in issuer:
            if st.button(result):
                issuer = st.empty()
                st.write(f"You Selected: {result}")
                st.success("Generating the Power Point Presentation...")
                Merchant_filter = result
                generate_ppt(df,Merchant_filter,template)
    st.sidebar.subheader("Customized Options")  
    st.sidebar.warning("Custom template should have same shape names as default template")
    input_template = st.sidebar.file_uploader("Upload different Template", type = ["pptx"])
    st.sidebar.download_button(label = 'Download Default Template', data = open(template,'rb').read(),file_name = f"template_ppt.pptx")
    if input_template:
        template = input_template
    if st.session_state.ppt_generated:
        # Feedback buttons
        st.subheader("Insights Feedback")  # Heading above the buttons
        col1, col2 = st.columns(2)
        with col1:
            if st.button("👍"):
                st.success("Thank you for your feedback! 👍")
                st.session_state.ppt_generated = False  # Reset after feedback
        with col2:
            if st.button("👎"):
                st.error("We're sorry to hear that. 👎")
                st.session_state.ppt_generated = False  # Reset after feedback
    if st.button('Download Powerpoint Presentation for all Issuers'):
        with st.spinner("Creating PPTs and zipping...."):
            output_dir = "ppt_files"
            if not os.path.exists(output_dir):
                os.makedirs(output_dir)
            for Merchant_filter in Merchant_options:
                generate_ppt(df,Merchant_filter,template)
            zip_name= "All_Merchants_Presentations.zip" 
            zip_files(output_dir,zip_name)
            with open(zip_name,"rb") as f:
                st.download_button("Download ZIP",f,file_name = zip_name)
            print('Removing')
            shutil.rmtree(output_dir)
            os.remove(zip_name)
    if st.button('Generate Power Point Presentation for a Single Issuer'):
        generate_ppt(df,Merchant_filter,template)
    if st.sidebar.button('Regenerate'):
        st.rerun()
if __name__ == '__main__':
    main()