import React, { useEffect, useState } from 'react'
import { issuerService, Issuer } from '../services/issuerService'
import '../styles/IssuerSelector.css'

interface IssuerSelectorProps {
  onIssuerSelect: (issuerId: number | null) => void
  selectedIssuerId: number | null
}

export const IssuerSelector: React.FC<IssuerSelectorProps> = ({
  onIssuerSelect,
  selectedIssuerId,
}) => {
  const [issuers, setIssuers] = useState<Issuer[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [searchQuery, setSearchQuery] = useState('')

  useEffect(() => {
    const fetchIssuers = async () => {
      try {
        setLoading(true)
        const data = await issuerService.getAllIssuers()
        setIssuers(data)
        setError(null)
      } catch (err) {
        setError('Failed to load issuers')
        console.error(err)
      } finally {
        setLoading(false)
      }
    }

    fetchIssuers()
  }, [])

  if (loading) {
    return <div className="issuer-selector loading">Loading issuers...</div>
  }

  if (error) {
    return <div className="issuer-selector error">{error}</div>
  }

  const filteredIssuers = issuers.filter(issuer =>
    issuer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    issuer.code.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div className="issuer-selector">
      <h3>Select Issuer</h3>
      <div className="search-box">
        <input
          type="text"
          placeholder="Search issuers..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="search-input"
        />
      </div>
      <div className="issuer-options">
        <button
          className={`issuer-btn ${selectedIssuerId === null ? 'active' : ''}`}
          onClick={() => onIssuerSelect(null)}
        >
          All Issuers
        </button>
        {filteredIssuers.map((issuer) => (
          <button
            key={issuer.id}
            className={`issuer-btn ${selectedIssuerId === issuer.id ? 'active' : ''}`}
            onClick={() => onIssuerSelect(issuer.id)}
          >
            {issuer.name}
          </button>
        ))}
        {filteredIssuers.length === 0 && searchQuery && (
          <div className="no-results">No issuers found</div>
        )}
      </div>
    </div>
  )
}
