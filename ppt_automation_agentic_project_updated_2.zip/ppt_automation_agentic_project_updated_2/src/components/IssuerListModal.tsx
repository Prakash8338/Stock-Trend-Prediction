import React from 'react'
import '../styles/IssuerListModal.css'

interface Issuer {
  id: number
  name: string
  code: string
}

interface IssuerListModalProps {
  issuers: Issuer[]
  onSelectIssuer: (issuerId: number) => void
  onClose: () => void
}

export const IssuerListModal: React.FC<IssuerListModalProps> = ({
  issuers,
  onSelectIssuer,
  onClose,
}) => {
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>Select Issuer to View Report</h2>
          <button className="modal-close" onClick={onClose}>
            ×
          </button>
        </div>
        <div className="modal-body">
          <p className="modal-description">
            Reports are ready for all issuers. Select an issuer to view and download their report.
          </p>
          <div className="issuer-list">
            {issuers.map((issuer) => (
              <div
                key={issuer.id}
                className="issuer-card"
                onClick={() => {
                  onSelectIssuer(issuer.id)
                  onClose()
                }}
              >
                <div className="issuer-card-header">
                  <h3>{issuer.name}</h3>
                  <span className="issuer-code">{issuer.code}</span>
                </div>
                <div className="issuer-card-actions">
                  <span className="view-label">Click to view report →</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
