import React from 'react'
import { Dashboard } from './pages/Dashboard'
import './index.css'

export const App: React.FC = () => {
  return (
    <div className="app">
      <Dashboard />
    </div>
  )
}

export default App
