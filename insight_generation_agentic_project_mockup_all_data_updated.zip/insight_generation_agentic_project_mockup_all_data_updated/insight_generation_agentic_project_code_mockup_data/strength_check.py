"""
Updated strength_check.py — Lightweight Bayesian Impact Scoring (replacement of deterministic model)

Design goals:
- Preserve existing public function names and return schemas so other modules (insight_agent.py, app.py)
  continue to work unchanged.
- Replace internal scoring logic with a conjugate Normal-Normal Bayesian update suitable for
  summary-level KPI deltas (percentage-point deltas for percentage metrics, percent-change for numeric metrics).
- Provide clear priors/likelihood heuristics, posterior computation, probability estimations, and
  human-friendly labels (impact magnitude & confidence).

Notes:
- This file intentionally keeps the same function signatures for:
    - calculate_change_magnitude
    - assess_impact_strength
    - analyze_insight_strength
    - format_impact_label
    - get_impact_thresholds_info

- Deterministic weight-based scoring has been removed as requested.
"""

from typing import Dict, List, Optional
import math

# =====================================================================
# PART 1 — CHANGE MAGNITUDE (UNCHANGED FOR BACKWARD COMPATIBILITY)
# =====================================================================

def calculate_change_magnitude(current_value: float, previous_value: float = None,
                               benchmark_value: float = None, is_percentage_data: bool = False) -> Dict:
    """
    Calculate magnitude of change. Behavior unchanged from previous engine.
    For percentage metrics:
        percentage_change = absolute pp difference
    For numeric metrics:
        percentage_change = percent change vs previous period
    """
    result = {
        'absolute_change': None,
        'percentage_change': None,
        'benchmark_gap': None,
        'benchmark_gap_pct': None
    }

    if previous_value is not None:
        result['absolute_change'] = current_value - previous_value
        if is_percentage_data:
            result['percentage_change'] = current_value - previous_value   # pp change
        else:
            if previous_value != 0:
                result['percentage_change'] = ((current_value - previous_value) / abs(previous_value)) * 100.0

    if benchmark_value is not None:
        result['benchmark_gap'] = current_value - benchmark_value
        if is_percentage_data:
            result['benchmark_gap_pct'] = current_value - benchmark_value
        else:
            if benchmark_value != 0:
                result['benchmark_gap_pct'] = ((current_value - benchmark_value) / abs(benchmark_value)) * 100.0

    return result


# =====================================================================
# PART 2 — LIGHTWEIGHT BAYESIAN MODEL
# =====================================================================

def is_percentage_metric(metric_name: Optional[str]) -> bool:
    """Heuristic to detect percentage-like metric names."""
    if not metric_name:
        return False
    low = metric_name.lower()
    pct_indicators = ["rate", "percentage", "%", "bps"]
    return any(ind in low for ind in pct_indicators)


def choose_prior_sd(metric_name: str, is_pct: bool) -> float:
    """
    Domain-informed prior standard deviation.
    For percentage metrics: SD measured in percentage points.
    For numeric metrics: SD measured in percent-change units.
    """
    mn = metric_name.lower() if metric_name else ""
    if is_pct:
        if "fraud" in mn or "decline" in mn or "disengagement" in mn:
            return 4.0
        if "authorization" in mn:
            return 1.5
        return 2.5
    else:
        if "spend" in mn or "transaction" in mn:
            return 10.0
        return 8.0


def choose_likelihood_sd(observed_delta: float, is_pct: bool) -> float:
    """
    Heuristic likelihood noise to avoid overconfidence.
    """
    if is_pct:
        floor = 0.5
        return max(abs(observed_delta) / 2.0 + 0.5, floor)
    else:
        floor = 3.0
        return max(abs(observed_delta) / 4.0 + 3.0, floor)


def bayesian_update(observed: float, observed_sd: float, prior_mean: float = 0.0, prior_sd: float = 1.0):
    """
    Conjugate Normal-Normal update.
    prior:     N(prior_mean, prior_sd^2)
    observed ~ N(observed, observed_sd^2)
    """
    prior_var = prior_sd ** 2
    like_var = max(1e-6, observed_sd ** 2)

    post_var = 1.0 / (1.0 / prior_var + 1.0 / like_var)
    post_mean = post_var * (prior_mean / prior_var + observed / like_var)
    post_sd = math.sqrt(post_var)

    return post_mean, post_sd


def thresholds_for_metric(is_pct: bool) -> Dict[str, float]:
    """
    Thresholds for mapping posterior mean to qualitative magnitude.
    """
    if is_pct:
        return {
            "massive": 5.0,        # 5pp+
            "significant": 2.0,    # 2pp
            "moderate": 1.0,       # 1pp
            "minor": 0.25
        }
    else:
        return {
            "massive": 25.0,       # 25%+
            "significant": 10.0,
            "moderate": 5.0,
            "minor": 1.0
        }


# =====================================================================
# PART 3 — BAYESIAN IMPACT SCORE ENGINE (REPLACES DETERMINISTIC)
# =====================================================================

def assess_impact_strength(
    percentage_change: float = None,
    benchmark_gap_pct: float = None,
    absolute_value: float = None,
    is_critical_metric: bool = False,
    custom_weights: Dict = None,
    auto_calculate_weights: bool = False,
    metrics_data_for_weights: List[Dict] = None,
    metric_name: Optional[str] = None,
    is_percentage_data: bool = False
) -> Dict:
    """
    Bayesian-only impact scoring engine.
    Keeps old function signature & output format so other modules remain compatible.
    """

    # Determine metric type
    is_pct = bool(is_percentage_data) or is_percentage_metric(metric_name)

    # Determine observed delta
    observed = (
        percentage_change
        if percentage_change is not None
        else benchmark_gap_pct if benchmark_gap_pct is not None
        else 0.0
    )

    # Bayesian parameters
    prior_sd = choose_prior_sd(metric_name or "metric", is_pct)
    likelihood_sd = choose_likelihood_sd(observed, is_pct)

    # Posterior distribution
    posterior_mean, posterior_sd = bayesian_update(
        observed=observed,
        observed_sd=likelihood_sd,
        prior_mean=0.0,
        prior_sd=prior_sd
    )

    # Magnitude & Impact Score
    th = thresholds_for_metric(is_pct)
    abs_mean = abs(posterior_mean)
    impact_score = min(100.0, (abs_mean / th["massive"]) * 100.0)

    if abs_mean >= th["massive"]:
        impact_magnitude = "Massive"
    elif abs_mean >= th["significant"]:
        impact_magnitude = "Significant"
    elif abs_mean >= th["moderate"]:
        impact_magnitude = "Moderate"
    elif abs_mean >= th["minor"]:
        impact_magnitude = "Minor"
    else:
        impact_magnitude = "Negligible"

    # Confidence level = signal-to-noise ratio
    if posterior_sd == 0:
        confidence_level = "Very High"
    else:
        rel = abs_mean / posterior_sd
        if rel >= 3.0:
            confidence_level = "Very High"
        elif rel >= 2.0:
            confidence_level = "High"
        elif rel >= 1.0:
            confidence_level = "Medium"
        else:
            confidence_level = "Low"

    # Return consistent schema
    return {
        "impact_score": round(impact_score, 4),
        "impact_magnitude": impact_magnitude,
        "confidence_level": confidence_level,
        "components": {
            "posterior_mean": round(posterior_mean, 4),
            "posterior_sd": round(posterior_sd, 4),
            "observed_used": observed,
            "benchmark_gap_pct": benchmark_gap_pct,
            "absolute_value": absolute_value
        },
        "data_completeness": 1.0 if (percentage_change is not None or benchmark_gap_pct is not None) else 0.0,
        "weights_used": {
            "mode": "bayesian",
            "prior_sd": prior_sd,
            "likelihood_sd": likelihood_sd
        }
    }


# =====================================================================
# PART 4 — EXTERNAL API WRAPPER (UNCHANGED SIGNATURE)
# =====================================================================

def analyze_insight_strength(
    current_value: float,
    previous_value: float = None,
    benchmark_value: float = None,
    metric_name: str = None,
    is_critical: bool = False,
    custom_weights: Dict = None,
    is_percentage_data: bool = False,
    auto_calculate_weights: bool = False,
    metrics_data_for_weights: List[Dict] = None
) -> Dict:
    """
    Computes changes then calls Bayesian impact scoring.
    """
    changes = calculate_change_magnitude(
        current_value, previous_value, benchmark_value, is_percentage_data
    )

    impact = assess_impact_strength(
        percentage_change=changes.get("percentage_change"),
        benchmark_gap_pct=changes.get("benchmark_gap_pct"),
        absolute_value=current_value,
        is_critical_metric=is_critical,
        metric_name=metric_name,
        is_percentage_data=is_percentage_data
    )

    label = format_impact_label(
        impact["impact_magnitude"],
        impact["confidence_level"],
        impact["impact_score"]
    )

    return {
        "metric_name": metric_name,
        "current_value": current_value,
        "changes": changes,
        "impact": impact,
        "formatted_label": label,
        "summary": f"{metric_name or 'Metric'}: {label}"
    }


# =====================================================================
# PART 5 — LABEL FORMATTER
# =====================================================================

def format_impact_label(impact_magnitude: str, confidence_level: str, impact_score: float = None) -> str:
    """Generates the final label string used in insights."""
    if impact_score is not None:
        return f"[{impact_magnitude} Impact • {confidence_level} Confidence • Score: {round(impact_score, 2)}]"
    else:
        return f"[{impact_magnitude} Impact • {confidence_level} Confidence]"


# =====================================================================
# PART 6 — DOCUMENTATION (UPDATED)
# =====================================================================

def get_impact_thresholds_info() -> str:
    """Documentation string for your logs or UI."""
    return """
BAYESIAN IMPACT STRENGTH ASSESSMENT — METHODOLOGY
=================================================

This engine uses a lightweight Bayesian update (Normal-Normal conjugacy) to score KPI impacts.

Key Concepts:
- Delta input:
    * Percentage metrics → percentage-point change (pp)
    * Numeric metrics → percent-change vs PY
- Priors:
    * Domain-informed SDs based on metric volatility
- Likelihood:
    * Noise model preventing overconfidence (adjusted by delta size)
- Posterior:
    * posterior_mean → effect size
    * posterior_sd → uncertainty
- Impact Score:
    * Scaled relative to "Massive" threshold (0–100)
- Magnitude:
    * Massive / Significant / Moderate / Minor / Negligible
- Confidence:
    * Based on |posterior_mean| / posterior_sd

This file is 100% drop-in compatible with previous deterministic version.
"""


