"""
Utility function to filter column_data based on columns present in a given dataframe/sheet.
This allows dynamic filtering of metadata for different data sheets.
"""

import pandas as pd
from typing import Dict, Any, Union, List
from column_data import column_data


def filter_column_data_by_sheet(
    data: Union[pd.DataFrame, List[str]], 
    column_data_dict: Dict[str, Dict[str, Any]] = None
) -> Dict[str, Dict[str, Any]]:
    """
    Filter column_data dictionary to only include columns present in the given dataframe or column list.
    
    This function is useful when you have multiple sheets with different columns and want to get
    only the metadata (definitions, formulas, descriptions) for columns that exist in a specific sheet.
    
    Args:
        data: Either a pandas DataFrame or a list of column names
        column_data_dict: Dictionary containing column metadata. 
                         If None, uses the default column_data from column_data.py
    
    Returns:
        Dictionary containing only the column metadata for columns present in the data
    
    Examples:
        >>> import pandas as pd
        >>> 
        >>> # Example 1: Filter using a DataFrame
        >>> df = pd.read_excel("data/mockup_data_all.xlsx", sheet_name="Sheet1")
        >>> filtered_metadata = filter_column_data_by_sheet(df)
        >>> print(f"Found metadata for {len(filtered_metadata)} columns")
        >>>
        >>> # Example 2: Filter using a list of column names
        >>> columns = ["Fraud Rate", "Decline Rate", "Authorization Rate"]
        >>> filtered_metadata = filter_column_data_by_sheet(columns)
        >>>
        >>> # Example 3: Use with custom column_data dictionary
        >>> custom_data = {"Metric1": {...}, "Metric2": {...}}
        >>> filtered = filter_column_data_by_sheet(df, column_data_dict=custom_data)
    """
    # Use default column_data if none provided
    if column_data_dict is None:
        column_data_dict = column_data
    
    # Extract column names from the data
    if isinstance(data, pd.DataFrame):
        data_columns = set(data.columns)
    elif isinstance(data, list):
        data_columns = set(data)
    else:
        raise ValueError("data must be either a pandas DataFrame or a list of column names")
    
    # Create a mapping of stripped column names to original names for matching
    # This handles cases where data columns have leading/trailing whitespace
    stripped_to_original = {col.strip(): col for col in data_columns}
    
    # Filter column_data to only include columns present in the data
    # Match using both exact names and stripped names for robust matching
    filtered_data = {
        col_name: col_info
        for col_name, col_info in column_data_dict.items()
        if col_name in data_columns or col_name in stripped_to_original
    }
    
    return filtered_data


def get_missing_columns(
    data: Union[pd.DataFrame, List[str]], 
    column_data_dict: Dict[str, Dict[str, Any]] = None
) -> List[str]:
    """
    Get list of columns in the data that don't have metadata in column_data.
    
    Useful for identifying columns that may need metadata definitions added.
    
    Args:
        data: Either a pandas DataFrame or a list of column names
        column_data_dict: Dictionary containing column metadata.
                         If None, uses the default column_data from column_data.py
    
    Returns:
        List of column names that exist in data but not in column_data_dict
    
    Example:
        >>> df = pd.read_excel("data/mockup_data_all.xlsx", sheet_name="Sheet1")
        >>> missing = get_missing_columns(df)
        >>> if missing:
        ...     print(f"Columns without metadata: {missing}")
    """
    if column_data_dict is None:
        column_data_dict = column_data
    
    # Extract column names from the data
    if isinstance(data, pd.DataFrame):
        data_columns = set(data.columns)
    elif isinstance(data, list):
        data_columns = set(data)
    else:
        raise ValueError("data must be either a pandas DataFrame or a list of column names")
    
    # Find columns in data but not in column_data
    metadata_columns = set(column_data_dict.keys())
    missing_columns = data_columns - metadata_columns
    
    return sorted(list(missing_columns))


def get_available_columns(
    data: Union[pd.DataFrame, List[str]], 
    column_data_dict: Dict[str, Dict[str, Any]] = None
) -> List[str]:
    """
    Get list of columns that exist in both the data and column_data (have metadata).
    
    Args:
        data: Either a pandas DataFrame or a list of column names
        column_data_dict: Dictionary containing column metadata.
                         If None, uses the default column_data from column_data.py
    
    Returns:
        List of column names that have metadata available
    
    Example:
        >>> df = pd.read_excel("data/mockup_data_all.xlsx", sheet_name="Sheet1")
        >>> available = get_available_columns(df)
        >>> print(f"Columns with metadata: {len(available)}")
    """
    filtered = filter_column_data_by_sheet(data, column_data_dict)
    return sorted(list(filtered.keys()))


def print_column_summary(
    data: Union[pd.DataFrame, List[str]], 
    column_data_dict: Dict[str, Dict[str, Any]] = None
) -> None:
    """
    Print a summary of columns, showing which have metadata and which don't.
    
    Args:
        data: Either a pandas DataFrame or a list of column names
        column_data_dict: Dictionary containing column metadata.
                         If None, uses the default column_data from column_data.py
    
    Example:
        >>> df = pd.read_excel("data/mockup_data_all.xlsx", sheet_name="Sheet1")
        >>> print_column_summary(df)
    """
    if isinstance(data, pd.DataFrame):
        total_columns = len(data.columns)
        data_type = "DataFrame"
    else:
        total_columns = len(data)
        data_type = "Column List"
    
    available = get_available_columns(data, column_data_dict)
    missing = get_missing_columns(data, column_data_dict)
    
    print(f"\n{'='*70}")
    print(f"COLUMN SUMMARY FOR {data_type}")
    print(f"{'='*70}")
    print(f"Total columns: {total_columns}")
    print(f"Columns with metadata: {len(available)}")
    print(f"Columns without metadata: {len(missing)}")
    print(f"{'='*70}\n")
    
    if available:
        print(f"✓ Columns with metadata ({len(available)}):")
        for i, col in enumerate(available, 1):
            print(f"  {i}. {col}")
    
    if missing:
        print(f"\n✗ Columns without metadata ({len(missing)}):")
        for i, col in enumerate(missing, 1):
            print(f"  {i}. {col}")
    
    print(f"\n{'='*70}\n")


def get_column_metadata_as_string(
    data: Union[pd.DataFrame, List[str]], 
    column_data_dict: Dict[str, Dict[str, Any]] = None
) -> str:
    """
    Get filtered column metadata as a formatted string for LLM prompts.
    
    This is particularly useful for passing context to language models about
    only the relevant columns in a specific sheet.
    
    Args:
        data: Either a pandas DataFrame or a list of column names
        column_data_dict: Dictionary containing column metadata.
                         If None, uses the default column_data from column_data.py
    
    Returns:
        Formatted string with column metadata
    
    Example:
        >>> df = pd.read_excel("data/mockup_data_all.xlsx", sheet_name="Sheet1")
        >>> metadata_str = get_column_metadata_as_string(df)
        >>> # Use in LLM prompt
        >>> prompt = f"Given these metrics:\n{metadata_str}\n\nAnalyze..."
    """
    filtered = filter_column_data_by_sheet(data, column_data_dict)
    
    if not filtered:
        return "No column metadata available for the provided data."
    
    result = []
    for col_name, col_info in filtered.items():
        result.append(f"\n{col_name}:")
        for key, value in col_info.items():
            result.append(f"  {key}: {value}")
    
    return "\n".join(result)


if __name__ == "__main__":
    # Example usage
    print("\n" + "="*70)
    print("FILTER COLUMN DATA - USAGE EXAMPLES")
    print("="*70 + "\n")
    
    # Example 1: Using with a list of columns
    print("Example 1: Filtering with a column list")
    print("-" * 70)
    sample_columns = [
        "Fraud Rate", 
        "Decline Rate", 
        "Authorization Rate",
        "Spend Per Active Card",
        "Unknown Column"  # This one doesn't exist in column_data
    ]
    
    filtered = filter_column_data_by_sheet(sample_columns)
    print(f"Input columns: {len(sample_columns)}")
    print(f"Filtered metadata entries: {len(filtered)}")
    print(f"Columns with metadata: {list(filtered.keys())}")
    
    missing = get_missing_columns(sample_columns)
    print(f"Missing metadata for: {missing}")
    
    # Example 2: Print summary
    print("\n\nExample 2: Column Summary")
    print("-" * 70)
    print_column_summary(sample_columns)
    
    # Example 3: Get metadata as string
    print("\n\nExample 3: Metadata as String (for LLM prompts)")
    print("-" * 70)
    metadata_str = get_column_metadata_as_string(["Fraud Rate", "Decline Rate"])
    print(metadata_str)
    
    # Example 4: Load from Excel (if file exists)
    print("\n\nExample 4: Loading from Excel file")
    print("-" * 70)
    try:
        import os
        excel_path = "data/mockup_data_all.xlsx"
        if os.path.exists(excel_path):
            excel_file = pd.ExcelFile(excel_path)
            print(f"Available sheets: {excel_file.sheet_names}")
            
            # Load first sheet
            df = pd.read_excel(excel_path, sheet_name=excel_file.sheet_names[0])
            print(f"\nAnalyzing sheet: {excel_file.sheet_names[0]}")
            print_column_summary(df)
            
            filtered = filter_column_data_by_sheet(df)
            print(f"\nFiltered column_data contains {len(filtered)} entries")
        else:
            print(f"Excel file not found at: {excel_path}")
    except Exception as e:
        print(f"Could not load Excel file: {e}")
    
    print("\n" + "="*70 + "\n")
