"""
Utility script to generate field relationships analysis once and save to file.
Run this script whenever column_data.py is updated to regenerate field_relations.txt
"""

import os
import json
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
import httpx
from column_data import column_data
from filter_column_data import filter_column_data_by_sheet

os.environ['OPENAI_API_KEY'] = "private_key"

# Initialize the LLMs
httpx_client = httpx.Client(http2=True, verify=False)
llm = ChatOpenAI(model="gpt-4o", temperature=0, http_client = httpx_client)


def generate_field_relations(filtered_column_data: dict = None) -> str:
    """
    Generate comprehensive field relationships analysis from column_data.
    
    Args:
        filtered_column_data: Optional filtered column data dictionary. If None, uses full column_data.
    
    Returns:
        str: Detailed analysis of how all fields relate to each other
    """
    data_to_use = filtered_column_data if filtered_column_data is not None else column_data
    column_data_str = json.dumps(data_to_use, indent=2)
    
    system_prompt = """You are an expert data analyst and financial metrics specialist with deep expertise in:
    - Credit card portfolio management and KPI relationships
    - Statistical correlation and causation analysis
    - Financial metrics interdependencies
    - Customer engagement and retention patterns

    Your task is to create a COMPREHENSIVE, ACCURATE field relationship analysis that will be used by an AI agent to answer user queries about metric relationships."""
    
    user_prompt = f"""# Field Definitions:
    {column_data_str}

    # Task: Create a Comprehensive Field Relationship Analysis

    Analyze EVERY field and document its relationships with other relevant fields from the list ONLY. Be mathematically precise and business-logic focused.

    ## Required Analysis Structure:

    For EACH field, provide:

    ### 1. DIRECTLY PROPORTIONAL Relationships
    - List fields from the metrics that increase when this field increases
    - Explain the mathematical or logical reason (use formulas when available)
    - Include numerical examples when possible
    - Only list fields that are in the Field Definitions above

    ### 2. INVERSELY PROPORTIONAL Relationships
    - List fields from the metrics that decrease when this field increases
    - Explain WHY they are inversely related (use formulas and business logic)
    - Include numerical examples when possible
    - Only list fields that are in the Field Definitions above

    ### 3. CAUSAL RELATIONSHIPS (Cause → Effect)
    - What this field CAUSES (downstream effects on other metrics)
    - What CAUSES this field (upstream drivers from other metrics)
    - Only include relationships with fields from the metrics listed above
    - Distinguish between direct causation vs correlation

    ### 4. DERIVED/CALCULATED Relationships
    - If this field is calculated from others, show the EXACT formula
    - Break down each component of the formula
    - Explain how changes in components affect this field

    ## Critical Requirements:

    1. **ONLY USE FIELDS FROM THE PROVIDED METRICS**: Do NOT introduce any fields, metrics, or concepts that are not explicitly listed in the Field Definitions above
    2. **Mathematical Accuracy**: Use actual formulas from the definitions
    3. **Bidirectional Analysis**: If A affects B, also mention B's relationship to A
    4. **Business Context**: Explain the business meaning of each relationship
    5. **Completeness**: Cover ALL fields in detail
    6. **Consistency**: Ensure relationships are symmetric (if A→B is direct, B→A should reflect this)
    7. **Real-World Examples**: Where possible, give numerical examples
    8. **No External References**: Do not mention fields like "Overall Amount", "Overall Card Count", "Customer engagement", etc. unless they are in the provided metrics

    ## Example of GOOD Analysis:

    **Spend per Active Card**
    - **Formula**: Overall amount / Overall card count
    
    - **Directly Proportional Relationships**:
      * Transaction per Active Card: More transactions typically lead to higher spend (if avg transaction value is constant, 2x transactions = 2x spend)
      * Authorization Rate: Higher auth rate allows more transactions to complete, increasing spend (e.g., 95% vs 90% auth rate = 5.6% more completed transactions)
    
    - **Inversely Proportional Relationships**:
      * Disengagement Rate: Disengaged cards contribute $0 spend, pulling average down (e.g., 15% disengagement vs 10% = lower average spend)
      * Decline Rate: Higher declines = fewer completed transactions = less spend
    
    - **Causal Relationships**:
      * Causes: Higher spend influences customer retention decisions
      * Caused by: Authorization Rate (more approved transactions), Transaction per Active Card (more activity)

    ## Fields to Analyze (USE ONLY THESE FIELDS):
    {chr(10).join(f"{i}. {field}" for i, field in enumerate(data_to_use.keys(), 1))}

    **IMPORTANT**: Only reference relationships between these {len(data_to_use)} fields. Do not introduce any other metrics, intermediate variables, or external factors.

    Provide your analysis in a clear, structured format that can be easily referenced."""
    
    messages = [
        SystemMessage(content=system_prompt),
        HumanMessage(content=user_prompt)
    ]
    
    print("Generating field relationships analysis...")
    response = llm.invoke(messages)
    field_relations = response.content
    
    return field_relations


def verify_and_clean_field_relations(field_relations: str, filtered_column_data: dict = None) -> tuple[str, dict]:
    """
    Verify field relationships and identify/remove unwanted or invalid relationships.
    
    Args:
        field_relations: The generated relationship analysis
        filtered_column_data: Optional filtered column data dictionary. If None, uses full column_data.
        
    Returns:
        tuple: (cleaned_field_relations, verification_report)
    """
    data_to_use = filtered_column_data if filtered_column_data is not None else column_data
    column_data_str = json.dumps(data_to_use, indent=2)
    
    verification_prompt = f"""# Task: Verify and Clean Field Relationships - Keep Only Strong and Moderate Relationships

    ## Original Field Definitions:
    {column_data_str}

    ## Generated Field Relationship Analysis:
    {field_relations}

    ## Relationship Classification Criteria:

    ### STRONG Relationships (KEEP):
    1. **Formula Dependency**: One field explicitly appears in another's formula
       - Example: Authorization Rate appears in calculation of other metrics
       - Example: Avg MCG Count >= 14 determines Tow Card%
    2. **Direct Mechanism**: Clear 1:1 mechanical link with mathematical proof
       - Example: Authorization Rate + Decline Rate + Other = 100% (complementary)
       - Example: Higher Authorization Rate → More completed transactions → Higher Spend
    3. **Denominator/Numerator Impact**: Field affects calculation by changing numerator or denominator
       - Example: New Active Card % increases denominator, dilutes per-card averages
       - Example: Disengagement Rate reduces active card count, affects denominators

    ### MODERATE Relationships (KEEP if business logic is sound):
    1. **Indirect Mathematical Link**: 2-step logical connection with quantifiable impact
       - Example: 3 Month Purchase Active Rate → More active cards → Higher transaction counts
       - Must explain: "If X increases 10%, then Y increases by ~Z% because [mathematical reason]"
    2. **Strong Business Logic**: Clear operational mechanism in credit card industry
       - Example: Higher fraud rate → Stricter controls → Higher decline rate
       - Example: Higher engagement (3M Active) → More transactions → Higher spend
       - Must be a well-established business pattern, not speculation
    3. **Bidirectional Consistency**: If A affects B strongly, B's inverse relationship to A is moderate
       - Example: Disengagement Rate ↔ Transaction per Active Card (inverse relationship both ways)

    ### WEAK Relationships (REMOVE):
    1. **Pure Correlation**: No mathematical or mechanical link
       - Example: Avg MCG Count ↔ Disengagement Rate (just correlation, no formula link)
       - Example: Tow Card% → Spend per Active Card (speculative, indirect)
    2. **Speculative**: "May", "might", "could potentially" without clear mechanism
       - Example: "New cards may explore categories" (too vague)
    3. **Contradictory Logic**: Relationship goes against mathematical formulas
       - Example: New Active Card % → Higher Spend per Active Card (WRONG - dilutes average)
    4. **External Fields**: References fields not in the 10 KPIs
    5. **Multi-step Indirect**: Requires 3+ steps with weak links

    ## Output Format (JSON):

    {{
    "weak_relationships_removed": [
        {{
            "field": "field name",
            "relationship_type": "directly proportional/inversely proportional/causal",
            "related_field": "related field name",
            "strength": "weak",
            "reason": "why it's weak and should be removed"
        }}
    ],
    "moderate_relationships_kept": [
        {{
            "field": "field name",
            "relationship_type": "directly proportional/inversely proportional/causal",
            "related_field": "related field name",
            "strength": "moderate",
            "business_logic": "explain the business logic that validates this moderate relationship"
        }}
    ],
    "strong_relationships_kept": [
        {{
            "field": "field name",
            "related_field": "related field name",
            "strength": "strong",
            "reason": "formula dependency / direct mechanism / denominator impact"
        }}
    ],
    "external_fields_used": ["list of non-KPI fields that should be removed"],
    "cleaned_analysis": "The full field relationship analysis with ONLY strong and moderate relationships. Remove all weak relationships. For moderate relationships, ensure business logic is clearly explained. Maintain the exact same structure and format.",
    "total_weak_relationships_removed": <number>,
    "total_moderate_relationships_kept": <number>,
    "total_strong_relationships_kept": <number>,
    "summary": "Brief summary of cleaning: X weak removed, Y moderate kept with business logic, Z strong kept"
    }}

    Provide ONLY the JSON output."""
    
    messages = [
        SystemMessage(content="You are an expert at validating data relationships and removing invalid connections."),
        HumanMessage(content=verification_prompt)
    ]
    
    print("\nVerifying and cleaning field relationships...")
    response = llm.invoke(messages)
    
    # Parse JSON response
    try:
        content = response.content.strip()
        if content.startswith("```json"):
            content = content.split("```json")[1].split("```")[0].strip()
        elif content.startswith("```"):
            content = content.split("```")[1].split("```")[0].strip()
        
        verification_result = json.loads(content)
        cleaned_relations = verification_result.get("cleaned_analysis", field_relations)
        
        # Create report
        report = {
            "invalid_count": verification_result.get("total_weak_relationships_removed", 0),
            "strong_count": verification_result.get("total_strong_relationships_kept", 0),
            "moderate_count": verification_result.get("total_moderate_relationships_kept", 0),
            "invalid_relationships": verification_result.get("weak_relationships_removed", []),
            "moderate_relationships": verification_result.get("moderate_relationships_kept", []),
            "strong_relationships": verification_result.get("strong_relationships_kept", []),
            "external_fields": verification_result.get("external_fields_used", []),
            "summary": verification_result.get("summary", "")
        }
        
        return cleaned_relations, report
        
    except Exception as e:
        print(f"Warning: Could not parse verification response: {e}")
        return field_relations, {
            "invalid_count": 0,
            "error": str(e),
            "summary": "Verification failed, using original analysis"
        }


def evaluate_field_relations(field_relations: str, filtered_column_data: dict = None) -> dict:
    """
    Evaluate the quality and completeness of generated field relationships.
    
    Args:
        field_relations: The generated relationship analysis
        filtered_column_data: Optional filtered column data dictionary. If None, uses full column_data.
        
    Returns:
        dict: Evaluation results with score, feedback, and pass/fail status
    """
    data_to_use = filtered_column_data if filtered_column_data is not None else column_data
    column_data_str = json.dumps(data_to_use, indent=2)
    
    evaluation_prompt = f"""# Task: Evaluate Field Relationship Analysis Quality

    ## Original Field Definitions:
    {column_data_str}

    ## Generated Field Relationship Analysis:
    {field_relations}

    ## Evaluation Criteria:

    Evaluate the analysis on these dimensions (score each 0-10):

    1. **Completeness (0-10)**
    - Are all 10 fields covered?
    - Are all relationship types addressed (direct, inverse, causal, derived)?
    - Missing any obvious relationships between the 10 KPIs?
    - Are only the 10 KPIs referenced (no external fields introduced)?

    2. **Mathematical Accuracy (0-10)**
    - Are formulas correctly referenced?
    - Are mathematical relationships logically sound?
    - Any contradictions in the relationships?
    - Are numerical examples accurate?

    3. **Business Logic Accuracy (0-10)**
    - Do the relationships make sense for credit card metrics?
    - Are causal relationships properly identified?
    - Any illogical connections?
    - Are only the 10 KPIs from column_data referenced?

    4. **Bidirectional Consistency (0-10)**
    - If A is directly proportional to B, is B to A consistent?
    - Are inverse relationships symmetric?
    - Any inconsistencies in mutual relationships?

    5. **Specificity & Detail (0-10)**
    - Are relationships explained with reasoning?
    - Enough detail for an AI agent to use?
    - Are numerical examples provided where helpful?

    6. **Usability for Query Answering (0-10)**
    - Can this analysis answer "what happens if X increases?"
    - Can this identify which metrics affect others?
    - Is it structured for easy lookup?
    - Are relationships actionable and useful?

    ## Required Output Format (JSON):

    {{
    "completeness_score": <0-10>,
    "mathematical_accuracy_score": <0-10>,
    "business_logic_score": <0-10>,
    "consistency_score": <0-10>,
    "specificity_score": <0-10>,
    "usability_score": <0-10>,
    "overall_score": <average of above>,
    "pass": <true if overall_score >= 7.5, else false>,
    "only_10_kpis_used": <true if only the 10 KPIs are referenced, false if external fields introduced>,
    "external_fields_found": ["list of any external fields/metrics that should not be there"],
    "strengths": ["list", "of", "strengths"],
    "weaknesses": ["list", "of", "issues"],
    "missing_relationships": ["specific relationships not covered"],
    "contradictions": ["any", "logical", "contradictions"],
    "improvement_suggestions": ["specific", "actionable", "suggestions"]
    }}

    Provide ONLY the JSON output, no additional text."""
    
    messages = [
        SystemMessage(content="You are an expert evaluator of data analysis quality. Provide objective, detailed assessments."),
        HumanMessage(content=evaluation_prompt)
    ]
    
    print("\nEvaluating field relationships quality...")
    response = llm.invoke(messages)
    
    # Parse JSON response
    try:
        # Extract JSON from response (handle markdown code blocks)
        content = response.content.strip()
        if content.startswith("```json"):
            content = content.split("```json")[1].split("```")[0].strip()
        elif content.startswith("```"):
            content = content.split("```")[1].split("```")[0].strip()
        
        evaluation = json.loads(content)
        return evaluation
    except Exception as e:
        print(f"Warning: Could not parse evaluation response: {e}")
        return {
            "overall_score": 5.0,
            "pass": False,
            "error": str(e),
            "raw_response": response.content
        }


def validate_field_relations(field_relations: str, filtered_column_data: dict = None) -> bool:
    """
    Validate that field relationships contain all required fields.
    
    Args:
        field_relations: The generated relationship analysis
        filtered_column_data: Optional filtered column data dictionary. If None, uses full column_data.
        
    Returns:
        bool: True if validation passes
    """
    data_to_use = filtered_column_data if filtered_column_data is not None else column_data
    required_fields = list(data_to_use.keys())
    
    missing_fields = []
    for field in required_fields:
        if field not in field_relations:
            missing_fields.append(field)
    
    if missing_fields:
        print(f"❌ Validation Failed: Missing fields: {', '.join(missing_fields)}")
        return False
    
    # Check for key relationship terms
    key_terms = ["proportional", "inverse", "causal", "formula", "relationship"]
    terms_found = sum(1 for term in key_terms if term.lower() in field_relations.lower())
    
    if terms_found < 3:
        print(f"❌ Validation Failed: Missing key relationship terminology")
        return False
    
    print("✓ Basic validation passed")
    return True


def save_field_relations(field_relations: str, output_file: str = "field_relations.txt"):
    """
    Save field relationships to a text file.
    
    Args:
        field_relations: The relationship analysis text
        output_file: Path to output file
    """
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(field_relations)
    print(f"✓ Field relationships saved to {output_file}")


def main(filtered_column_data: dict = None, data_name: str = None):
    """
    Main function to generate field relationships.
    
    Args:
        filtered_column_data: Optional filtered column data dictionary. If None, uses full column_data.
        data_name: Optional name to append to output file (e.g., 'sheet1' -> 'field_relations_sheet1.txt')
    """
    print("="*80)
    print("Generating Field Relationships Analysis with Evaluation")
    if data_name:
        print(f"Data Name: {data_name}")
    print("="*80)
    
    max_attempts = 2
    best_relations = None
    best_score = 0
    
    for attempt in range(1, max_attempts + 1):
        print(f"\n{'='*80}")
        print(f"Attempt {attempt}/{max_attempts}")
        print(f"{'='*80}")
        
        # Generate relationships
        field_relations = generate_field_relations(filtered_column_data)
        
        # Verify and clean relationships
        cleaned_relations, verification_report = verify_and_clean_field_relations(field_relations, filtered_column_data)
        
        # Display verification results
        print("\n" + "="*80)
        print("VERIFICATION RESULTS:")
        print("="*80)
        print(f"Weak relationships removed: {verification_report.get('invalid_count', 0)}")
        print(f"Strong relationships kept: {verification_report.get('strong_count', 0)}")
        print(f"Moderate relationships kept: {verification_report.get('moderate_count', 0)}")
        
        if verification_report.get('invalid_relationships'):
            print(f"\n🗑️  Weak Relationships Removed:")
            for inv_rel in verification_report['invalid_relationships'][:5]:
                print(f"  • {inv_rel.get('field', 'Unknown')} → {inv_rel.get('invalid_relation_with', 'Unknown')}")
                print(f"    Reason: {inv_rel.get('reason', 'No reason provided')}")
        
        if verification_report.get('moderate_relationships'):
            print(f"\n✓ Moderate Relationships Kept (with business logic):")
            for mod_rel in verification_report['moderate_relationships'][:5]:
                print(f"  • {mod_rel.get('field', 'Unknown')} ↔ {mod_rel.get('related_field', 'Unknown')}")
                print(f"    Logic: {mod_rel.get('business_logic', 'No logic provided')[:100]}...")
        
        if verification_report.get('external_fields'):
            print(f"\n⚠️  External Fields Removed:")
            for ext_field in verification_report['external_fields'][:5]:
                print(f"  • {ext_field}")
        
        if verification_report.get('summary'):
            print(f"\n📋 Summary: {verification_report['summary']}")
        
        print("="*80)
        
        # Use cleaned relations for further processing
        field_relations = cleaned_relations
        
        # Validate basic requirements (allow continuation if validation fails on last attempt)
        validation_passed = validate_field_relations(field_relations, filtered_column_data)
        if not validation_passed and attempt < max_attempts:
            print(f"⚠️  Attempt {attempt} failed basic validation, retrying...")
            continue
        elif not validation_passed and attempt == max_attempts:
            print(f"⚠️  Attempt {attempt} failed basic validation, but using best available result")
        
        # Evaluate quality
        evaluation = evaluate_field_relations(field_relations, filtered_column_data)
        
        # Display evaluation results
        print("\n" + "="*80)
        print("EVALUATION RESULTS:")
        print("="*80)
        print(f"Overall Score: {evaluation.get('overall_score', 0):.1f}/10")
        print(f"Status: {'✓ PASS' if evaluation.get('pass', False) else '✗ NEEDS IMPROVEMENT'}")
        print(f"\nDetailed Scores:")
        print(f"  - Completeness: {evaluation.get('completeness_score', 0)}/10")
        print(f"  - Mathematical Accuracy: {evaluation.get('mathematical_accuracy_score', 0)}/10")
        print(f"  - Business Logic: {evaluation.get('business_logic_score', 0)}/10")
        print(f"  - Consistency: {evaluation.get('consistency_score', 0)}/10")
        print(f"  - Specificity: {evaluation.get('specificity_score', 0)}/10")
        print(f"  - Usability: {evaluation.get('usability_score', 0)}/10")
        
        if evaluation.get('strengths'):
            print(f"\n✓ Strengths:")
            for strength in evaluation['strengths'][:3]:
                print(f"  • {strength}")
        
        if evaluation.get('weaknesses'):
            print(f"\n⚠️  Weaknesses:")
            for weakness in evaluation['weaknesses'][:3]:
                print(f"  • {weakness}")
        
        if evaluation.get('missing_relationships'):
            print(f"\n❌ Missing Relationships:")
            for missing in evaluation['missing_relationships'][:3]:
                print(f"  • {missing}")
        
        print("="*80)
        
        # Track best result
        current_score = evaluation.get('overall_score', 0)
        if current_score > best_score:
            best_score = current_score
            best_relations = field_relations
        
        # If passing score, accept it
        if evaluation.get('pass', False):
            print(f"\n✓ Attempt {attempt} passed with score {current_score:.1f}/10")
            break
        else:
            print(f"\n⚠️  Attempt {attempt} scored {current_score:.1f}/10 (needs >= 7.5 to pass)")
            if attempt < max_attempts:
                print(f"Retrying with improved prompt...")
    
    # Use best result
    if best_relations:
        # Display preview
        print("\n" + "="*80)
        print("FIELD RELATIONSHIPS ANALYSIS (Preview - First 1000 chars):")
        print("="*80)
        print(best_relations[:1000] + "..." if len(best_relations) > 1000 else best_relations)
        print("="*80 + "\n")
        
        # Save to file with data name suffix
        output_filename = f"field_relations_{data_name}.txt" if data_name else "field_relations.txt"
        save_field_relations(best_relations, output_filename)
        
        print(f"\n✓ Complete! Best score achieved: {best_score:.1f}/10")
        print(f"  The {output_filename} file can now be used by the insight agent.")
        print("  Run this script again whenever you update column_data.py")
        
        if best_score < 7.5:
            print(f"\n⚠️  Warning: Score below passing threshold (7.5). Consider:")
            print("     - Reviewing the generated relationships manually")
            print("     - Running the script again for a different generation")
            print("     - Updating the prompt if patterns of issues emerge")
    else:
        print("\n❌ Failed to generate valid field relationships")
        print("   Please check the prompts and try again")


if __name__ == "__main__":
    main()
