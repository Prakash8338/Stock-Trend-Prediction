column_data = {
    "New Active Card Percentage": {
        "definition": "What were the newly acquired cards in the year",
        "direction": "Higher is better",
        "formula": "Newly Acquired card count / Overall card count",
        "description": "Measures the percentage of newly acquired cards. High New Active Card Percentage indicates good customer acquisition.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "3 Month Purchase Active Rate": {
        "definition": "How many cards are active in last 3 months",
        "direction": "Higher is better",
        "formula": "3-month active card count / Overall card count",
        "description": "Measures card engagement over the last 3 months. High 3 Month Purchase Active Rate indicates strong card usage and customer engagement.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "Spend Per Active Card": {
        "definition": "What is the average spend of cards",
        "direction": "Higher is better",
        "formula": "Overall amount / Overall card count",
        "description": "Average spending per card. High Spend Per Active Card indicates higher transaction values and better monetization.",
        "data_type": "currency",
        "unit": "$"
    },
    
    "Transaction Per Active Card": {
        "definition": "What is the average transactions of cards",
        "direction": "Higher is better",
        "formula": "Overall transaction count / Overall card count",
        "description": "Average number of transactions per card. High Transaction Per Active Card indicates frequent card usage.",
        "data_type": "count",
        "unit": "transactions"
    },
    
    "Avg MCG Count": {
        "definition": "What is the average merchant counts of cards",
        "direction": "Higher is better",
        "formula": "Calculate MCG (Merchant Category Group) count at PAN level and then take average",
        "description": "Average number of merchant categories where cards are used. High Avg MCG Count indicates diverse card usage across different merchants.",
        "data_type": "count",
        "unit": "categories"
    },
    
    "Tow Card %": {
        "definition": "What are the average top of wallet card percentage",
        "direction": "Higher is better",
        "formula": "If MCG Count >= 14 then card is top of wallet, otherwise not. Calculate percentage of top of wallet cards.",
        "description": "Percentage of cards that are 'Top of Wallet' (primary spending cards). High Tow Card % means the card is the customer's preferred payment method.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "Disengagement Rate": {
        "definition": "Percentage of cards stopped transacting in the year",
        "direction": "Lower is better",
        "formula": "Number of inactive cards / Overall card count",
        "description": "Measures card attrition and disengagement. Low Disengagement Rate is good, indicating high customer retention.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "Authorization Rate": {
        "definition": "Percentage of transactions getting authorized",
        "direction": "Higher is better",
        "formula": "Number of Authorized Transactions / Overall transactions",
        "description": "Percentage of successfully authorized transactions. High Authorization Rate indicates smooth transaction processing and good fraud controls.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "Fraud Rate": {
        "definition": "Rate of transactions tagged as fraudulent",
        "direction": "Lower is better",
        "formula": "(Fraud Amount / Authorized Amount) × 10000 (calculated in BPS - basis points)",
        "description": "Fraud rate measured in basis points (BPS). Low Fraud Rate is better, indicating effective fraud prevention and security.",
        "data_type": "percentage",
        "unit": "bps"
    },
    
    "Decline Rate": {
        "definition": "Percentage of transactions getting declined",
        "direction": "Lower is better",
        "formula": "Number of Declined Transactions / Overall transactions",
        "description": "Percentage of declined transactions. Low Decline Rate is better, as it indicates fewer payment failures and better customer experience.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "Interchange Rate": {
        "definition": "Interchange rate charged on transactions",
        "direction": "Context dependent",
        "formula": "Interchange fees / Transaction volume",
        "description": "Interchange rate as a percentage of transaction volume.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "KPI_Relationships": {
        "engagement_metrics": "New Active Card Percentage, 3 Month Purchase Active Rate, Transaction per Active Card, and Avg MCG Count all measure card engagement. Higher engagement typically leads to higher Spend per Active Card.",
        "top_of_wallet": "Tow Card% is influenced by Avg MCG Count (>=14 MCG categories makes a card top of wallet) and 3 Month Purchase Active Rate.",
        "negative_indicators": "Disengagement Rate negatively impacts all positive metrics. High Disengagement Rate leads to lower transaction volumes and spend.",
        "transaction_health": "Authorization Rate and Decline Rate are inversely related. High Decline Rate may indicate fraud prevention being too aggressive or technical issues.",
        "fraud_impact": "Fraud Rate affects Authorization Rate and customer trust. High Fraud Rate may lead to stricter controls, potentially increasing Decline Rate.",
        "spend_drivers": "Spend per Active Card is driven by Transaction per Active Card, Authorization Rate, and Avg MCG Count (diverse spending patterns)."
    },
    
    # Data 2 Metrics - New Card Acquisition
    "New Active Card Spend Growth": {
        "definition": "Year-over-year growth rate in spending by newly acquired cards",
        "direction": "Higher is better",
        "formula": "((Current Year New Card Spend - Previous Year New Card Spend) / Previous Year New Card Spend) × 100",
        "description": "Measures the growth in spending from newly acquired cards. High growth indicates successful new customer activation and engagement.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "Active Card Growth Rate": {
        "definition": "Year-over-year growth rate in the number of active cards",
        "direction": "Higher is better",
        "formula": "((Current Year Active Cards - Previous Year Active Cards) / Previous Year Active Cards) × 100",
        "description": "Measures the portfolio expansion through new active cards. High growth rate indicates strong customer acquisition and retention.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "Percentage of New Millennial Cards": {
        "definition": "Proportion of newly acquired cards belonging to millennial customers",
        "direction": "Context dependent",
        "formula": "(New Millennial Cards / Total New Cards) × 100",
        "description": "Measures the acquisition success in the millennial demographic segment. Important for understanding target market penetration.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "Spend per New Active Card": {
        "definition": "Average spending amount per newly acquired active card",
        "direction": "Higher is better",
        "formula": "Total New Card Spend / Number of New Active Cards",
        "description": "Measures the monetization of newly acquired customers. High spend per new card indicates effective new customer engagement.",
        "data_type": "currency",
        "unit": "$"
    },
    
    # Data 3 Metrics - Existing Card Performance
    "Existing Card Spend Growth": {
        "definition": "Year-over-year growth rate in spending by existing cards",
        "direction": "Higher is better",
        "formula": "((Current Year Existing Card Spend - Previous Year Existing Card Spend) / Previous Year Existing Card Spend) × 100",
        "description": "Measures the spending growth from the existing customer base. High growth indicates strong customer retention and increased engagement.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "Percentage Top-of-Wallet": {
        "definition": "Proportion of cards that are customers' primary spending cards",
        "direction": "Higher is better",
        "formula": "(Number of Top-of-Wallet Cards / Total Active Cards) × 100",
        "description": "Measures the share of cards that are the primary payment method for customers. High percentage indicates strong customer loyalty and preference.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "Top-of-Wallet Spend per Active Card": {
        "definition": "Average spending amount per top-of-wallet card",
        "direction": "Higher is better",
        "formula": "Total Top-of-Wallet Spend / Number of Top-of-Wallet Cards",
        "description": "Measures the value generated from primary cards. High spend indicates strong card usage by loyal customers.",
        "data_type": "currency",
        "unit": "$"
    },
    
    "Percentage of Millennial Cards": {
        "definition": "Proportion of total active cards belonging to millennial customers",
        "direction": "Context dependent",
        "formula": "(Millennial Cards / Total Active Cards) × 100",
        "description": "Measures the millennial segment's representation in the active card portfolio. Important for demographic strategy assessment.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    # Data 4 Metrics - Digital and Cross-Border Spending
    "Percentage Digital Spend": {
        "definition": "Proportion of total spending conducted through digital channels",
        "direction": "Context dependent",
        "formula": "(Digital Channel Spend / Total Spend) × 100",
        "description": "Measures digital channel adoption. Higher percentage indicates modernization and digital transformation success.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "Digital Spend per Active Card": {
        "definition": "Average digital channel spending per active card",
        "direction": "Higher is better",
        "formula": "Total Digital Spend / Number of Active Cards",
        "description": "Measures the average value of digital transactions per card. High value indicates strong digital engagement.",
        "data_type": "currency",
        "unit": "$"
    },
    
    "Percentage of Card Not Present Spend": {
        "definition": "Proportion of spending from card-not-present (CNP) transactions",
        "direction": "Context dependent",
        "formula": "(CNP Spend / Total Spend) × 100",
        "description": "Measures online and remote transaction volume. Higher percentage indicates e-commerce adoption but may require stronger fraud controls.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "Percentage of Contactless Spend out of CP Transactions": {
        "definition": "Proportion of card-present transactions using contactless payment",
        "direction": "Higher is better",
        "formula": "(Contactless CP Spend / Total Card Present Spend) × 100",
        "description": "Measures contactless payment adoption for in-person transactions. High percentage indicates modern payment technology adoption.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "Percentage of Cross Border Spend": {
        "definition": "Proportion of spending on cross-border transactions",
        "direction": "Context dependent",
        "formula": "(Cross Border Spend / Total Spend) × 100",
        "description": "Measures international usage of cards. Higher percentage indicates global card acceptance and international customer activity.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "Merchant Category Groups per Active Card": {
        "definition": "Average number of different merchant categories where cards are used",
        "direction": "Higher is better",
        "formula": "Total Merchant Category Groups / Number of Active Cards",
        "description": "Measures spending diversity across merchant categories. High count indicates versatile card usage and customer engagement.",
        "data_type": "count",
        "unit": "categories"
    },
    
    # Data 5 Metrics - Cardholder Segmentation (Cohort Analysis)
    "'23 Q1–'23 Q4": {
        "definition": "Baseline period representing cardholders from Q1 to Q4 of 2023",
        "direction": "Neutral",
        "formula": "Count of cardholders active during 2023 quarters",
        "description": "Reference period for cohort analysis. Used as starting point to track cardholder transitions.",
        "data_type": "count",
        "unit": "cardholders"
    },
    
    "New Active Cardholders": {
        "definition": "Cardholders who were newly acquired and became active",
        "direction": "Higher is better",
        "formula": "Count of cardholders who became active in the current period",
        "description": "Measures new customer acquisition success. High count indicates effective acquisition and activation strategies.",
        "data_type": "count",
        "unit": "cardholders"
    },
    
    "Existing Cardholders": {
        "definition": "Cardholders who remained active from the previous period",
        "direction": "Higher is better",
        "formula": "Count of cardholders active in both previous and current periods",
        "description": "Measures customer retention. High count indicates strong loyalty and continued engagement.",
        "data_type": "count",
        "unit": "cardholders"
    },
    
    "Disengaged Cardholders": {
        "definition": "Previously active cardholders who stopped using their cards",
        "direction": "Lower is better",
        "formula": "Count of cardholders active in previous period but inactive in current period",
        "description": "Measures customer attrition. Low count indicates better retention and customer satisfaction.",
        "data_type": "count",
        "unit": "cardholders"
    },
    
    "'24 Q1–'24 Q4": {
        "definition": "Current period representing cardholders from Q1 to Q4 of 2024",
        "direction": "Neutral",
        "formula": "Count of cardholders active during 2024 quarters",
        "description": "Current period for cohort analysis. Shows the outcome after tracking transitions from the baseline period.",
        "data_type": "count",
        "unit": "cardholders"
    },
    
    # Data 6 Metrics - Digital and Payment Trends (Duplicate with variations)
    "Percentage of Contactless Spend (out of CP transactions)": {
        "definition": "Proportion of card-present transactions using contactless payment method",
        "direction": "Higher is better",
        "formula": "(Contactless Card Present Spend / Total Card Present Spend) × 100",
        "description": "Measures contactless technology adoption in physical retail environments. High percentage indicates customer preference for tap-to-pay convenience.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "Percentage of Cross-Border Spend": {
        "definition": "Proportion of total spending on international transactions",
        "direction": "Context dependent",
        "formula": "(Cross-Border Transaction Spend / Total Spend) × 100",
        "description": "Measures international card usage and global acceptance. Higher percentage may indicate travel activity or international e-commerce.",
        "data_type": "percentage",
        "unit": "%"
    }
}