import React, { useState, useEffect } from 'react'
import { feedbackService } from '../services/feedbackService'
import { pptService } from '../services/pptService'
import '../styles/SlideViewer.css'

interface SlideViewerProps {
  slideImages: string[]
  insights: Record<string, string[]>
  issuerId: number
  feedback: Record<number, number>
  onSlideRegenerated: (slideNum: number, newImages: string[], newInsights: string[]) => void
  onFeedbackUpdate: (slideIndex: number, score: number) => void
}

const SlideViewer: React.FC<SlideViewerProps> = ({ 
  slideImages, 
  insights, 
  issuerId,
  feedback,
  onSlideRegenerated,
  onFeedbackUpdate
}) => {
  const [regenerating, setRegenerating] = useState<Record<number, boolean>>({})

  const handleFeedback = async (slideIndex: number, score: number) => {
    // Skip feedback for first slide (title slide)
    if (slideIndex === 0) return

    const slideKey = `slide${slideIndex}`
    // Get all insights - send the full array as-is (matching Streamlit behavior)
    const insightsList = insights[slideKey] || []

    try {
      // Submit feedback - send the entire list including title
      await feedbackService.submitFeedback({
        slide_key: slideKey,
        insight: insightsList,  // Send as array
        score,
      })

      // Update feedback state in parent
      onFeedbackUpdate(slideIndex, score)

      // If thumbs down, regenerate the slide
      if (score === 0) {
        setRegenerating(prev => ({ ...prev, [slideIndex]: true }))
        
        const result = await pptService.regenerateSlide(issuerId, slideIndex)
        
        // Notify parent component
        onSlideRegenerated(slideIndex, result.slide_images, result.new_insights)
        
        setRegenerating(prev => ({ ...prev, [slideIndex]: false }))
      }
    } catch (error) {
      console.error('Error handling feedback:', error)
      setRegenerating(prev => ({ ...prev, [slideIndex]: false }))
    }
  }

  return (
    <div className="slide-viewer">
      {slideImages.map((image, index) => (
        <div key={index} className="slide-container">
          <img 
            src={image} 
            alt={`Slide ${index + 1}`} 
            className="slide-image"
          />
          
          {index > 0 && (
            <div className="feedback-buttons">
              <button
                className={`feedback-btn thumbs-up ${feedback[index] === 1 ? 'active' : ''}`}
                onClick={() => handleFeedback(index, 1)}
                disabled={regenerating[index]}
                title="Mark this slide as helpful"
              >
                👍
              </button>
              <button
                className={`feedback-btn thumbs-down ${feedback[index] === 0 ? 'active' : ''}`}
                onClick={() => handleFeedback(index, 0)}
                disabled={regenerating[index]}
                title="Regenerate this slide"
              >
                👎
              </button>
              {regenerating[index] && (
                <span className="regenerating-text">Regenerating...</span>
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  )
}

export default SlideViewer
