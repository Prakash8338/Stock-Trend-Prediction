import React, { createContext, useContext, useState, ReactNode } from 'react'

interface IssuerPPTData {
  issuerId: number
  issuerName: string
  slideImages: string[]
  insights: Record<string, string[]>
  generated: boolean
  timestamp: number
}

interface PPTDataContextType {
  generatedPPTs: Record<number, IssuerPPTData>
  addPPTData: (data: IssuerPPTData) => void
  getPPTData: (issuerId: number) => IssuerPPTData | undefined
  hasPPTData: (issuerId: number) => boolean
  checkAllIssuersGenerated: (issuerIds: number[]) => boolean
  clearAllPPTData: () => void
}

const PPTDataContext = createContext<PPTDataContextType | undefined>(undefined)

interface PPTDataProviderProps {
  children: ReactNode
}

export const PPTDataProvider: React.FC<PPTDataProviderProps> = ({ children }) => {
  const [generatedPPTs, setGeneratedPPTs] = useState<Record<number, IssuerPPTData>>({})

  const addPPTData = (data: IssuerPPTData) => {
    setGeneratedPPTs(prev => ({
      ...prev,
      [data.issuerId]: data
    }))
  }

  const getPPTData = (issuerId: number): IssuerPPTData | undefined => {
    return generatedPPTs[issuerId]
  }

  const hasPPTData = (issuerId: number): boolean => {
    return generatedPPTs[issuerId]?.generated === true
  }

  const checkAllIssuersGenerated = (issuerIds: number[]): boolean => {
    return issuerIds.every(id => generatedPPTs[id]?.generated === true)
  }

  const clearAllPPTData = () => {
    setGeneratedPPTs({})
  }

  return (
    <PPTDataContext.Provider value={{ generatedPPTs, addPPTData, getPPTData, hasPPTData, checkAllIssuersGenerated, clearAllPPTData }}>
      {children}
    </PPTDataContext.Provider>
  )
}

export const usePPTData = () => {
  const context = useContext(PPTDataContext)
  if (context === undefined) {
    throw new Error('usePPTData must be used within a PPTDataProvider')
  }
  return context
}
