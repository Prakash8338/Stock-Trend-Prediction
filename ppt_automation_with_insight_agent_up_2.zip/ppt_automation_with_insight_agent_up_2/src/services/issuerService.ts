import apiClient from './apiClient'

export interface Issuer {
  id: number
  name: string
  code: string
  details?: string
}

export const issuerService = {
  // Get all issuers
  async getAllIssuers(): Promise<Issuer[]> {
    try {
      const response = await apiClient.get<Issuer[]>('/issuers')
      return response.data
    } catch (error) {
      console.error('Error fetching issuers:', error)
      throw error
    }
  },

  // Get single issuer
  async getIssuer(issuerId: number): Promise<Issuer> {
    try {
      const response = await apiClient.get<Issuer>(`/issuers/${issuerId}`)
      return response.data
    } catch (error) {
      console.error(`Error fetching issuer ${issuerId}:`, error)
      throw error
    }
  },
}
