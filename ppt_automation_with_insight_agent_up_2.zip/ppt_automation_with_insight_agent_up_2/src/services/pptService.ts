import apiClient from './apiClient'

export interface AllIssuersResponse {
  success: boolean
  message: string
  issuers_data: Array<{
    issuer_id: number
    issuer_name: string
    slide_images: string[]
    insights: Record<string, string[]>
    success: boolean
    error?: string
  }>
}

export interface AIGenerationResponse {
  message: string
  issuer_id: number
  issuer_name: string
  ppt_file: string
  pdf_file: string
  slide_images: string[]
  insights: Record<string, string[]>
}

export interface RegenerateSlideResponse {
  message: string
  slide_num: number
  new_insights: string[]
  slide_images: string[]
}

export const pptService = {
  // Generate PPT for all issuers - returns list of issuers
  async generateAllIssuers(): Promise<AllIssuersResponse> {
    try {
      const response = await apiClient.post('/ppt/generate-all')
      return response.data
    } catch (error) {
      console.error('Error generating PPT for all issuers:', error)
      throw error
    }
  },

  // Generate PPT for single issuer and get PDF (simple version)
  async generateSingleIssuer(issuerId: number): Promise<Blob> {
    try {
      const response = await apiClient.post(`/ppt/generate-single/${issuerId}`, {}, {
        responseType: 'blob',
      })
      return response.data
    } catch (error) {
      console.error(`Error generating PPT for issuer ${issuerId}:`, error)
      throw error
    }
  },

  // Generate PPT with AI insights for single issuer
  async generateWithAI(issuerId: number): Promise<AIGenerationResponse> {
    try {
      const response = await apiClient.post(`/ppt/generate-with-ai/${issuerId}`)
      return response.data
    } catch (error) {
      console.error(`Error generating PPT with AI for issuer ${issuerId}:`, error)
      throw error
    }
  },

  // Regenerate a specific slide
  async regenerateSlide(issuerId: number, slideNum: number): Promise<RegenerateSlideResponse> {
    try {
      const response = await apiClient.post(`/ppt/regenerate-slide/${issuerId}/${slideNum}`)
      return response.data
    } catch (error) {
      console.error(`Error regenerating slide ${slideNum} for issuer ${issuerId}:`, error)
      throw error
    }
  },

  // Get PDF file for issuer
  async getPDF(issuerId: number): Promise<Blob> {
    try {
      const response = await apiClient.get(`/ppt/get-pdf/${issuerId}`, {
        responseType: 'blob',
      })
      return response.data
    } catch (error) {
      console.error(`Error getting PDF for issuer ${issuerId}:`, error)
      throw error
    }
  },

  // Get slide image
  async getSlideImage(issuerId: number, slideNum: number): Promise<Blob> {
    try {
      const response = await apiClient.get(`/ppt/slide-images/${issuerId}/${slideNum}`, {
        responseType: 'blob',
      })
      return response.data
    } catch (error) {
      console.error(`Error getting slide image ${slideNum} for issuer ${issuerId}:`, error)
      throw error
    }
  },

  // Preview generation for all issuers
  async previewAll(): Promise<any> {
    try {
      const response = await apiClient.get('/ppt/preview-all')
      return response.data
    } catch (error) {
      console.error('Error previewing all issuers:', error)
      throw error
    }
  },

  // Preview generation for single issuer
  async previewSingle(issuerId: number): Promise<any> {
    try {
      const response = await apiClient.get(`/ppt/preview-single/${issuerId}`)
      return response.data
    } catch (error) {
      console.error(`Error previewing issuer ${issuerId}:`, error)
      throw error
    }
  },

  // Download PPTX file for single issuer
  async downloadPptx(issuerId: number): Promise<void> {
    try {
      const response = await apiClient.get(`/ppt/download-pptx/${issuerId}`, {
        responseType: 'blob',
      })
      
      // Check if response is actually a blob and not an error JSON
      if (response.data.type === 'application/json') {
        const text = await response.data.text()
        const errorData = JSON.parse(text)
        throw new Error(errorData.error || 'Download failed')
      }
      
      // Create a download link
      const url = window.URL.createObjectURL(response.data)
      const link = document.createElement('a')
      link.href = url
      
      // Extract filename from response headers or use default
      const contentDisposition = response.headers['content-disposition']
      let filename = `issuer_${issuerId}_report.pptx`
      if (contentDisposition) {
        const filenameMatch = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/)
        if (filenameMatch && filenameMatch[1]) {
          filename = filenameMatch[1].replace(/['"]/g, '')
        }
      }
      
      link.setAttribute('download', filename)
      document.body.appendChild(link)
      link.click()
      
      // Cleanup
      setTimeout(() => {
        link.remove()
        window.URL.revokeObjectURL(url)
      }, 100)
    } catch (error) {
      console.error(`Error downloading PPTX for issuer ${issuerId}:`, error)
      throw error
    }
  },

  // Download default PowerPoint template
  async downloadDefaultPptx(): Promise<void> {
    try {
      const response = await apiClient.get('/ppt/download-default', {
        responseType: 'blob',
      })
      
      // Check if response is actually a blob and not an error JSON
      if (response.data.type === 'application/json') {
        const text = await response.data.text()
        const errorData = JSON.parse(text)
        throw new Error(errorData.error || 'Download failed')
      }
      
      // Create a download link
      const url = window.URL.createObjectURL(response.data)
      const link = document.createElement('a')
      link.href = url
      
      // Extract filename from response headers or use default
      const contentDisposition = response.headers['content-disposition']
      let filename = 'auto_code_ppt.pptx'
      if (contentDisposition) {
        const filenameMatch = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/)
        if (filenameMatch && filenameMatch[1]) {
          filename = filenameMatch[1].replace(/['"]/g, '')
        }
      }
      
      link.setAttribute('download', filename)
      document.body.appendChild(link)
      link.click()
      
      // Cleanup
      setTimeout(() => {
        link.remove()
        window.URL.revokeObjectURL(url)
      }, 100)
    } catch (error) {
      console.error('Error downloading default PPTX:', error)
      throw error
    }
  },

  // Download all issuer PowerPoint files as ZIP
  async downloadAllPptx(): Promise<void> {
    try {
      const response = await apiClient.get('/ppt/download-all-pptx', {
        responseType: 'blob',
      })
      
      // Check if response is actually a blob and not an error JSON
      if (response.data.type === 'application/json') {
        const text = await response.data.text()
        const errorData = JSON.parse(text)
        throw new Error(errorData.error || 'Download failed')
      }
      
      // Create a download link
      const url = window.URL.createObjectURL(response.data)
      const link = document.createElement('a')
      link.href = url
      
      // Extract filename from response headers or use default
      const contentDisposition = response.headers['content-disposition']
      let filename = 'All_Issuers_Reports.zip'
      if (contentDisposition) {
        const filenameMatch = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/)
        if (filenameMatch && filenameMatch[1]) {
          filename = filenameMatch[1].replace(/['"]/g, '')
        }
      }
      
      link.setAttribute('download', filename)
      document.body.appendChild(link)
      link.click()
      
      // Cleanup
      setTimeout(() => {
        link.remove()
        window.URL.revokeObjectURL(url)
      }, 100)
    } catch (error) {
      console.error('Error downloading all PPTX files:', error)
      throw error
    }
  },
}
