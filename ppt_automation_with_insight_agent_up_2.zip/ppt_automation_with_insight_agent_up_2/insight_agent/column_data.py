column_data = {
    # Excel Data Columns - Used across all slides
    "Metric": {
        "definition": "Name of the performance metric being measured",
        "direction": "Neutral",
        "formula": "N/A - This is a label column",
        "description": "Identifies the specific metric or KPI being analyzed in each row. Used as the primary identifier for data points.",
        "data_type": "text",
        "unit": "N/A"
    },
    
    "Difference_Current": {
        "definition": "Difference between Issuer and Peers current period values",
        "direction": "Context dependent",
        "formula": "Issuer_Current - Peers_Current",
        "description": "Shows the performance gap between the issuer and peer average. Positive values indicate issuer outperformance, negative values indicate underperformance.",
        "data_type": "decimal",
        "unit": "varies"
    },
    
    "Issuer_Current": {
        "definition": "Current period value for the issuer",
        "direction": "Context dependent",
        "formula": "Issuer's actual performance value for current period",
        "description": "Represents the issuer's performance metric for the current reporting period. Used for comparison against peers and historical performance.",
        "data_type": "decimal",
        "unit": "varies"
    },
    
    "Issuer_Prior": {
        "definition": "Prior period value for the issuer",
        "direction": "Context dependent",
        "formula": "Issuer's actual performance value for previous period",
        "description": "Represents the issuer's performance metric for the previous reporting period. Used for trend analysis and period-over-period comparison.",
        "data_type": "decimal",
        "unit": "varies"
    },
    
    "Peers_Current": {
        "definition": "Current period average value for peer group",
        "direction": "Context dependent",
        "formula": "Average of peer institutions' performance values for current period",
        "description": "Benchmark value representing the average performance of peer institutions. Used for competitive positioning analysis.",
        "data_type": "decimal",
        "unit": "varies"
    },
    
    # Data_1 Metrics - Cardholder Segmentation (Cohort Analysis)
    "22 Q1-22 Q4": {
        "definition": "Baseline period representing cardholders from Q1 to Q4 of 2022",
        "direction": "Neutral",
        "formula": "Count/percentage of cardholders active during 2022 quarters",
        "description": "Reference period for cohort analysis. Used as starting point to track cardholder transitions.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "New Active Cardholders": {
        "definition": "Cardholders who were newly acquired and became active",
        "direction": "Higher is better",
        "formula": "Percentage of cardholders who became active in the current period",
        "description": "Measures new customer acquisition success. High percentage indicates effective acquisition and activation strategies.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "Existing Cardholders": {
        "definition": "Cardholders who remained active from the previous period",
        "direction": "Higher is better",
        "formula": "Percentage of cardholders active in both previous and current periods",
        "description": "Measures customer retention. High percentage indicates strong loyalty and continued engagement.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "Disengaged Cardholders": {
        "definition": "Previously active cardholders who stopped using their cards",
        "direction": "Lower is better",
        "formula": "Percentage of cardholders active in previous period but inactive in current period",
        "description": "Measures customer attrition. Low percentage indicates better retention and customer satisfaction.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "23 Q3-23 Q4": {
        "definition": "Current period representing cardholders from Q3 to Q4 of 2023",
        "direction": "Neutral",
        "formula": "Count/percentage of cardholders active during Q3-Q4 2023",
        "description": "Current period for cohort analysis. Shows the outcome after tracking transitions from the baseline period.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    # Data_2 Metrics - Strategic Performance Indicators
    "Impact on Spend from Cardholder Disengagement": {
        "definition": "Financial impact of cardholders who stopped using their cards",
        "direction": "Lower is better (less negative)",
        "formula": "Lost spend from disengaged cardholders as a proportion of total spend",
        "description": "Measures the revenue loss from customer disengagement. Higher negative values indicate significant revenue impact from attrition.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "Cards With at least 1 Authorization Decline": {
        "definition": "Number of cards that experienced at least one declined transaction",
        "direction": "Lower is better",
        "formula": "Count of unique cards with one or more declined authorizations",
        "description": "Measures the scope of authorization issues affecting the card portfolio. High count may indicate system issues or fraud prevention being too aggressive.",
        "data_type": "count",
        "unit": "cards"
    },
    
    "Percent of Portfolio at Risk of Disengagement": {
        "definition": "Proportion of active cards showing signs of potential disengagement",
        "direction": "Lower is better",
        "formula": "Cards at risk / Total active cards",
        "description": "Predicts potential future attrition. High percentage requires proactive retention efforts to prevent revenue loss.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    # Data_3 Metrics - Core Performance Metrics
    "New Active Card Percentage": {
        "definition": "What were the newly acquired cards in the year",
        "direction": "Higher is better",
        "formula": "Newly Acquired card count / Overall card count",
        "description": "Measures the percentage of newly acquired cards. High New Active Card Percentage indicates good customer acquisition.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "3 Month Purchase Active Rate": {
        "definition": "How many cards are active in last 3 months",
        "direction": "Higher is better",
        "formula": "3-month active card count / Overall card count",
        "description": "Measures card engagement over the last 3 months. High 3 Month Purchase Active Rate indicates strong card usage and customer engagement.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "Spend Per Active Card": {
        "definition": "What is the average spend of cards",
        "direction": "Higher is better",
        "formula": "Overall amount / Overall card count",
        "description": "Average spending per card. High Spend Per Active Card indicates higher transaction values and better monetization.",
        "data_type": "currency",
        "unit": "$"
    },
    
    "Transaction Per Active Card": {
        "definition": "What is the average transactions of cards",
        "direction": "Higher is better",
        "formula": "Overall transaction count / Overall card count",
        "description": "Average number of transactions per card. High Transaction Per Active Card indicates frequent card usage.",
        "data_type": "count",
        "unit": "transactions"
    },
    
    "Disengagement Rate": {
        "definition": "Percentage of cards stopped transacting in the year",
        "direction": "Lower is better",
        "formula": "Number of inactive cards / Overall card count",
        "description": "Measures card attrition and disengagement. Low Disengagement Rate is good, indicating high customer retention.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "Authorization Rate": {
        "definition": "Percentage of transactions getting authorized",
        "direction": "Higher is better",
        "formula": "Number of Authorized Transactions / Overall transactions",
        "description": "Percentage of successfully authorized transactions. High Authorization Rate indicates smooth transaction processing and good fraud controls.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "Fraud Rate": {
        "definition": "Rate of transactions tagged as fraudulent",
        "direction": "Lower is better",
        "formula": "(Fraud Amount / Authorized Amount) × 10000 (calculated in BPS - basis points)",
        "description": "Fraud rate measured in basis points (BPS). Low Fraud Rate is better, indicating effective fraud prevention and security.",
        "data_type": "percentage",
        "unit": "bps"
    },
    
    "Interchange Rate": {
        "definition": "Interchange rate charged on transactions",
        "direction": "Context dependent",
        "formula": "Interchange fees / Transaction volume",
        "description": "Interchange rate as a percentage of transaction volume.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    # Data_4 Metrics - Decline Reason Analysis
    "RESTRICTED CARD": {
        "definition": "Percentage of declines due to card restrictions",
        "direction": "Lower is better",
        "formula": "Restricted card declines / Total declines",
        "description": "Measures authorization failures from card restrictions. High percentage may indicate overly restrictive policies affecting customer experience.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "NOT SUFFICIENT FUNDS": {
        "definition": "Percentage of declines due to insufficient funds",
        "direction": "Lower is better",
        "formula": "NSF declines / Total declines",
        "description": "Measures authorization failures from insufficient account balance. High percentage may indicate customer credit limit issues.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "CLOSED AMOUNT": {
        "definition": "Percentage of declines due to closed account",
        "direction": "Lower is better",
        "formula": "Closed account declines / Total declines",
        "description": "Measures authorization failures from closed accounts. High percentage indicates inactive account management issues.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "SUSPECTED FRAUD": {
        "definition": "Percentage of declines due to suspected fraudulent activity",
        "direction": "Context dependent",
        "formula": "Fraud-suspected declines / Total declines",
        "description": "Measures authorization blocks from fraud detection. Balance needed between fraud prevention and customer convenience.",
        "data_type": "percentage",
        "unit": "%"
    },
    
    "EXCEEDS APPROVAL AMOUNT LIMIT": {
        "definition": "Percentage of declines due to exceeding approved transaction limits",
        "direction": "Lower is better",
        "formula": "Limit-exceeded declines / Total declines",
        "description": "Measures authorization failures from transaction limit breaches. High percentage may indicate limits not aligned with customer needs.",
        "data_type": "percentage",
        "unit": "%"
    }
}