# Create impact_strength_examples.py

"""
Examples of using the generalized impact strength assessment system.
This works with any numerical data - financial, operational, behavioral, etc.
"""

import pandas as pd
import os
from strength_check import (
    analyze_insight_strength,
    assess_impact_strength,
    calculate_change_magnitude,
    format_impact_label,
    get_impact_thresholds_info
)


def load_mockup_data():
    """Load and parse the mockup data CSV"""
    data_path = os.path.join(os.path.dirname(__file__), 'data', 'mockup_data.csv')
    
    # Read CSV with pandas
    df = pd.read_csv(data_path)
    
    # Clean the data - remove % signs, commas, and convert to float
    def clean_value(val):
        if pd.isna(val):
            return None
        val_str = str(val).strip()
        # Remove % signs, commas, parentheses
        val_str = val_str.replace('%', '').replace(',', '').replace('(', '-').replace(')', '').strip()
        try:
            return float(val_str)
        except:
            return None
    
    # Create a list of metrics with cleaned data
    metrics_data = []
    for _, row in df.iterrows():
        metrics_data.append({
            'name': row['Metric'],
            'current': clean_value(row['Issuer Current Year']),
            'previous': clean_value(row['Issuer Previous Year']),
            'peers': clean_value(row['Peers Current Year'])
        })
    
    return metrics_data


def example_1_financial_metric():
    """Example: Analyze Disengagement Rate from mockup data"""
    print("\n" + "="*80)
    print("EXAMPLE 1: Financial Metric (Disengagement Rate)")
    print("="*80)
    
    # Load mockup data
    metrics = load_mockup_data()
    disengagement = next(m for m in metrics if 'Disengagement' in m['name'])
    
    analysis = analyze_insight_strength(
        current_value=disengagement['current'],
        previous_value=disengagement['previous'],
        benchmark_value=disengagement['peers'],
        metric_name=disengagement['name'],
        is_critical=True  # Critical metric for customer retention
    )
    
    print(f"\nMetric: {analysis['metric_name']}")
    print(f"Current Value: {analysis['current_value']}%")
    print(f"\nChanges:")
    print(f"  - YoY Change: {analysis['changes']['percentage_change']:.2f}%")
    print(f"  - Absolute Change: {analysis['changes']['absolute_change']:.2f}pp")
    print(f"  - Benchmark Gap: {analysis['changes']['benchmark_gap']:.2f}pp")
    print(f"  - Gap %: {analysis['changes']['benchmark_gap_pct']:.2f}%")
    
    print(f"\nImpact Assessment:")
    print(f"  - Impact Score: {analysis['impact']['impact_score']}")
    print(f"  - Impact Magnitude: {analysis['impact']['impact_magnitude']}")
    print(f"  - Confidence Level: {analysis['impact']['confidence_level']}")
    print(f"  - Score Components: {analysis['impact']['components']}")
    
    print(f"\n{analysis['formatted_label']}")
    print("="*80)


def example_2_operational_metric():
    """Example: Analyze Authorization Rate from mockup data"""
    print("\n" + "="*80)
    print("EXAMPLE 2: Operational Metric (Authorization Rate)")
    print("="*80)
    
    # Load mockup data
    metrics = load_mockup_data()
    auth_rate = next(m for m in metrics if 'Authorization' in m['name'])
    
    analysis = analyze_insight_strength(
        current_value=auth_rate['current'],
        previous_value=auth_rate['previous'],
        benchmark_value=auth_rate['peers'],
        metric_name=auth_rate['name'],
        is_critical=True  # Authorization rate is critical for operations
    )
    
    print(f"\nMetric: {analysis['metric_name']}")
    print(f"Current Value: {analysis['current_value']}%")
    print(f"Previous Value: {auth_rate['previous']}%")
    print(f"Change: +{analysis['changes']['percentage_change']:.2f}%")
    print(f"Peer Benchmark: {auth_rate['peers']}%")
    print(f"Gap vs Peers: {analysis['changes']['benchmark_gap']:.2f}pp")
    
    print(f"\nImpact: {analysis['impact']['impact_magnitude']}")
    print(f"Confidence: {analysis['impact']['confidence_level']}")
    print(f"\n{analysis['formatted_label']}")
    print("="*80)


def example_3_custom_weights():
    """Example: Using custom weights for fraud rate analysis"""
    print("\n" + "="*80)
    print("EXAMPLE 3: Custom Weights (Fraud Rate - High Risk Metric)")
    print("="*80)
    
    # Load mockup data
    metrics = load_mockup_data()
    fraud_rate = next(m for m in metrics if 'Fraud' in m['name'])
    
    # For fraud/risk metrics, we want to emphasize changes and gaps more
    custom_weights = {
        'change_weight': 3.5,      # Higher than default 2.0
        'gap_weight': 3.0,         # Higher than default 2.5
        'critical_bonus': 25       # Higher than default 15
    }
    
    analysis = analyze_insight_strength(
        current_value=fraud_rate['current'],
        previous_value=fraud_rate['previous'],
        benchmark_value=fraud_rate['peers'],
        metric_name=fraud_rate['name'],
        is_critical=True,
        custom_weights=custom_weights
    )
    
    print(f"\nMetric: {analysis['metric_name']}")
    print(f"Current: {analysis['current_value']}")
    print(f"Previous: {fraud_rate['previous']} (change: {analysis['changes']['percentage_change']:.1f}%)")
    print(f"Industry Benchmark: {fraud_rate['peers']}")
    print(f"Gap vs Benchmark: {analysis['changes']['benchmark_gap']:.2f}")
    
    print(f"\nCustom Scoring (Fraud-focused):")
    print(f"  - Impact Score: {analysis['impact']['impact_score']}")
    print(f"  - Components: {analysis['impact']['components']}")
    
    print(f"\n{analysis['formatted_label']}")
    print("="*80)


def example_4_batch_analysis():
    """Example: Analyzing all metrics from mockup data"""
    print("\n" + "="*80)
    print("EXAMPLE 4: Batch Analysis of All Mockup Metrics")
    print("="*80)
    
    # Load mockup data
    metrics_data = load_mockup_data()
    
    # Define which metrics are critical
    critical_metrics = ['Disengagement Rate', 'Fraud Rate', 'Authorization Rate', 
                       'Decline Rate', '3 Month Purchase Active Rate']
    
    results = []
    for m in metrics_data:
        if m['current'] is not None:  # Only analyze if we have current data
            is_critical = m['name'] in critical_metrics
            analysis = analyze_insight_strength(
                current_value=m['current'],
                previous_value=m['previous'],
                benchmark_value=m['peers'],
                metric_name=m['name'],
                is_critical=is_critical
            )
            results.append(analysis)
    
    # Sort by impact score
    results.sort(key=lambda x: x['impact']['impact_score'], reverse=True)
    
    print("\nAll Metrics Ranked by Impact Score:\n")
    for i, r in enumerate(results, 1):
        print(f"{i}. {r['metric_name']}")
        print(f"   {r['formatted_label']}")
        if r['changes']['percentage_change'] is not None:
            print(f"   YoY Change: {r['changes']['percentage_change']:+.1f}%")
        if r['changes']['benchmark_gap'] is not None:
            print(f"   Gap vs Peers: {r['changes']['benchmark_gap']:+.2f}")
        print()
    
    print("="*80)


def example_5_insight_formatting():
    """Example: Adding strength labels to insight text using mockup data"""
    print("\n" + "="*80)
    print("EXAMPLE 5: Formatting Insights with Strength Indicators")
    print("="*80)
    
    # Load mockup data
    metrics = load_mockup_data()
    purchase_active = next(m for m in metrics if '3 Month Purchase' in m['name'])
    
    # Analyze the metric
    analysis = analyze_insight_strength(
        current_value=purchase_active['current'],
        previous_value=purchase_active['previous'],
        benchmark_value=purchase_active['peers'],
        metric_name=purchase_active['name'],
        is_critical=True
    )
    
    # Calculate actual percentage change
    pct_change = ((purchase_active['current'] - purchase_active['previous']) / purchase_active['previous']) * 100
    gap = purchase_active['current'] - purchase_active['peers']
    
    # Original insight text
    insight_text = f"""{purchase_active['name']} reached {purchase_active['current']}% 
(up {pct_change:.1f}% from {purchase_active['previous']}%), {abs(gap):.1f}pp below 
peers at {purchase_active['peers']}%. Despite the YoY improvement, the significant gap 
indicates lower customer engagement compared to competitors."""
    
    # Add strength indicator
    formatted_insight = f"{analysis['formatted_label']}\n{insight_text}"
    
    print("\nOriginal Insight:")
    print("-" * 80)
    print(insight_text)
    
    print("\n\nWith Strength Indicator:")
    print("-" * 80)
    print(formatted_insight)
    
    print("\n\nDetailed Analysis:")
    print(f"Impact Score: {analysis['impact']['impact_score']}")
    print(f"Score Breakdown: {analysis['impact']['components']}")
    
    print("="*80)


def show_methodology():
    """Display the methodology documentation"""
    print(get_impact_thresholds_info())


if __name__ == "__main__":
    # Run all examples
    example_1_financial_metric()
    example_2_operational_metric()
    example_3_custom_weights()
    example_4_batch_analysis()
    example_5_insight_formatting()
    
    # Show methodology
    print("\n")
    show_methodology()