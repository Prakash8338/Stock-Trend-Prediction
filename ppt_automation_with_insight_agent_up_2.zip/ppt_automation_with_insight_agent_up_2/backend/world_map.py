import pptx
from pptx import Presentation
from pptx.enum.chart import *
from pptx.enum.shapes import *
from pptx.chart.data import * 
import pandas as pd
from pptx.util import Pt,Inches
from pptx.dml.color import RGBColor
import plotly.graph_objs as go
import plotly.io as pio
import os 
from lxml import etree
import kaleido 
print(kaleido.__version__)
print('world_map')
        if shape.name == 'chart_1':
            print('world_map')
            #fig = go.Figure()
            #fig.add_trace(go.Scattergeo(locationmode='ISO-3',lon=[100,20],lat=[15,-5],text=['Asia Pacific','CEMEA'],mode='markers+text',marker=dict(size=10,color='black')))
            #fig.add_trace(go.Scattergeo(lon=[120,20],lat=[15,-5],text=["<b> Asia Pacific </b><br>PV: -5.2% YoY<br>FRAUD RATE: +0.8% YOY","<b>CEMEA</b><br>PV: -6.2% YoY<br>FRAUD RATE: +91.1% YOY"],mode='text',textposition= 'top right' , textfont=dict(size=12,color='black')))
            #fig.update_layout(geo=dict(showframe=False,showcoastlines= False,projection_type='natural earth'),margin={"r":0,"t":0,"l":0,"b":0})
# Check Kaleido version
#print(pio.kaleido.scope.default_format)
            #fig.show()
            #pio.write_image(fig,"simple.png")
            #print("finished")
            left,top,width,height = shape.left,shape.top,shape.width,shape.height
            slide.shapes._spTree.remove(shape._element)
            slide.shapes.add_picture("simple.png",left,top,width=width,height=height)
            print('added')

            #left,top,width,height = shape.left,shape.top,shape.width,shape.height

            #slide.shapes._spTree.remove(shape._element)
            #slide.shapes.add_picture(image_file,left,top,width=width,height=height)