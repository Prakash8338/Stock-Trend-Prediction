"""
Slide-wise Pivot Table Generator
Creates pivot tables for each slide using Category, Metric, time_period, and value columns
Separates data by chart type and saves to Excel files
"""

import pandas as pd
import os


def create_chart_pivot(df, issuer_name, slide_number, chart_type, pivot_type='category'):
    """
    Create pivot table for a specific chart on a slide in row x column format
    
    Args:
        df: DataFrame with issuer data
        issuer_name: Name of issuer
        slide_number: Slide number
        chart_type: Chart type ('Waterfall', 'Metric', 'Line', 'column', 'Oval')
        pivot_type: Type of pivot
    
    Returns:
        Flattened DataFrame with Metric as first column and simple column names
        Easy to process row by row and access by column names
    """
    # Filter for slide and chart type
    chart_df = df[
        (df['issuer'] == issuer_name) & 
        (df['slide'] == slide_number) &
        (df['chart_type'] == chart_type)
    ].copy()
    
    if chart_df.empty:
        return pd.DataFrame()
    
    # Create pivot based on type
    if pivot_type == 'category':
        pivot = pd.pivot_table(
            chart_df,
            index='Metric',
            columns='Category',
            values='value',
            aggfunc='first'
        )
    
    elif pivot_type == 'time':
        pivot = pd.pivot_table(
            chart_df,
            index='Metric',
            columns='time_period',
            values='value',
            aggfunc='first'
        )
    
    elif pivot_type == 'category_time':
        pivot = pd.pivot_table(
            chart_df,
            index='Metric',
            columns=['Category', 'time_period'],
            values='value',
            aggfunc='first'
        )
        
        # Flatten multi-index columns into single level
        # Convert ('Issuer', 'Current') to 'Issuer_Current'
        if isinstance(pivot.columns, pd.MultiIndex):
            pivot.columns = ['_'.join(map(str, col)).strip() for col in pivot.columns.values]
    
    # Reset index to make Metric a regular column (row by column format)
    pivot = pivot.reset_index()
    
    return pivot


def get_slide_summary(df, issuer_name):
    """
    Get summary of slides and their chart types
    
    Returns:
        DataFrame with slide, chart_type, and counts
    """
    issuer_df = df[df['issuer'] == issuer_name].copy()
    
    summary = issuer_df.groupby(['slide', 'chart_type']).agg({
        'Metric': 'nunique',
        'Category': 'nunique',
        'time_period': 'nunique'
    }).reset_index()
    
    summary.columns = ['Slide', 'Chart_Type', 'Unique_Metrics', 'Unique_Categories', 'Unique_Time_Periods']
    
    return summary


def create_slide_pivots_by_chart_type(df, issuer_name, slide_number, pivot_type='category_time'):
    """
    Create separate pivot tables for each chart type on a slide
    
    Args:
        df: DataFrame with issuer data
        issuer_name: Name of issuer
        slide_number: Slide number
        pivot_type: Type of pivot (default: 'category_time')
    
    Returns:
        Dictionary with chart_type as keys and pivot DataFrames as values
        Example: {'Waterfall': pivot_df, 'Metric': pivot_df, ...}
    """
    # Get data for this slide
    slide_df = df[(df['issuer'] == issuer_name) & (df['slide'] == slide_number)].copy()
    
    if slide_df.empty:
        return {}
    
    # Get unique chart types for this slide
    chart_types = slide_df['chart_type'].unique()
    
    # Create pivot for each chart type
    pivots = {}
    for chart_type in chart_types:
        pivot = create_chart_pivot(df, issuer_name, slide_number, chart_type, pivot_type)
        if not pivot.empty:
            pivots[chart_type] = pivot
    
    return pivots


def save_slide_pivots_to_excel(df, issuer_name, slide_number, output_dir=None, pivot_type='category_time'):
    """
    Create pivots by chart type and save to Excel file with multiple sheets
    
    Args:
        df: DataFrame with issuer data
        issuer_name: Name of issuer
        slide_number: Slide number
        output_dir: Directory to save Excel files (default: ../insight_agent/data)
        pivot_type: Type of pivot (default: 'category_time')
    
    Returns:
        Path to saved Excel file
    """
    # Set default output directory to insight_agent/data
    if output_dir is None:
        output_dir = os.path.join(os.path.dirname(__file__), '..', 'insight_agent', 'data')
    
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    # Get pivots by chart type
    pivots = create_slide_pivots_by_chart_type(df, issuer_name, slide_number, pivot_type)
    
    if not pivots:
        print(f"No data found for {issuer_name}, Slide {slide_number}")
        return None
    
    # Create filename
    issuer_clean = issuer_name.replace(' ', '_')
    filename = f"{issuer_clean}_Slide_{slide_number}_pivots.xlsx"
    filepath = os.path.join(output_dir, filename)
    
    # Save to Excel with multiple sheets
    with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
        for chart_type, pivot_df in pivots.items():
            # Clean sheet name (Excel has 31 char limit and some char restrictions)
            sheet_name = chart_type[:31].replace('/', '_').replace('\\', '_')
            # Save without index since Metric is already a column
            pivot_df.to_excel(writer, sheet_name=sheet_name, index=False)
    
    print(f"Saved: {filepath}")
    return filepath


def save_all_slides_to_excel(df, issuer_name, output_dir=None, pivot_type='category_time'):
    """
    Create and save pivot tables for all slides of an issuer
    
    Args:
        df: DataFrame with issuer data
        issuer_name: Name of issuer
        output_dir: Directory to save Excel files (default: ../insight_agent/data)
        pivot_type: Type of pivot (default: 'category_time')
    
    Returns:
        List of file paths created
    """
    # Set default output directory to insight_agent/data
    if output_dir is None:
        output_dir = os.path.join(os.path.dirname(__file__), '..', 'insight_agent', 'data')
    
    # Get unique slides for this issuer
    slides = df[df['issuer'] == issuer_name]['slide'].unique()
    slides = sorted(slides)
    
    filepaths = []
    for slide in slides:
        filepath = save_slide_pivots_to_excel(df, issuer_name, slide, output_dir, pivot_type)
        if filepath:
            filepaths.append(filepath)
    
    return filepaths


# Example usage
if __name__ == "__main__":
    # Load data
    data_path = os.path.join(os.path.dirname(__file__), 'issuer_data.csv')
    df = pd.read_csv(data_path)
    
    issuer = "Bank of America"
    
    print("="*80)
    print(f"CREATING PIVOTS BY CHART TYPE FOR {issuer}")
    print("="*80)
    
    # Show summary
    print("\nSLIDE SUMMARY:")
    summary = get_slide_summary(df, issuer)
    print(summary.to_string(index=False))
    
    # Get unique slides
    slides = df[df['issuer'] == issuer]['slide'].unique()
    slides = sorted(slides)
    
    print("\n" + "="*80)
    print("CREATING PIVOTS SEPARATED BY CHART TYPE")
    print("="*80)
    
    # Process each slide
    for slide_num in slides:
        print(f"\n{'='*80}")
        print(f"SLIDE {slide_num} - PIVOTS BY CHART TYPE (Category x time_period)")
        print(f"{'='*80}")
        
        # Get pivots by chart type
        pivots = create_slide_pivots_by_chart_type(df, issuer, slide_num, 'category_time')
        
        # Display each chart type's pivot
        for chart_type, pivot_df in pivots.items():
            print(f"\n{chart_type} Chart:")
            print("-" * 60)
            print(pivot_df)
            print()
    
    # Save all slides to Excel files
    print("\n" + "="*80)
    print("SAVING PIVOTS TO EXCEL FILES")
    print("="*80)
    
    # Uses default output_dir (insight_agent/data)
    filepaths = save_all_slides_to_excel(df, issuer, pivot_type='category_time')
    
    print(f"\n✓ Created {len(filepaths)} Excel files")
    print("\nFiles created:")
    for filepath in filepaths:
        print(f"  - {os.path.basename(filepath)}")
    print(f"\nSaved to: {os.path.dirname(filepaths[0]) if filepaths else 'N/A'}")
    
    print("\n" + "="*80)
    print("EXAMPLE: Reading back from Excel")
    print("="*80)
    
    # Example: Read back one of the Excel files
    if filepaths:
        print(f"\nReading: {os.path.basename(filepaths[0])}")
        excel_file = pd.ExcelFile(filepaths[0])
        print(f"Sheets in file: {excel_file.sheet_names}")
        
        # Read first sheet (without index_col since data is in row x column format)
        if excel_file.sheet_names:
            first_sheet = excel_file.sheet_names[0]
            df_read = pd.read_excel(filepaths[0], sheet_name=first_sheet)
            print(f"\nData from '{first_sheet}' sheet (Row x Column format):")
            print(df_read)
            
            # Show how to access data easily
            print(f"\n{'='*80}")
            print("EXAMPLE: How to access data from row x column format")
            print("="*80)
            if not df_read.empty and 'Metric' in df_read.columns:
                print("\n# Access by row index and column name:")
                print(f"First metric: {df_read.loc[0, 'Metric']}")
                
                # Show all column names for easy access
                print(f"\nAvailable columns: {list(df_read.columns)}")
                
                # Iterate through rows
                print(f"\n# Iterate through rows:")
                for idx, row in df_read.head(3).iterrows():
                    print(f"Row {idx}: Metric = {row['Metric']}")
                    # Access other columns
                    for col in df_read.columns:
                        if col != 'Metric' and pd.notna(row[col]):
                            print(f"  {col} = {row[col]}")
                    print()
