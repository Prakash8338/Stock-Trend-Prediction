from langgraph.graph import StateGraph, END
from typing import TypedDict
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
import httpx
from langchain_core.caches import BaseCache 
from langchain_core.callbacks import Callbacks 
import pandas as pd
import os
from review_prompt import get_review_prompt
from column_data import column_data
import re
from dotenv import load_dotenv

load_dotenv()
os.environ["OPENAI_API_KEY"] = os.getenv("OPENAI_API_KEY")

# def count_errors(error_msg: str):
#     # Count enumerated errors, e.g. "Rule 8 violated:" or "Rule 5:"
#     matches = re.findall(r'Rule\s*\d+\s*:', error_msg)
#     if matches:
#         return len(matches)
#     # If not enumerated, fall back to line count, ignoring empty lines
#     return len([line for line in error_msg.split('\n') if line.strip()])

def count_errors(error_msg: str):
    """
    Counts violations specified as:
      - 'Rule X violated:' or 'Rule X:'
      - 'Rule X and Y violated:' or 'Rule X and Y:'
      - ...even if multiple per line.
    """
    total = 0
    # Pattern for "Rule X and Y violated:" or "Rule X and Y:"
    multi_pattern = re.compile(r'Rule\s*(\d+)\s*and\s*(\d+)\s*(?:violated)?\s*:', re.IGNORECASE)
    # Pattern for single "Rule X violated:" or "Rule X:"
    single_pattern = re.compile(r'Rule\s*(\d+)\s*(?:violated)?\s*:', re.IGNORECASE)

    # First, count all multi-rule violations
    for match in multi_pattern.finditer(error_msg):
        # Each multi-vio counts as two
        total += 2

    # Remove strings already matched as multi (to avoid double-counting)
    singles_check_str = multi_pattern.sub('', error_msg)

    # Now, count all remaining singles
    singles = single_pattern.findall(singles_check_str)
    total += len(singles)

    return total

def extract_rule_count(review_prompt: str) -> int:
    """
    Counts the number of explicitly numbered rules in the review prompt.
    Matches patterns like '1.', '2.' etc, not inside other text.
    """
    # Find all lines that start with a number followed by a period (rule number)
    # This is robust unless your prompt changes the numbering style.
    rule_pattern = re.compile(r'^\s*\d+\.', re.MULTILINE)
    return len(rule_pattern.findall(review_prompt))

def summary_agent(
    data,
    prompt,
    slide_number,
    model = "gpt-4o",
    max_retries = 1,
    retry_count = 0
):
    httpx_client = httpx.Client(http2=True, verify=False)
    ChatOpenAI.model_rebuild(_types_namespace={'BaseCache': BaseCache, 'Callbacks': Callbacks})
    llm = ChatOpenAI(model=model, http_client=httpx_client)

    class GraphState(TypedDict):
        summary: str
        prev_summary: str
        error: str
        error_score: float
        error_count: int
        max_retries: int
        retry_count: int

    # Generation node
    def generate_text(state: GraphState):
        eval_df = pd.DataFrame(columns=["Data Format", "Data raw"])
        data_json = data.to_json(orient='records')
        eval_df.loc[len(eval_df)] = ["JSON", data_json]

        # If we have an error or previous summary, ask to improve
        input_prompt = prompt
        if state.get("prev_summary") and state.get("error"):
            input_prompt += (
                f"\n\nThe previous summary was:\n{state['prev_summary']}\n"
                f"Feedback from review:\n{state['error']}\n"
                "Please correct the summary to address this feedback and ensure all requirements are strictly followed."
            )
        elif state.get("prev_summary"):
            input_prompt += (
                f"\n\nThe previous summary was:\n{state['prev_summary']}\n"
                "Please improve upon it according to the instructions."
            )

        def response_test(question: str, context: str, model: str):
            ChatOpenAI.model_rebuild(_types_namespace={'BaseCache': BaseCache, 'Callbacks': Callbacks})
            llm = ChatOpenAI(model=model, http_client=httpx_client)
            messages = [
                SystemMessage(content=context),
                HumanMessage(content=question)
            ]
            response = llm.invoke(messages)
            content = response.content
            content = content.strip('\n2').replace('Title:','').replace('Insights:','').strip('\n1').strip('\n3').strip('\n4').strip('  ').strip('\t').replace('"','')
            # Clean response (optional, can be tailored)
            #for ch in ['\n1', '\n2', '\n3', '\n4', 'Title:', 'Insights:', '  ', '\t', '"']:
                #content = content.replace(ch, '')
            return content

        def run_question_test(query: str, eval_df: pd.DataFrame):
            eval_df_str = eval_df.to_string()
            response = response_test(query, eval_df_str, model=model)
            return response

        result_df1 = run_question_test(input_prompt, eval_df.copy())
        

        return {
            "summary": result_df1,
        }

    # Review node using LLM
    def review_text(state: GraphState):
        summary = state.get("summary", "")
        
        # Prompt for LLM-based review
        review_prompt = get_review_prompt(column_data,summary,slide_number)

        # Use LLM to review the summary
        ChatOpenAI.model_rebuild(_types_namespace={'BaseCache': BaseCache, 'Callbacks': Callbacks})
        llm = ChatOpenAI(model=model, http_client=httpx_client)
        messages = [
            SystemMessage(content="You are a strict financial data insight reviewer. Output only actionable feedback or 'OK'."),
            HumanMessage(content=review_prompt)
        ]
        response = llm.invoke(messages)
        content = response.content.strip()

        # Determine error or not
        error = "" if content == "OK" else content
        error_count = count_errors(content) if error else 0
        total_rules = extract_rule_count(review_prompt)
        score = error_count / total_rules if total_rules > 0 else 0

        if state.get("retry_count", 0) == 0:
            print("prev_summary:", summary)
            print("prev_error:", error)
            print("error_score:", score)
            print("error_count:", error_count)

        return {
            "error": error,
            "error_score": score,
            "error_count": error_count,
            "retry_count": state.get("retry_count", 0) + (1 if error else 0),
            "prev_summary": summary,
        }

    workflow = StateGraph(GraphState)
    workflow.add_node("generate_text", generate_text)
    workflow.add_node("review_text", review_text)
    workflow.set_entry_point("generate_text")
    workflow.add_edge("generate_text", "review_text")

    def error_and_score_can_retry(state):
        # Only retry if score is above threshold and retry_count is below max_retries
        threshold_score = 0.3  # you can set e.g. if >30% of rules violated, repeat
        if state.get("error") not in (None, "", "OK") and state["retry_count"] == 1:
            return True
        return (
            state.get("error") not in (None, "", "OK") and
            state["error_score"] > threshold_score and
            state["retry_count"] < state["max_retries"]
        )

    workflow.add_conditional_edges(
        "review_text",
        lambda s: "generate_text_node" if error_and_score_can_retry(s) else "END",
        {
            "generate_text_node": "generate_text",
            "END": END,
        },
    )

    app = workflow.compile()

    response = app.invoke({
        "retry_count": retry_count,
        "max_retries": max_retries
    })
    result = response["summary"]
    insights_list = []
    insights_list = result.split('\n')
    insights_list = [insights for insights in insights_list if insights.strip()]
    insights_list = [insights for insights in insights_list if insights not in ('  ')]
    #print('Answer_list: ', insights_list)
    print("-----------------summary-----------------\n", insights_list)
    #print("-----------------prev_summary-----------------\n", response["prev_summary"])
    print("-----------------error-----------------\n", response["error"])
    print("-----------------max_retries-----------------\n", response["max_retries"])
    print("-----------------retry_count-----------------\n", response["retry_count"])

    return insights_list