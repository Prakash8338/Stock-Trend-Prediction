from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN
from pptx.dml.color import RGBColor
import io


class PPTService:
    """Service for generating PowerPoint presentations"""
    
    def generate_ppt_all(self):
        """Generate PPT for all issuers"""
        prs = Presentation()
        prs.slide_width = Inches(10)
        prs.slide_height = Inches(7.5)
        
        # Title slide
        title_slide_layout = prs.slide_layouts[6]  # Blank layout
        slide = prs.slides.add_slide(title_slide_layout)
        
        # Add title
        left = Inches(1)
        top = Inches(3)
        width = Inches(8)
        height = Inches(1.5)
        
        title_box = slide.shapes.add_textbox(left, top, width, height)
        title_frame = title_box.text_frame
        title_frame.text = "Fraud Detection Report - All Issuers"
        title_frame.paragraphs[0].font.size = Pt(54)
        title_frame.paragraphs[0].font.bold = True
        title_frame.paragraphs[0].font.color.rgb = RGBColor(0, 51, 102)
        title_frame.paragraphs[0].alignment = PP_ALIGN.CENTER
        
        # Add subtitle
        subtitle_box = slide.shapes.add_textbox(Inches(1), Inches(4.5), Inches(8), Inches(1))
        subtitle_frame = subtitle_box.text_frame
        subtitle_frame.text = "Comprehensive Analysis Report"
        subtitle_frame.paragraphs[0].font.size = Pt(24)
        subtitle_frame.paragraphs[0].alignment = PP_ALIGN.CENTER
        
        # Content slides for each issuer
        issuers = [
            {'id': 1, 'name': 'Issuer A', 'code': 'ISA'},
            {'id': 2, 'name': 'Issuer B', 'code': 'ISB'},
            {'id': 3, 'name': 'Issuer C', 'code': 'ISC'},
            {'id': 4, 'name': 'Issuer D', 'code': 'ISD'},
        ]
        
        for issuer in issuers:
            self._add_content_slide(prs, issuer)
        
        # Convert to PDF-like binary (PPT in memory)
        ppt_stream = io.BytesIO()
        prs.save(ppt_stream)
        ppt_stream.seek(0)
        return ppt_stream.getvalue()
    
    def generate_ppt_single(self, issuer_id):
        """Generate PPT for a single issuer"""
        prs = Presentation()
        prs.slide_width = Inches(10)
        prs.slide_height = Inches(7.5)
        
        # Title slide
        title_slide_layout = prs.slide_layouts[6]  # Blank layout
        slide = prs.slides.add_slide(title_slide_layout)
        
        # Map issuer IDs to issuer data
        issuers_map = {
            1: {'id': 1, 'name': 'Issuer A', 'code': 'ISA'},
            2: {'id': 2, 'name': 'Issuer B', 'code': 'ISB'},
            3: {'id': 3, 'name': 'Issuer C', 'code': 'ISC'},
            4: {'id': 4, 'name': 'Issuer D', 'code': 'ISD'},
        }
        
        issuer = issuers_map.get(issuer_id)
        if not issuer:
            raise ValueError(f"Issuer with ID {issuer_id} not found")
        
        # Add title
        left = Inches(1)
        top = Inches(3)
        width = Inches(8)
        height = Inches(1.5)
        
        title_box = slide.shapes.add_textbox(left, top, width, height)
        title_frame = title_box.text_frame
        title_frame.text = f"Fraud Detection Report - {issuer['name']}"
        title_frame.paragraphs[0].font.size = Pt(54)
        title_frame.paragraphs[0].font.bold = True
        title_frame.paragraphs[0].font.color.rgb = RGBColor(0, 51, 102)
        title_frame.paragraphs[0].alignment = PP_ALIGN.CENTER
        
        # Add subtitle
        subtitle_box = slide.shapes.add_textbox(Inches(1), Inches(4.5), Inches(8), Inches(1))
        subtitle_frame = subtitle_box.text_frame
        subtitle_frame.text = f"Code: {issuer['code']}"
        subtitle_frame.paragraphs[0].font.size = Pt(24)
        subtitle_frame.paragraphs[0].alignment = PP_ALIGN.CENTER
        
        # Add content slide
        self._add_content_slide(prs, issuer)
        
        # Convert to PDF-like binary (PPT in memory)
        ppt_stream = io.BytesIO()
        prs.save(ppt_stream)
        ppt_stream.seek(0)
        return ppt_stream.getvalue()
    
    def _add_content_slide(self, prs, issuer):
        """Add a content slide for an issuer"""
        blank_slide_layout = prs.slide_layouts[6]
        slide = prs.slides.add_slide(blank_slide_layout)
        
        # Add background color
        background = slide.background
        fill = background.fill
        fill.solid()
        fill.fore_color.rgb = RGBColor(240, 240, 240)
        
        # Add title
        title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.5), Inches(9), Inches(0.8))
        title_frame = title_box.text_frame
        title_frame.text = issuer['name']
        title_frame.paragraphs[0].font.size = Pt(40)
        title_frame.paragraphs[0].font.bold = True
        title_frame.paragraphs[0].font.color.rgb = RGBColor(0, 51, 102)
        
        # Add content
        content_box = slide.shapes.add_textbox(Inches(1), Inches(1.5), Inches(8), Inches(5.5))
        content_frame = content_box.text_frame
        content_frame.word_wrap = True
        
        # Add content text
        content_text = f"""
        Issuer Code: {issuer['code']}
        
        Key Information:
        • Analysis Period: Current Quarter
        • Risk Level: Medium
        • Status: Active Monitoring
        
        Summary:
        This report presents a comprehensive fraud detection analysis for {issuer['name']}.
        The analysis includes transaction patterns, anomaly detection, and risk assessment.
        
        Recommendations:
        • Continue regular monitoring
        • Review flagged transactions
        • Update detection rules as needed
        """
        
        content_frame.text = content_text.strip()
        for paragraph in content_frame.paragraphs:
            paragraph.font.size = Pt(14)
            paragraph.font.color.rgb = RGBColor(50, 50, 50)
