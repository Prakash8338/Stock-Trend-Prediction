from flask import Blueprint, jsonify, request, send_file
from app.services.ppt_service import PPTService
import io
import os
import sys
import pandas as pd
import subprocess
import time
import fitz  # PyMuPDF
import zipfile
from datetime import datetime
import comtypes.client
# Add parent directory to path to import from root backend folder
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from ppt_generator import generate_ppt_2, update_slide_insight
from column_data import column_data
from prompt import get_prompt
from summary_agent import summary_agent

bp = Blueprint('ppt', __name__, url_prefix='/api/ppt')

ppt_service = PPTService()

# Map issuer IDs to names
ISSUER_NAMES = {
    1: 'Bank of America',
    2: 'Navy Federal Credit Union',
}


@bp.route('/generate-all', methods=['POST'])
def generate_all_issuers():
    """Generate PowerPoint with AI insights for all issuers"""
    try:
        all_issuers_data = []
        
        # Generate PPT for each issuer using shared function
        for issuer_id, issuer_name in ISSUER_NAMES.items():
            try:
                issuer_data = generate_ppt_for_issuer(issuer_id, issuer_name)
                issuer_data['success'] = True
                all_issuers_data.append(issuer_data)
            except Exception as issuer_error:
                all_issuers_data.append({
                    'issuer_id': issuer_id,
                    'issuer_name': issuer_name,
                    'success': False,
                    'error': str(issuer_error)
                })
        
        return jsonify({
            'success': True,
            'message': 'PPT generated successfully for all issuers',
            'issuers_data': all_issuers_data
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@bp.route('/preview-all', methods=['GET'])
def preview_all():
    """Preview generation parameters for all issuers"""
    return jsonify({
        'message': 'This will generate a comprehensive report for all issuers',
        'issuers': ['Bank of America', 'Navy Federal Credit Union']
    }), 200


@bp.route('/preview-single/<int:issuer_id>', methods=['GET'])
def preview_single(issuer_id):
    """Preview generation parameters for a single issuer"""
    issuer_names = {
        1: 'Bank of America',
        2: 'Navy Federal Credit Union'
    }
    return jsonify({
        'message': f'This will generate a report for {issuer_names.get(issuer_id, "issuer")}',
        'issuer_id': issuer_id
    }), 200


@bp.route('/download-pptx/<int:issuer_id>', methods=['GET'])
def download_pptx(issuer_id):
    """Download PowerPoint file for a single issuer"""
    try:
        if issuer_id not in ISSUER_NAMES:
            return jsonify({'error': f'Issuer with ID {issuer_id} not found'}), 404
        
        issuer_name = ISSUER_NAMES[issuer_id]
        pptx_filename = f'{issuer_name}_generated_ppt.pptx'
        pptx_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'ppt_files', pptx_filename)
        
        if not os.path.exists(pptx_path):
            return jsonify({'error': f'PPTX file not found for issuer {issuer_id}'}), 404
        
        return send_file(
            pptx_path,
            mimetype='application/vnd.openxmlformats-officedocument.presentationml.presentation',
            as_attachment=True,
            download_name=pptx_filename
        )
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@bp.route('/download-default', methods=['GET'])
def download_default_pptx():
    """Download default PowerPoint template"""
    try:
        pptx_filename = 'auto_code_ppt.pptx'
        pptx_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), pptx_filename)
        
        if not os.path.exists(pptx_path):
            return jsonify({'error': 'Default PPTX file not found'}), 404
        
        return send_file(
            pptx_path,
            mimetype='application/vnd.openxmlformats-officedocument.presentationml.presentation',
            as_attachment=True,
            download_name=pptx_filename
        )
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@bp.route('/download-all-pptx', methods=['GET'])
def download_all_pptx():
    """Download all issuer PowerPoint files as a ZIP archive"""
    try:
        ppt_files_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'ppt_files')
        
        # Create an in-memory ZIP file
        memory_file = io.BytesIO()
        
        with zipfile.ZipFile(memory_file, 'w', zipfile.ZIP_DEFLATED) as zipf:
            # Add each issuer's PPTX file to the ZIP
            for issuer_id, issuer_name in ISSUER_NAMES.items():
                pptx_filename = f'{issuer_name}_generated_ppt.pptx'
                pptx_path = os.path.join(ppt_files_dir, pptx_filename)
                
                if os.path.exists(pptx_path):
                    # Add file to ZIP with a clean name
                    zipf.write(pptx_path, arcname=pptx_filename)
        
        # Seek to the beginning of the BytesIO buffer
        memory_file.seek(0)
        
        zip_filename = 'All_Issuers_Reports.zip'
        
        return send_file(
            memory_file,
            mimetype='application/zip',
            as_attachment=True,
            download_name=zip_filename
        )
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# Helper functions
def ppt_to_pdf(ppt_file):
    try:
        import pythoncom
        pythoncom.CoInitialize()
        
        powerpoint = comtypes.client.CreateObject("PowerPoint.Application")
        powerpoint.Visible = 1  # Optional: make PowerPoint visible

       
        presentation = powerpoint.Presentations.Open(ppt_file)

        
        pdf_file = ppt_file.replace('.pptx', '.pdf')

        
        presentation.SaveAs(pdf_file, 32)  # 32 is the format for PDF
        presentation.Close()

        return pdf_file

    except Exception as e:
        raise RuntimeError(f"Failed to convert PPT to PDF: {e}")

    finally:
       
        if 'powerpoint' in locals():
            powerpoint.Quit()


def pdf_to_images(pdf_file, issuer_id=None):
    """Convert PDF pages to images"""
    images = []
    document = fitz.open(pdf_file)
    zoom = 1
    mat = fitz.Matrix(zoom, zoom)
    
    for page_num in range(len(document)):
        page = document.load_page(page_num)
        pix = page.get_pixmap(matrix=mat)
        # Make image filename issuer-specific to avoid conflicts
        if issuer_id is not None:
            img_path = f"issuer_{issuer_id}_page_{page_num + 1}.png"
        else:
            img_path = f"page_{page_num + 1}.png"
        img_full_path = os.path.join(os.path.dirname(pdf_file), img_path)
        pix.save(img_full_path)
        images.append(img_full_path)
    
    document.close()
    return images


def generate_ppt_for_issuer(issuer_id, issuer_name):
    """Shared function to generate PPT with AI insights for a single issuer"""
    # Load issuer data
    df = pd.read_csv(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'issuer_data.csv'))
    template = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'auto_code_ppt.pptx')
    # Generate PPT with AI
    ppt_file, final_dict = generate_ppt_2(df, issuer_name, template)

    # Convert to PDF
    ppt_file_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'ppt_files', f'{issuer_name}_generated_ppt.pptx')
    pdf_file_path = ppt_to_pdf(os.path.abspath(ppt_file_path))
    
    # Convert PDF to images (issuer-specific)
    slide_images_paths = pdf_to_images(pdf_file_path, issuer_id)
    
    # Convert file paths to API URLs with timestamp for cache busting
    timestamp = int(time.time() * 1000)
    slide_images = []
    for i, img_path in enumerate(slide_images_paths):
        slide_images.append(f'/api/ppt/slide-images/{issuer_id}/{i + 1}?t={timestamp}')
    
    return {
        'issuer_id': issuer_id,
        'issuer_name': issuer_name,
        'ppt_file': ppt_file_path,
        'pdf_file': f'{issuer_name}_generated_ppt.pdf',
        'slide_images': slide_images,
        'insights': final_dict
    }

@bp.route('/generate-with-ai/<int:issuer_id>', methods=['POST'])
def generate_with_ai(issuer_id):
    """Generate PowerPoint with AI insights for a single issuer"""
    try:
        if issuer_id not in ISSUER_NAMES:
            return jsonify({'error': f'Issuer with ID {issuer_id} not found'}), 404
        
        issuer_name = ISSUER_NAMES[issuer_id]
        
        # Use shared function to generate PPT (same as generate-all)
        issuer_data = generate_ppt_for_issuer(issuer_id, issuer_name)
        
        return jsonify({
            'message': 'PPT generated successfully with AI insights',
            'issuer_id': issuer_data['issuer_id'],
            'issuer_name': issuer_data['issuer_name'],
            'ppt_file': issuer_data['ppt_file'],
            'pdf_file': issuer_data['pdf_file'],
            'slide_images': issuer_data['slide_images'],
            'insights': issuer_data['insights']
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@bp.route('/get-pdf/<int:issuer_id>', methods=['GET'])
def get_pdf(issuer_id):
    """Get the generated PDF for an issuer"""
    try:
        if issuer_id not in ISSUER_NAMES:
            return jsonify({'error': f'Issuer with ID {issuer_id} not found'}), 404
        
        issuer_name = ISSUER_NAMES[issuer_id]
        pdf_filename = f'{issuer_name}_generated_ppt.pdf'
        pdf_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
            'ppt_files',
            pdf_filename
        )
        
        if not os.path.exists(pdf_path):
            return jsonify({'error': f'PDF file not found for issuer {issuer_id}'}), 404
        
        return send_file(
            pdf_path,
            mimetype='application/pdf',
            as_attachment=False,
            download_name=pdf_filename
        )
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@bp.route('/slide-images/<int:issuer_id>/<int:slide_num>', methods=['GET'])
def get_slide_image(issuer_id, slide_num):
    """Get a specific slide image"""
    try:
        if issuer_id not in ISSUER_NAMES:
            return jsonify({'error': f'Issuer with ID {issuer_id} not found'}), 404
        
        issuer_name = ISSUER_NAMES[issuer_id]
        # Use issuer-specific image filename
        image_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
            'ppt_files',
            f'issuer_{issuer_id}_page_{slide_num}.png'
        )
        
        if not os.path.exists(image_path):
            return jsonify({'error': f'Slide image not found'}), 404
        
        return send_file(image_path, mimetype='image/png')
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@bp.route('/regenerate-slide/<int:issuer_id>/<int:slide_num>', methods=['POST'])
def regenerate_slide(issuer_id, slide_num):
    """Regenerate a specific slide with new AI insights"""
    try:
        if issuer_id not in ISSUER_NAMES:
            return jsonify({'error': f'Issuer with ID {issuer_id} not found'}), 404
        
        issuer_name = ISSUER_NAMES[issuer_id]
        
        # Load issuer data for this slide
        df = pd.read_csv(os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'issuer_data.csv'))
        filtered_df = df[(df['issuer'] == issuer_name) & (df['slide'] == slide_num)]
        
        # Get column data for this slide
        columns = ['Category', 'Metric', 'time_period']
        column_dict = {}
        for col in columns:
            v = list(filtered_df[col].unique())
            for key, value in column_data[col].items():
                if key in v:
                    column_dict[key] = value
        
        # Generate new insights
        prompt = get_prompt(str(column_dict), 3, slide_num)
        output_list = summary_agent(filtered_df, prompt, slide_num)
        
        # Update the PPT file
        ppt_file_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
            'ppt_files',
            f'{issuer_name}_generated_ppt.pptx'
        )
        
        update_slide_insight(ppt_file_path, slide_num, output_list)
        
        # Re-convert to PDF and update images (issuer-specific)
        pdf_file = ppt_to_pdf(os.path.abspath(ppt_file_path))
        slide_images_paths = pdf_to_images(pdf_file, issuer_id)
        
        # Convert file paths to API URLs with timestamp for cache busting
        timestamp = int(time.time() * 1000)
        slide_images = []
        for i, img_path in enumerate(slide_images_paths):
            slide_images.append(f'/api/ppt/slide-images/{issuer_id}/{i + 1}?t={timestamp}')
        
        return jsonify({
            'message': 'Slide regenerated successfully',
            'slide_num': slide_num,
            'new_insights': output_list,
            'slide_images': slide_images
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500
