from flask import Flask
from flask_cors import CORS


def create_app(config_name='development'):
    """Factory function to create Flask app"""
    app = Flask(__name__)
    
    # Enable CORS for all routes
    CORS(app)
    
    # Register blueprints
    from app.routes import issuer_routes, ppt_routes, feedback_routes
    app.register_blueprint(issuer_routes.bp)
    app.register_blueprint(ppt_routes.bp)
    app.register_blueprint(feedback_routes.bp)
    
    return app
