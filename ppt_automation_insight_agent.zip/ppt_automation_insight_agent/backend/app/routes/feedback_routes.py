from flask import Blueprint, jsonify, request
import pandas as pd
import os

bp = Blueprint('feedback', __name__, url_prefix='/api/feedback')


@bp.route('/submit', methods=['POST'])
def submit_feedback():
    """Submit feedback for a slide"""
    try:
        data = request.get_json()
        slide_key = data.get('slide_key')
        insight = data.get('insight')
        score = data.get('score')  # 1 for thumbs up, 0 for thumbs down
        
        if not all([slide_key, insight is not None, score is not None]):
            return jsonify({'error': 'Missing required fields'}), 400
        
        # Convert insight to string representation of the list (matching Streamlit CSV format)
        # Keep it as string representation of list: "['item1', 'item2', 'item3']"
        if isinstance(insight, list):
            insight_str = str(insight)  # Convert list to its string representation
        else:
            insight_str = str(insight)
        
        # Load existing feedback
        feedback_file = os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
            'feedback_data.csv'
        )
        
        try:
            feedback_df = pd.read_csv(feedback_file)
        except FileNotFoundError:
            feedback_df = pd.DataFrame(columns=['Slide', 'Insight', 'Score'])
        
        # Add new feedback
        new_row = {'Slide': slide_key, 'Insight': insight_str, 'Score': score}
        feedback_df = pd.concat([feedback_df, pd.DataFrame([new_row])], ignore_index=True)
        
        # Save to CSV
        feedback_df.to_csv(feedback_file, index=False)
        
        return jsonify({
            'message': 'Feedback submitted successfully',
            'slide_key': slide_key,
            'score': score
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@bp.route('/get/<slide_key>', methods=['GET'])
def get_feedback(slide_key):
    """Get feedback for a specific slide"""
    try:
        feedback_file = os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
            'feedback_data.csv'
        )
        
        try:
            feedback_df = pd.read_csv(feedback_file)
            slide_feedback = feedback_df[feedback_df['Slide'] == slide_key]
            
            return jsonify({
                'slide_key': slide_key,
                'feedback': slide_feedback.to_dict('records')
            }), 200
        except FileNotFoundError:
            return jsonify({
                'slide_key': slide_key,
                'feedback': []
            }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500
