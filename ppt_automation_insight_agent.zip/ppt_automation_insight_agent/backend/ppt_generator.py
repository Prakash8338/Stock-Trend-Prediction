import pptx
from pptx import Presentation
from pptx.enum.chart import *
from pptx.enum.shapes import *
from pptx.chart.data import * 
import pandas as pd
from pptx.util import Pt,Inches
from pptx.dml.color import RGBColor
import plotly.graph_objs as go
import plotly.io as pio
import os 
import sys
import time
from lxml import etree
#import kaleido

# Add insight_agent directory to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'insight_agent'))
from insight_agent import generate_insight, load_field_relations
from filter_column_data import filter_column_data_by_sheet
from column_data import column_data

def create_waterfall_data(categories,values):
    waterfall_data_2 = []
    for value in values:
        series_data = [value] * len(categories)
        waterfall_data_2.append(series_data)
    return waterfall_data_2

def parse_insight_output(insight_draft):
    """
    Parse the insight agent output to extract title and individual insights.
    Expected format:
    [Impact Label]
    1. First insight
    [Impact Label]
    2. Second insight
    ...
    
    Returns: [title, insight1_with_label, insight2_with_label, insight3_with_label, insight4_with_label]
    """
    lines = insight_draft.strip().split('\n')
    insights = []
    current_insight = ""
    current_label = ""
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
        
        # Check if line is an impact label (starts with [)
        if line.startswith('['):
            # This is an impact label, save it
            current_label = line
        # Check if line starts with a number followed by period (insight text)
        elif line and line[0].isdigit() and '. ' in line[:4]:
            if current_insight:
                insights.append(current_insight)
            # Combine label and insight text on same line with space
            current_insight = current_label + " " + line if current_label else line
            current_label = ""  # Reset label
        else:
            # Continuation of current insight
            if current_insight:
                current_insight += " " + line
    
    # Add last insight
    if current_insight:
        insights.append(current_insight)
    
    # Return only insights without title
    result = insights[:4]  # first 4 insights with labels
    while len(result) < 4:
        result.append("")
    
    return result

def generate_insight_for_slide(issuer_filter, slide_number, query_prompt, num_insights):
    """
    Generate insights for a specific slide.
    
    Args:
        issuer_filter: The issuer name
        slide_number: The slide number (1-4)
        query_prompt: The prompt for insight generation
        num_insights: Number of insights to generate
    
    Returns:
        Tuple: (List of parsed insights, time_taken_in_seconds, token_info_dict)
    """
    start_time = time.time()
    
    # Clean issuer name for file paths
    issuer_clean = issuer_filter.replace(' ', '_')
    
    # Construct pivot file path
    pivot_path = os.path.join(
        os.path.dirname(__file__), '..', 'insight_agent', 'data', 
        f"{issuer_clean}_Slide_{slide_number}_pivots.xlsx"
    )
    
    # Read first sheet from pivot file
    excel_file = pd.ExcelFile(pivot_path)
    first_sheet = excel_file.sheet_names[0]
    slide_df = pd.read_excel(pivot_path, sheet_name=first_sheet)
    
    # Get filtered column data
    filtered_column_data = filter_column_data_by_sheet(slide_df)
    
    # Load field relations
    field_relations_path = os.path.join(
        os.path.dirname(__file__), '..', 'insight_agent', 
        f'field_relations_Data_{slide_number}.txt'
    )
    field_relations = load_field_relations(field_relations_path)
    
    # Call insight agent
    result = generate_insight(
        query=query_prompt,
        data=slide_df,
        max_retries=1,
        num_insights=num_insights,
        field_relations=field_relations,
        filtered_column_data=filtered_column_data,
        data_path=pivot_path
    )
    
    # Parse output
    parsed_insights = parse_insight_output(result['draft'])
    
    end_time = time.time()
    time_taken = end_time - start_time
    
    # Extract token information if available in result
    # Note: Token tracking depends on the insight_agent implementation
    # If not available, we'll estimate based on text length
    token_info = {
        'prompt_tokens': 0,
        'completion_tokens': 0,
        'total_tokens': 0,
        'estimated': True  # Flag to indicate if tokens are estimated or actual
    }
    
    # Check if result contains token information
    if 'tokens' in result:
        token_info = result['tokens']
        token_info['estimated'] = False
    else:
        # Estimate tokens (rough approximation: 1 token ≈ 4 characters)
        draft_length = len(result.get('draft', ''))
        token_info['completion_tokens'] = draft_length // 4
        token_info['prompt_tokens'] = 2000  # Rough estimate for prompt
        token_info['total_tokens'] = token_info['prompt_tokens'] + token_info['completion_tokens']
    
    # Log timing and token information
    print(f"Slide {slide_number} insight generation took {time_taken:.2f} seconds")
    print(f"Slide {slide_number} tokens: {token_info['total_tokens']} {'(estimated)' if token_info['estimated'] else '(actual)'}")
    
    return parsed_insights, time_taken, token_info

def calculate_cost(token_info, model="gpt-4o-mini"):
    """
    Calculate cost based on token usage and model pricing.
    
    Args:
        token_info: Dictionary containing token usage information
        model: Model name for pricing lookup
    
    Returns:
        float: Cost in USD
    """
    # Pricing per 1M tokens (as of 2024)
    pricing = {
        'gpt-4o-mini': {
            'input': 0.150,   # $0.150 per 1M input tokens
            'output': 0.600   # $0.600 per 1M output tokens
        },
        'gpt-4o': {
            'input': 2.50,    # $2.50 per 1M input tokens
            'output': 10.00   # $10.00 per 1M output tokens
        },
        'gpt-5.1': {
            'input': 1.25,   # $30.00 per 1M input tokens
            'output': 10.00   # $60.00 per 1M output tokens
        }
    }
    
    # Get pricing for the model (default to gpt-4o-mini)
    model_pricing = pricing.get(model, pricing['gpt-4o-mini'])
    
    # Calculate cost
    input_cost = (token_info.get('prompt_tokens', 0) / 1_000_000) * model_pricing['input']
    output_cost = (token_info.get('completion_tokens', 0) / 1_000_000) * model_pricing['output']
    total_cost = input_cost + output_cost
    
    return total_cost

def calculate_and_display_token_cost_summary(slide_token_info, model="gpt-4o-mini"):
    """
    Calculate and display token usage and cost information for all slides.
    
    Args:
        slide_token_info: Dictionary with slide numbers as keys and token info as values
        model: Model name used for generation
    
    Returns:
        Dictionary with token and cost information
    """
    total_prompt_tokens = sum(info['prompt_tokens'] for info in slide_token_info.values())
    total_completion_tokens = sum(info['completion_tokens'] for info in slide_token_info.values())
    total_tokens = total_prompt_tokens + total_completion_tokens
    
    # Calculate costs per slide
    slide_costs = {}
    for slide_num, token_info in slide_token_info.items():
        slide_costs[slide_num] = calculate_cost(token_info, model)
    
    total_cost = sum(slide_costs.values())
    
    # Check if any tokens are estimated
    is_estimated = any(info.get('estimated', False) for info in slide_token_info.values())
    estimate_note = " (ESTIMATED)" if is_estimated else ""
    
    print("\n" + "="*60)
    print(f"TOKEN USAGE AND COST SUMMARY{estimate_note}")
    print("="*60)
    print(f"Model: {model}")
    print("-"*60)
    
    for slide_num in sorted(slide_token_info.keys()):
        token_info = slide_token_info[slide_num]
        cost = slide_costs[slide_num]
        percentage = (token_info['total_tokens'] / total_tokens * 100) if total_tokens > 0 else 0
        cost_percentage = (cost / total_cost * 100) if total_cost > 0 else 0
        
        print(f"Slide {slide_num}:")
        print(f"  Input Tokens:  {token_info['prompt_tokens']:>8,}")
        print(f"  Output Tokens: {token_info['completion_tokens']:>8,}")
        print(f"  Total Tokens:  {token_info['total_tokens']:>8,} ({percentage:>5.1f}%)")
        print(f"  Cost:          ${cost:>8.4f} ({cost_percentage:>5.1f}%)")
        print()
    
    print("-"*60)
    print(f"TOTAL:")
    print(f"  Input Tokens:  {total_prompt_tokens:>8,}")
    print(f"  Output Tokens: {total_completion_tokens:>8,}")
    print(f"  Total Tokens:  {total_tokens:>8,}")
    print(f"  Total Cost:    ${total_cost:>8.4f}")
    print("="*60 + "\n")
    
    if is_estimated:
        print("⚠️  Note: Token counts are estimated based on text length.")
        print("   For actual token usage, modify insight_agent.py to return token metadata.\n")
    
    return {
        'slide_token_info': slide_token_info,
        'slide_costs': slide_costs,
        'total_prompt_tokens': total_prompt_tokens,
        'total_completion_tokens': total_completion_tokens,
        'total_tokens': total_tokens,
        'total_cost': total_cost,
        'model': model,
        'is_estimated': is_estimated
    }

def calculate_and_display_timing(slide_timings):
    """
    Calculate and display timing information for all slides and total time.
    
    Args:
        slide_timings: Dictionary with slide numbers as keys and time taken as values
    
    Returns:
        Dictionary with timing information including total time
    """
    total_time = sum(slide_timings.values())
    
    print("\n" + "="*60)
    print("INSIGHT GENERATION TIMING SUMMARY")
    print("="*60)
    
    for slide_num, time_taken in sorted(slide_timings.items()):
        percentage = (time_taken / total_time * 100) if total_time > 0 else 0
        print(f"Slide {slide_num}: {time_taken:.2f}s ({percentage:.1f}%)")
    
    print("-"*60)
    print(f"Total Time: {total_time:.2f}s ({total_time/60:.2f} minutes)")
    print("="*60 + "\n")
    
    return {
        'slide_timings': slide_timings,
        'total_time': total_time,
        'total_time_minutes': total_time / 60
    }

def set_insight_text_with_bold_label(shape, insight_text, font_size=14):
    """
    Set insight text in a shape with bold impact label.
    Impact label (text in [brackets]) will be bold, rest will be normal.
    """
    if not shape.has_text_frame:
        return
    
    # Clear existing text
    text_frame = shape.text_frame
    text_frame.clear()
    
    # Get the first paragraph
    p = text_frame.paragraphs[0]
    
    # Check if text starts with a bracket (label on same line)
    if insight_text.startswith('['):
        # Find the closing bracket
        closing_bracket = insight_text.find(']')
        if closing_bracket != -1:
            # Extract label and rest of text
            impact_label = insight_text[:closing_bracket + 1]  # Include the closing bracket
            remaining_text = insight_text[closing_bracket + 1:]  # Text after the bracket
            
            # Add impact label as bold
            run = p.add_run()
            run.text = impact_label
            run.font.size = Pt(font_size)
            run.font.bold = True
            run.font.color.rgb = RGBColor(0, 0, 0)
            
            # Add remaining text as normal (NOT bold)
            if remaining_text:
                run = p.add_run()
                run.text = remaining_text
                run.font.size = Pt(font_size)
                run.font.bold = False
                run.font.color.rgb = RGBColor(0, 0, 0)
        else:
            # No closing bracket found, treat as normal text
            run = p.add_run()
            run.text = insight_text
            run.font.size = Pt(font_size)
            run.font.bold = False
            run.font.color.rgb = RGBColor(0, 0, 0)
    elif '\n' in insight_text:
        # Label on separate line (legacy support)
        parts = insight_text.split('\n', 1)
        impact_label = parts[0]
        insight_body = parts[1] if len(parts) > 1 else ""
        
        # Add impact label as bold
        run = p.add_run()
        run.text = impact_label
        run.font.size = Pt(font_size)
        run.font.bold = True
        run.font.color.rgb = RGBColor(0, 0, 0)
        
        # Add line break and insight body as normal text
        run = p.add_run()
        run.text = '\n' + insight_body
        run.font.size = Pt(font_size)
        run.font.bold = False
        run.font.color.rgb = RGBColor(0, 0, 0)
    else:
        # No label, just set text normally (NOT bold)
        run = p.add_run()
        run.text = insight_text
        run.font.size = Pt(font_size)
        run.font.bold = False
        run.font.color.rgb = RGBColor(0, 0, 0)

def generate_ppt_2(df,issuer_filter,template):
    filtered_df=df[(df['issuer'] == issuer_filter)]
    prs=Presentation(template)
    slide = prs.slides[0]
    for shape in slide.shapes:
        if shape.name == 'issuer_name':
            shape.text = issuer_filter
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(40)
                        run.font.color.rgb = RGBColor(255,0,0)
    query_prompt = f"""
    You are an Insight Generation Specialist trained to analyze multi-dimensional financial 
    tabular datasets across segments, metrics, time periods, and hierarchical structures. 
    Generate concise (≤50 words), precise, non-hallucinatory, non-repetitive insights. Each 
    insight must show a multi-dimensional relationship and use only values explicitly present 
    in the dataset.
    
    Follow these rules:
    1. Ensure accuracy; do not infer unprovided numbers.
    2. Avoid repeating the same metric relationship across insights.
    3. Maintain grammatical correctness and clear subject–object linkage; do not start 
    sentences with grammar modifiers (e.g., because, although, while).
    4. Use simple credit-card industry jargons but never use jargons such as activation, transaction velocity, monetization, 
    ticket size, utilization intensity, engagement depth, portfolio lift/drag, etc.
    5. Each insight must relate at least two dimensions (e.g., segment × metric, 
    metric × peer benchmark, metric × time, segment × contribution).
    6. Use crisp, consulting-style phrasing with quantified directional commentary 
    that reflects business relevance.
    
    Produce only insights with no filler commentary.
    """
    slide = prs.slides[1]
    filtered_df_2=filtered_df[filtered_df['slide'] == 1]
    
    # Generate insights for slide 1
    output_list, slide1_time, slide1_tokens = generate_insight_for_slide(issuer_filter, 1, query_prompt, num_insights=4)
    final_dict = {}
    final_dict['slide1'] = output_list
    slide_timings = {1: slide1_time}
    slide_token_info = {1: slide1_tokens}
    for shape in slide.shapes:
        if shape.name == 'issuer_name':
            shape.text = issuer_filter
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(20,52,203)
        if shape.name == 'chart_1':
            waterfall_df=filtered_df[(filtered_df['chart_type'] == 'Waterfall') & (filtered_df['Peerset'] == 0) & (filtered_df['Category'] != 'Difference')]
            cats=waterfall_df['Metric'].tolist()
            vals=waterfall_df['value'].tolist()
            waterfall_data=create_waterfall_data(cats,vals)
            chart = shape.chart
            chart_data = CategoryChartData()
            chart_data.categories = waterfall_df['Metric']
            #chart_data.add_series('Value', waterfall_df['value'])
            for i,series in enumerate(waterfall_data):
                series_name=f'Series {i + 1}'
                chart_data.add_series(series_name,series)
            chart.replace_data(chart_data)
            chart.has_legend = False
            chart.plots[0].gap_width=50
            #chart.legend.position = XL_LEGEND_POSITION.BOTTOM
            #chart.legend.include_in_layout = False
            for i in range(len(waterfall_data)):
                for j in range(len(waterfall_data)):
                    if i!=j :
                        fill = chart.series[i].points[j].format.fill
                        fill.solid()
                        fill.fore_color.rgb = RGBColor(255,255,255)
                        fill.transparency = 1
                        line = chart.series[i].points[j].format.line
                        line.fill.solid()
                        line.fill.fore_color.rgb = RGBColor(255,255,255)
                        chart.series[i].points[j].data_label.text_frame.text = ""
        if shape.name == 'peers_1':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Waterfall') & (filtered_df['Peerset']==1) & (filtered_df['Metric'] == 'New Active Cardholders'), 'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'peers_2':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Waterfall') & (filtered_df['Peerset']==1) & (filtered_df['Metric'] == 'Existing Cardholders'), 'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'peers_3':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Waterfall') & (filtered_df['Peerset']==1) & (filtered_df['Metric'] == 'Disengaged Cardholders'), 'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'peers_4':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Waterfall') & (filtered_df['Peerset']==1) & (filtered_df['Metric'] == '23 Q3-23 Q4'), 'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'oval_box':
            shape.text=str((filtered_df.loc[filtered_df['chart_type'] == 'Oval','value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'chart_2':
            waterfall_df=filtered_df[(filtered_df['chart_type'] == 'Waterfall' ) & (filtered_df['Peerset'] == 0) & (filtered_df['Category'] == 'Difference')]
            cats=waterfall_df['Metric'].tolist()
            vals=waterfall_df['value'].tolist()
            waterfall_data=create_waterfall_data(cats,vals)
            chart = shape.chart
            chart_data = CategoryChartData()
            chart_data.categories = waterfall_df['Metric']
            #chart_data.add_series('Value', waterfall_df['value'])
            for i,series in enumerate(waterfall_data):
                series_name=f'Series {i + 1}'
                chart_data.add_series(series_name,series)
            chart.replace_data(chart_data)
            chart.has_legend = False
            chart.plots[0].gap_width=50
            #chart.legend.position = XL_LEGEND_POSITION.BOTTOM
            #chart.legend.include_in_layout = False
            for i in range(len(waterfall_data)):
                for j in range(len(waterfall_data)):
                    if i!=j :
                        fill = chart.series[i].points[j].format.fill
                        fill.solid()
                        fill.fore_color.rgb = RGBColor(255,255,255)
                        fill.transparency = 1
                        line = chart.series[i].points[j].format.line
                        line.fill.solid()
                        line.fill.fore_color.rgb = RGBColor(255,255,255)
                        chart.series[i].points[j].data_label.text_frame.text = ""
            #data = go.Waterfall(x=cats,y=vals,increasing = dict(marker=dict(color='green')),decreasing=dict(marker=dict(color='red')),textposition='outside',text=['{:.1f}%'.format(value) for value in vals])
            #layout = go.Layout(title=None, xaxis=dict(tickangle=-45,automargin=True,showticklabels=False),yaxis=dict(tickangle=0,showticklabels=False,title=None,showgrid=False),showlegend=False)
            #fig=go.Figure(data=data,layout=layout)
            #image_file='waterfall_Chart.png'
            #left,top,width,height = shape.left,shape.top,shape.width,shape.height
            #pio.write_image(fig,image_file)
            #slide.shapes._spTree.remove(shape._element)
            #slide.shapes.add_picture(image_file,left,top,width=width,height=height)
        # Title removed from slides
        # if shape.name == 'title_box':
        #     shape.text= output_list[0]
        #     if shape.has_text_frame:
        #         for paragraph in shape.text_frame.paragraphs:
        #             paragraph.font.bold = True
        #             for run in paragraph.runs:
        #                 run.font.size=Pt(18)
        #                 run.font.color.rgb = RGBColor(0,0,255)
        if shape.name == 'key_insight_1':
            set_insight_text_with_bold_label(shape, output_list[0], font_size=12)
        if shape.name == 'key_insight_2':
            set_insight_text_with_bold_label(shape, output_list[1], font_size=12)
        if shape.name == 'key_insight_3':
            set_insight_text_with_bold_label(shape, output_list[2], font_size=12)
        if shape.name == 'key_insight_4':
            set_insight_text_with_bold_label(shape, output_list[3], font_size=12)
        #if shape.name == 'key_insight_1':
        #    x=filtered_df.loc[filtered_df['Metric'] == '22 Q1-22 Q4']
        #    y=filtered_df.loc[filtered_df['Metric'] == '23 Q3-23 Q4']
        #    z=filtered_df.loc[(filtered_df['Peerset'] == 1) & (filtered_df['Metric'] == '23 Q3-23 Q4')]
        #    df=pd.concat([x,y,z], axis=0)
        #   shape.text=generate_text(df,1)
        #    if shape.has_text_frame:
        #        for paragraph in shape.text_frame.paragraphs:
        #            for run in paragraph.runs:
        #                run.font.size=Pt(16)
        #                run.font.color.rgb = RGBColor(0,0,0)
        #if shape.name == 'key_insight_2':
        #   x=filtered_df.loc[(filtered_df['Peerset'] == 0) & (filtered_df['Metric'] == 'New Active Cardholders')]
        #    y=filtered_df.loc[(filtered_df['Peerset'] == 1) & (filtered_df['Metric'] == 'New Active Cardholders')]
        #    df=pd.concat([x,y], axis=0)
        #    shape.text=generate_text(df,1)
        #    if shape.has_text_frame:
        #       for paragraph in shape.text_frame.paragraphs:
        #            for run in paragraph.runs:
        #                run.font.size=Pt(16)
        #               run.font.color.rgb = RGBColor(0,0,0)
        #if shape.name == 'key_insight_3': 
        #    x=filtered_df.loc[(filtered_df['Peerset'] == 0) & (filtered_df['Metric'] == 'Existing Cardholders')]
        #    y=filtered_df.loc[(filtered_df['Peerset'] == 1) & (filtered_df['Metric'] == 'Existing Cardholders')]
        #    df=pd.concat([x,y], axis=0)
        #    shape.text=generate_text(df,1)
        #    if shape.has_text_frame:
        #        for paragraph in shape.text_frame.paragraphs:
        #            for run in paragraph.runs:
        #                run.font.size=Pt(16)
        #                run.font.color.rgb = RGBColor(0,0,0)
        #if shape.name == 'key_insight_4':
        #    x=filtered_df.loc[(filtered_df['Peerset'] == 0) & (filtered_df['Metric'] == 'Disengaged Cardholders')]
        #    y=filtered_df.loc[(filtered_df['Peerset'] == 1) & (filtered_df['Metric'] == 'Disengaged Cardholders')]
        #    df=pd.concat([x,y], axis=0)
        #    shape.text=generate_text(df,1)
        #    if shape.has_text_frame:
        #        for paragraph in shape.text_frame.paragraphs:
        #            for run in paragraph.runs:
        #                run.font.size=Pt(16)
        #               run.font.color.rgb = RGBColor(0,0,0)
    slide = prs.slides[2]
    filtered_df_2=filtered_df[filtered_df['slide'] == 2]
    
    # Generate insights for slide 2
    output_list, slide2_time, slide2_tokens = generate_insight_for_slide(issuer_filter, 2, query_prompt, num_insights=3)
    final_dict['slide2'] = output_list
    slide_timings[2] = slide2_time
    slide_token_info[2] = slide2_tokens
    for shape in slide.shapes:
        if shape.name == 'issuer_name':
            shape.text=issuer_filter
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(20,52,203)
        if shape.name == 'line_chart':
            line_df_client = filtered_df[(filtered_df['chart_type'] == 'Line') & (filtered_df['Peerset'] == 0)]
            line_df_peers = filtered_df[(filtered_df['chart_type'] == 'Line') & (filtered_df['Peerset'] == 1)]
            cats=line_df_client['Metric'].tolist()
            client_val=line_df_client['value'].tolist()
            peer_val=line_df_peers['value'].tolist()
            chart=shape.chart
            chart_data=CategoryChartData()
            chart_data.categories = cats
            chart_data.add_series('Issuer % Cards Attrited',client_val)
            chart_data.add_series('Peers % Cards Attrited',peer_val)
            chart.replace_data(chart_data)
        if shape.name == 'bar_graph':
            line_df_client = filtered_df[(filtered_df['chart_type'] == 'column') & (filtered_df['Peerset'] == 0)]
            line_df_peers = filtered_df[(filtered_df['chart_type'] == 'column') & (filtered_df['Peerset'] == 1)]
            cats=line_df_client['Metric'].tolist()
            client_val=line_df_client['value'].tolist()
            peer_val=line_df_peers['value'].tolist()
            chart=shape.chart
            chart_data=CategoryChartData()
            chart_data.categories = cats
            chart_data.add_series('Issuer PV',client_val)
            chart_data.add_series('Peers PV',peer_val)
            chart.replace_data(chart_data)
        if shape.name == 'Issuer_1':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Impact on Spend from Cardholder Disengagement'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Issuer_2':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Cards With at least 1 Authorization Decline'),'value'].values[0]) / 1000) + 'K'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Issuer_3':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Percent of Portfolio at Risk of Disengagement'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'prev_year_1':
            shape.text='(' + str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Prior') & (filtered_df['Metric'] == 'Impact on Spend from Cardholder Disengagement'),'value'].values[0]) * 100) + '%' + ')'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(10)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'prev_year_2':
            shape.text='(' + str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Prior') & (filtered_df['Metric'] == 'Cards With at least 1 Authorization Decline'),'value'].values[0]) / 1000) + 'K' + ')'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(10)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'prev_year_3':
            shape.text='(' + str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Prior') & (filtered_df['Metric'] == 'Percent of Portfolio at Risk of Disengagement'),'value'].values[0]) * 100) + '%' + ')'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(10)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Peers_1':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 1) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Impact on Spend from Cardholder Disengagement'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Peers_2':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 1) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Cards With at least 1 Authorization Decline'),'value'].values[0]) / 1000) + 'K'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Peers_3':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 1) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Percent of Portfolio at Risk of Disengagement'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Delta_1':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Category'] == 'Difference') & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Impact on Spend from Cardholder Disengagement'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Delta_2':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Category'] == 'Difference') & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Cards With at least 1 Authorization Decline'),'value'].values[0]) / 1000) + 'K'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Delta_3':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Category'] == 'Difference') & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Percent of Portfolio at Risk of Disengagement'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(14)
                        run.font.color.rgb = RGBColor(0,0,0)
        # Title removed from slides
        # if shape.name == 'title_box':
        #     shape.text= output_list[0]
        #     if shape.has_text_frame:
        #         for paragraph in shape.text_frame.paragraphs:
        #             for run in paragraph.runs:
        #                 run.font.size=Pt(18)
        #                 run.font.color.rgb = RGBColor(0,0,255)
        #                 run.font.bold = True
        if shape.name == 'key_insight_1':
            set_insight_text_with_bold_label(shape, output_list[0], font_size=12)
        if shape.name == 'key_insight_2':
            set_insight_text_with_bold_label(shape, output_list[1], font_size=12)
        if shape.name == 'key_insight_3':
            set_insight_text_with_bold_label(shape, output_list[2], font_size=12)
    slide = prs.slides[3]  # Move to slide 4
    
    # Generate insights for slide 3
    output_list, slide3_time, slide3_tokens = generate_insight_for_slide(issuer_filter, 3, query_prompt, num_insights=3)
    final_dict['slide3'] = output_list
    slide_timings[3] = slide3_time
    slide_token_info[3] = slide3_tokens

    for shape in slide.shapes:
        if shape.name == 'issuer_name':
            shape.text=issuer_filter
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(20,52,203)
        if shape.name == 'Issuer_1':
            shape.text=str(round((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'New Active Card Percentage'),'value'].values[0]) * 100, 2)) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Issuer_2':
            shape.text=str(round((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == '3 Month Purchase Active Rate'),'value'].values[0]) * 100, 2)) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Issuer_3':
            shape.text='$' + str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Spend Per Active Card'),'value'].values[0]))
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Issuer_4':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Transaction Per Active Card'),'value'].values[0]))
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Issuer_5':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Disengagement Rate'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Issuer_6':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Interchange Rate'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Issuer_7':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Authorization Rate'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Issuer_8':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Fraud Rate'),'value'].values[0])) + ' bps'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'prev_year_1':
            shape.text='(' + str(round((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Prior') & (filtered_df['Metric'] == 'New Active Card Percentage'),'value'].values[0]) * 100, 2)) + '%' + ')'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(11)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'prev_year_2':
            shape.text='(' + str(round((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Prior') & (filtered_df['Metric'] == '3 Month Purchase Active Rate'),'value'].values[0]) * 100, 2)) + '%' + ')'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(11)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'prev_year_3':
            shape.text='('+ '$' + str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Prior') & (filtered_df['Metric'] == 'Spend Per Active Card'),'value'].values[0])) + ')'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(11)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'prev_year_4':
            shape.text='(' + str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Prior') & (filtered_df['Metric'] == 'Transaction Per Active Card'),'value'].values[0])) + ')'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(11)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'prev_year_5':
            shape.text='(' + str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Prior') & (filtered_df['Metric'] == 'Disengagement Rate'),'value'].values[0]) * 100) + '%' + ')'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(11)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'prev_year_6':
            shape.text='(' + str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Prior') & (filtered_df['Metric'] == 'Interchange Rate'),'value'].values[0]) * 100) + '%' + ')'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(11)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'prev_year_7':
            shape.text='(' + str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Prior') & (filtered_df['Metric'] == 'Authorization Rate'),'value'].values[0]) * 100) + '%' + ')'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(11)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'prev_year_8':
            shape.text='(' + str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Prior') & (filtered_df['Metric'] == 'Fraud Rate'),'value'].values[0])) + ' bps' + ')'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(11)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Peers_1':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 1) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'New Active Card Percentage'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Peers_2':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 1) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == '3 Month Purchase Active Rate'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Peers_3':
            shape.text='$' + str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 1) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Spend Per Active Card'),'value'].values[0]))
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Peers_4':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 1) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Transaction Per Active Card'),'value'].values[0]))
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Peers_5':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 1) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Disengagement Rate'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Peers_6':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 1) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Interchange Rate'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Peers_7':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 1) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Authorization Rate'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Peers_8':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Peerset'] == 1) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Fraud Rate'),'value'].values[0])) + ' bps'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Delta_1':
            shape.text=str(round((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Category'] == 'Difference') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'New Active Card Percentage'),'value'].values[0]) * 100, 2)) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Delta_2':
            shape.text=str(round((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Category'] == 'Difference') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == '3 Month Purchase Active Rate'),'value'].values[0]) * 100, 2)) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Delta_3':
            shape.text='$' + str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Category'] == 'Difference') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Spend Per Active Card'),'value'].values[0]))
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Delta_4':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Category'] == 'Difference') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Transaction Per Active Card'),'value'].values[0]))
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Delta_5':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Category'] == 'Difference') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Disengagement Rate'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Delta_6':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Category'] == 'Difference') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Interchange Rate'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Delta_7':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Category'] == 'Difference') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Authorization Rate'),'value'].values[0]) * 100) + '%'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'Delta_8':
            shape.text=str((filtered_df.loc[(filtered_df['chart_type'] == 'Metric') & (filtered_df['Category'] == 'Difference') & (filtered_df['Peerset'] == 0) & (filtered_df['time_period'] == 'Current') & (filtered_df['Metric'] == 'Fraud Rate'),'value'].values[0])) + ' bps'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        # Title removed from slides
        # if shape.name == 'title_box':
        #     shape.text= output_list[0]
        #     if shape.has_text_frame:
        #         for paragraph in shape.text_frame.paragraphs:
        #             for run in paragraph.runs:
        #                 run.font.size=Pt(18)
        #                 run.font.color.rgb = RGBColor(0,0,255)
        #                 run.font.bold = True
        if shape.name == 'key_insight_1':
            set_insight_text_with_bold_label(shape, output_list[0], font_size=12)
        if shape.name == 'key_insight_2':
            set_insight_text_with_bold_label(shape, output_list[1], font_size=12)
        if shape.name == 'key_insight_3':
            set_insight_text_with_bold_label(shape, output_list[2], font_size=12)
    slide = prs.slides[4]  # Move to slide 5
    filtered_df_4=filtered_df[filtered_df['slide'] == 4]
    
    # Generate insights for slide 4
    output_list, slide4_time, slide4_tokens = generate_insight_for_slide(issuer_filter, 4, query_prompt, num_insights=2)
    final_dict['slide4'] = output_list
    slide_timings[4] = slide4_time
    slide_token_info[4] = slide4_tokens
    for shape in slide.shapes:
        if shape.name == 'issuer_name':
            shape.text=issuer_filter
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(20,52,203)
        if shape.name == 'bar_graph':
            line_df_client = filtered_df_4[(filtered_df_4['chart_type'] == 'Bar') & (filtered_df['Peerset'] == 0)]
            line_df_peers = filtered_df_4[(filtered_df_4['chart_type'] == 'Bar') & (filtered_df['Peerset'] == 1)]
            cats=line_df_client['Metric'].tolist()
            client_val=line_df_client['value'].tolist()
            peer_val=line_df_peers['value'].tolist()
            chart=shape.chart
            chart_data=CategoryChartData()
            chart_data.categories = cats
            chart_data.add_series('Peer',peer_val)
            chart_data.add_series('Issuer',client_val)
            chart.replace_data(chart_data)
        if shape.name == 'donought_graph':
            line_df_client = filtered_df_4[(filtered_df_4['chart_type'] == 'Donought') & (filtered_df['Peerset'] == 0)]
            cats=line_df_client['Metric'].tolist()
            client_val=line_df_client['value'].tolist()
            chart=shape.chart
            chart_data=CategoryChartData()
            chart_data.categories = cats
            chart_data.add_series('value',client_val)
            chart.replace_data(chart_data)
        if shape.name == 'value_1':
            shape.text=str((filtered_df_4.loc[(filtered_df_4['chart_type'] == 'Donought')  & (filtered_df_4['Metric'] == 'No Negative Effect'),'value'].values[0])) + 'K'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'value_2':
            shape.text=str((filtered_df_4.loc[(filtered_df_4['chart_type'] == 'Donought')  & (filtered_df_4['Metric'] == 'Drop In Spend'),'value'].values[0])) + 'K'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'value_3':
            shape.text=str((filtered_df_4.loc[(filtered_df_4['chart_type'] == 'Donought')  & (filtered_df_4['Metric'] == 'Card Dormancy'),'value'].values[0])) + 'K'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'value_4':
            shape.text='$' + str((filtered_df_4.loc[(filtered_df_4['chart_type'] == 'Metric')  & (filtered_df_4['Metric'] == 'Drop In Spend'),'value'].values[0])) + 'M'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'value_5':
            shape.text='$' + str((filtered_df_4.loc[(filtered_df['chart_type'] == 'Metric')  & (filtered_df['Metric'] == 'Card Dormancy'),'value'].values[0])) + 'M'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        if shape.name == 'total_value':
            first_value = float((filtered_df_4.loc[(filtered_df_4['chart_type'] == 'Donought')  & (filtered_df_4['Metric'] == 'No Negative Effect'),'value'].values[0]))
            second_value = float((filtered_df_4.loc[(filtered_df_4['chart_type'] == 'Donought')  & (filtered_df_4['Metric'] == 'Drop In Spend'),'value'].values[0]))
            third_value = float((filtered_df_4.loc[(filtered_df_4['chart_type'] == 'Donought')  & (filtered_df_4['Metric'] == 'Card Dormancy'),'value'].values[0]))
            total = first_value + second_value + third_value
            shape.text=str(total) + 'K'
            if shape.has_text_frame:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        run.font.size=Pt(12)
                        run.font.color.rgb = RGBColor(0,0,0)
        # Title removed from slides
        # if shape.name == 'title_box':
        #     shape.text= output_list[0]
        #     if shape.has_text_frame:
        #         for paragraph in shape.text_frame.paragraphs:
        #             for run in paragraph.runs:
        #                 run.font.size=Pt(18)
        #                 run.font.color.rgb = RGBColor(0,0,255)
        #                 run.font.bold = True
        if shape.name == 'key_insight_1':
            set_insight_text_with_bold_label(shape, output_list[0], font_size=12)
        if shape.name == 'key_insight_2':
            set_insight_text_with_bold_label(shape, output_list[1], font_size=12)
    
    # Calculate and display token usage and cost information
    token_cost_info = calculate_and_display_token_cost_summary(slide_token_info, model="gpt-4o-mini")
    
    # Calculate and display timing information
    timing_info = calculate_and_display_timing(slide_timings)
    
    output_dir='ppt_files'
    if not os.path.exists(output_dir):
        os.mkdir(output_dir)
    ppt_file=f"{output_dir}/{issuer_filter}_generated_ppt.pptx"
    prs.save(ppt_file)
    return ppt_file, final_dict, token_cost_info, timing_info

def update_slide_insight(ppt_file, slide_num, new_insights):
    prs = Presentation(ppt_file)
    # slide_num is 1-based from frontend, but prs.slides is 0-based
    slide = prs.slides[slide_num - 1]
    for shape in slide.shapes:
        if hasattr(shape, 'name'):
            # Title removed from slides
            # if shape.name in ['title_box', 'title'] and len(new_insights) > 0:
            #     shape.text = new_insights[0]
            #     if shape.has_text_frame:
            #         for paragraph in shape.text_frame.paragraphs:
            #             paragraph.font.bold = True
            #             for run in paragraph.runs:
            #                 run.font.size = Pt(18)
            #                 run.font.color.rgb = RGBColor(0, 0, 255)
            if shape.name in ['key_insight_1', 'insights_1'] and len(new_insights) > 0:
                set_insight_text_with_bold_label(shape, new_insights[0], font_size=12)
            if shape.name in ['key_insight_2', 'insights_2'] and len(new_insights) > 1:
                set_insight_text_with_bold_label(shape, new_insights[1], font_size=12)
            if shape.name in ['key_insight_3', 'insights_3'] and len(new_insights) > 2:
                set_insight_text_with_bold_label(shape, new_insights[2], font_size=12)
            if shape.name in ['key_insight_4', 'insights_4'] and len(new_insights) > 3:
                set_insight_text_with_bold_label(shape, new_insights[3], font_size=12)
    prs.save(ppt_file)


