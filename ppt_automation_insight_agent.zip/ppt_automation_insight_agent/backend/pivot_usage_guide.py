"""
Integration Guide: Using Slide Pivots in PPT Generator

This guide shows how to use slide_pivot.py functions in your ppt_generator.py
"""

# ============================================================================
# BASIC USAGE EXAMPLES
# ============================================================================

from slide_pivot import create_slide_pivot, create_chart_pivot, create_all_slides_pivots
import pandas as pd

# Load your data
df = pd.read_csv('issuer_data.csv')
issuer_name = "Bank of America"

# ----------------------------------------------------------------------------
# EXAMPLE 1: Get pivot for entire slide
# ----------------------------------------------------------------------------

# Get Slide 1 pivot (Metric x Category)
slide1_pivot = create_slide_pivot(df, issuer_name, 1, 'category')
# Result columns: Difference, Issuer, Peers, issuer growth
# Access specific values:
issuer_value = slide1_pivot.loc['New Active Cardholders', 'Issuer']  # 0.19
peers_value = slide1_pivot.loc['New Active Cardholders', 'Peers']    # 0.20


# ----------------------------------------------------------------------------
# EXAMPLE 2: Get pivot for specific chart type
# ----------------------------------------------------------------------------

# Get waterfall chart data only
waterfall = create_chart_pivot(df, issuer_name, 1, 'Waterfall', 'category')
# Cleaner data - only waterfall metrics

# Get line chart data (time series)
line_chart = create_chart_pivot(df, issuer_name, 2, 'Line', 'time')
# Result: Metric x time_period


# ----------------------------------------------------------------------------
# EXAMPLE 3: Different pivot types
# ----------------------------------------------------------------------------

# Pivot by Category (Metric x Category)
pivot_cat = create_slide_pivot(df, issuer_name, 2, 'category')

# Pivot by Time (Metric x time_period) 
pivot_time = create_slide_pivot(df, issuer_name, 2, 'time')

# Pivot by both (Metric x Category x time_period)
pivot_both = create_slide_pivot(df, issuer_name, 2, 'category_time')


# ----------------------------------------------------------------------------
# EXAMPLE 4: Get all slides at once
# ----------------------------------------------------------------------------

all_slides = create_all_slides_pivots(df, issuer_name, 'category')
# Returns: {1: pivot_df_1, 2: pivot_df_2, 3: pivot_df_3, ...}

slide1 = all_slides[1]
slide2 = all_slides[2]


# ============================================================================
# INTEGRATION WITH YOUR PPT_GENERATOR.PY
# ============================================================================

"""
BEFORE (your current code in ppt_generator.py):
"""
def old_approach(filtered_df):
    # Multiple filter operations
    waterfall_df = filtered_df[
        (filtered_df['chart_type'] == 'Waterfall') & 
        (filtered_df['Peerset'] == 0) & 
        (filtered_df['Category'] != 'Difference')
    ]
    cats = waterfall_df['Metric'].tolist()
    vals = waterfall_df['value'].tolist()
    
    # Get peer values with complex filtering
    peers_val = filtered_df.loc[
        (filtered_df['chart_type'] == 'Waterfall') & 
        (filtered_df['Peerset'] == 1) & 
        (filtered_df['Metric'] == 'New Active Cardholders'), 
        'value'
    ].values[0]


"""
AFTER (using slide_pivot):
"""
from slide_pivot import create_chart_pivot

def new_approach(df, issuer_filter, slide_num):
    # Get waterfall pivot table
    waterfall = create_chart_pivot(df, issuer_filter, slide_num, 'Waterfall', 'category')
    
    # Extract issuer data
    cats = waterfall.index.tolist()  # Metric names
    vals = waterfall['Issuer'].tolist()  # Issuer values
    
    # Get peer value directly
    peers_val = waterfall.loc['New Active Cardholders', 'Peers']
    
    # Get difference
    diff_val = waterfall.loc['New Active Cardholders', 'Difference']


# ============================================================================
# SPECIFIC USE CASES FOR EACH SLIDE
# ============================================================================

def slide_1_data(df, issuer):
    """Slide 1: Waterfall Chart"""
    # Get waterfall pivot
    waterfall = create_chart_pivot(df, issuer, 1, 'Waterfall', 'category')
    
    # For chart - Issuer data
    issuer_categories = waterfall.index.tolist()
    issuer_values = waterfall['Issuer'].fillna(0).tolist()
    
    # For chart - Peers data  
    peers_values = waterfall['Peers'].fillna(0).tolist()
    
    # For text boxes - specific peer comparisons
    peers_new_active = waterfall.loc['New Active Cardholders', 'Peers']
    peers_existing = waterfall.loc['Existing Cardholders', 'Peers']
    peers_disengaged = waterfall.loc['Disengaged Cardholders', 'Peers']
    
    # For oval box - get growth
    oval_val = create_chart_pivot(df, issuer, 1, 'Oval', 'category')
    growth = oval_val.loc['issuer growth', 'issuer growth']
    
    return {
        'categories': issuer_categories,
        'issuer_values': issuer_values,
        'peers_values': peers_values,
        'peers_new_active': peers_new_active,
        'peers_existing': peers_existing,
        'peers_disengaged': peers_disengaged,
        'growth': growth
    }


def slide_2_data(df, issuer):
    """Slide 2: Metrics + Line + Column Charts"""
    # Metrics with time comparison
    metrics = create_chart_pivot(df, issuer, 2, 'Metric', 'category_time')
    
    # Extract current and prior values for issuer
    impact_current = metrics.loc['Impact on Spend from Cardholder Disengagement', ('Issuer', 'Current')]
    impact_prior = metrics.loc['Impact on Spend from Cardholder Disengagement', ('Issuer', 'Prior')]
    
    cards_current = metrics.loc['Cards With at least 1 Authorization Decline', ('Issuer', 'Current')]
    cards_prior = metrics.loc['Cards With at least 1 Authorization Decline', ('Issuer', 'Prior')]
    
    # Line chart - % Cards Attrited over time
    line_data = create_chart_pivot(df, issuer, 2, 'Line', 'time')
    time_periods = line_data.index.tolist()
    
    # Need to separate issuer and peers from line chart
    # Use category_time pivot for line chart
    line_full = create_chart_pivot(df, issuer, 2, 'Line', 'category_time')
    # This won't work well, need different approach...
    
    # Better: filter and then pivot by metric
    line_df = df[(df['issuer'] == issuer) & (df['slide'] == 2) & (df['chart_type'] == 'Line')]
    line_pivot = pd.pivot_table(
        line_df,
        index='time_period',
        columns='Metric',
        values='value'
    )
    
    return {
        'metrics': metrics,
        'line_data': line_pivot,
    }


def slide_3_data(df, issuer):
    """Slide 3: Activation Metrics"""
    # Get all metrics with category and time
    metrics = create_chart_pivot(df, issuer, 3, 'Metric', 'category_time')
    
    # Extract values
    new_active_current = metrics.loc['New Active Card Percentage', ('Issuer', 'Current')]
    new_active_prior = metrics.loc['New Active Card Percentage', ('Issuer', 'Prior')]
    new_active_peers = metrics.loc['New Active Card Percentage', ('Peers', 'Current')]
    
    return {
        'metrics': metrics,
        'new_active_current': new_active_current,
        'new_active_prior': new_active_prior,
        'new_active_peers': new_active_peers
    }


# ============================================================================
# QUICK REFERENCE: Accessing Values from Pivot Tables
# ============================================================================

# Single index pivot (Metric x Category)
pivot = create_chart_pivot(df, issuer, 1, 'Waterfall', 'category')
value = pivot.loc['New Active Cardholders', 'Issuer']

# Multi-index pivot (Metric x Category x time_period)  
pivot = create_chart_pivot(df, issuer, 2, 'Metric', 'category_time')
value = pivot.loc['Impact on Spend from Cardholder Disengagement', ('Issuer', 'Current')]

# Get entire column
issuer_column = pivot['Issuer']  # Returns Series

# Get entire row
metric_row = pivot.loc['New Active Card Percentage']  # Returns Series

# Convert to lists for charts
categories = pivot.index.tolist()
values = pivot['Issuer'].tolist()

# Handle NaN values
values_no_nan = pivot['Issuer'].fillna(0).tolist()
