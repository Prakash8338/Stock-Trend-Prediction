"""
Streamlit Web Application for Insight Generation Agent

Simple interface: User input → Generate → Summary display
"""

import streamlit as st
import pandas as pd
from insight_agent import generate_insight
from column_data import column_data
from filter_column_data import filter_column_data_by_sheet
import os
import glob

# Page configuration
st.set_page_config(
    page_title="Insight Generation Agent",
    page_icon="📊",
    layout="wide"
)

# Custom CSS
st.markdown("""
    <style>
    .main-header {
        font-size: 2.5rem;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 1rem;
    }
    .summary-box {
        background-color: #f8f9fa;
        padding: 2rem;
        border-radius: 10px;
        border-left: 5px solid #1f77b4;
        margin: 2rem 0;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    .user-input-box {
        background-color: #e8f4f8;
        padding: 1.5rem;
        border-radius: 8px;
        border: 1px solid #b8d4e0;
        margin: 1rem 0;
    }
    .stButton>button {
        width: 100%;
        background-color: #1f77b4;
        color: white;
        font-size: 1.1rem;
        padding: 0.75rem;
        border-radius: 8px;
    }
    .insight-item {
        background-color: #ffffff;
        padding: 1.2rem;
        margin: 0.8rem 0;
        border-radius: 8px;
        border-left: 4px solid #1f77b4;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
    .insight-number {
        display: inline-block;
        background-color: #1f77b4;
        color: white;
        font-weight: bold;
        padding: 0.3rem 0.7rem;
        border-radius: 50%;
        margin-right: 0.8rem;
        font-size: 0.9rem;
    }
    .insight-text {
        display: inline;
        line-height: 1.8;
        color: #333;
    }
    .impact-label {
        display: inline-block;
        padding: 0.4rem 0.9rem;
        border-radius: 6px;
        font-weight: 600;
        font-size: 0.85rem;
        margin-bottom: 0.5rem;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .impact-massive {
        background: linear-gradient(135deg, #dc2626 0%, #ef4444 100%);
        color: white;
        border: 2px solid #dc2626;
    }
    .impact-significant {
        background: linear-gradient(135deg, #ea580c 0%, #f97316 100%);
        color: white;
        border: 2px solid #ea580c;
    }
    .impact-moderate {
        background: linear-gradient(135deg, #d97706 0%, #f59e0b 100%);
        color: white;
        border: 2px solid #d97706;
    }
    .impact-minor {
        background: linear-gradient(135deg, #0891b2 0%, #06b6d4 100%);
        color: white;
        border: 2px solid #0891b2;
    }
    .impact-negligible {
        background: linear-gradient(135deg, #64748b 0%, #94a3b8 100%);
        color: white;
        border: 2px solid #64748b;
    }
    </style>
    """, unsafe_allow_html=True)

# Header
st.markdown('<h1 class="main-header">📊 Insight Generation Agent</h1>', unsafe_allow_html=True)
st.markdown('<p style="text-align: center; color: #666;">Generate meaningful insights from your financial KPI data</p>', unsafe_allow_html=True)
st.markdown("---")

# Sidebar for configuration
with st.sidebar:
    st.header("⚙️ Settings")
    
    # Sheet Selection
    st.subheader("📋 Data Sheet Selection")
    
    # Get available sheets from Excel file
    excel_file_path = "data/mockup_data_all.xlsx"
    try:
        xl_file = pd.ExcelFile(excel_file_path)
        available_sheets = xl_file.sheet_names
    except:
        available_sheets = []
        st.error("⚠️ Could not load Excel file")
    
    # Create sheet selector
    selected_sheet = st.selectbox(
        "Select Data Sheet",
        options=available_sheets,
        index=0 if available_sheets else None,
        help="Choose which data sheet to analyze"
    )
    
    # Display info about selected sheet
    if selected_sheet:
        st.info(f"📊 Analyzing: **{selected_sheet}**")
    
    st.markdown("---")
    
    max_retries = st.slider(
        "Max Retries",
        min_value=1,
        max_value=10,
        value=1,
        help="Maximum iterations for refinement"
    )
    
    num_insights = st.slider(
        "Number of Insights",
        min_value=3,
        max_value=12,
        value=3,
        help="Number of insights to generate"
    )
    
    st.markdown("---")
    
    st.subheader("💡 Example Queries")
    examples = [
        "Analyze the issuer's disengagement rate increase and its impact on active card metrics",
        "Compare issuer vs peer performance across all KPIs and identify key gaps",
        "What's driving the decline in 3 Month Purchase Active Rate despite growth in spend?",
        "Analyze the fraud rate situation and its relationship with authorization and decline rates",
        "Evaluate year-over-year improvements and explain the spend per active card growth"
    ]
    
    for i, example in enumerate(examples, 1):
        if st.button(f"📌 Example {i}", key=f"ex_{i}", use_container_width=True, help=example):
            st.session_state.query_text = example
            st.rerun()

# Initialize session state
if 'query_text' not in st.session_state:
    st.session_state.query_text = ""
if 'result' not in st.session_state:
    st.session_state.result = None

# Main content area
st.subheader("📝 Enter Your Query")

# User input
query = st.text_area(
    "What insights would you like to generate?",
    value=st.session_state.query_text,
    height=120,
    placeholder="Example: Analyze fraud trends for Bank of America and explain how they relate to payment volumes..."
)

# Generate button
col1, col2, col3 = st.columns([1, 2, 1])
with col2:
    generate_button = st.button("🚀 Generate Insight", type="primary", use_container_width=True)

st.markdown("---")

# Generate insight
if generate_button:
    if not query.strip():
        st.error("⚠️ Please enter a query!")
    elif not selected_sheet:
        st.error("⚠️ Please select a data sheet!")
    elif not os.getenv("OPENAI_API_KEY"):
        st.error("⚠️ OPENAI_API_KEY not found! Please set it in your .env file.")
    else:
        try:
            # Load data from selected sheet
            with st.spinner(f"📊 Loading data from '{selected_sheet}'..."):
                df = pd.read_excel(excel_file_path, sheet_name=selected_sheet)
            
            # Load field relations for selected sheet
            with st.spinner("🔗 Loading field relations..."):
                # Map sheet name to field relations file
                # Handle spaces in sheet names for file matching
                sheet_name_normalized = selected_sheet.replace(' ', '_')
                field_relations_file = f"field_relations_{sheet_name_normalized}.txt"
                
                # Check if file exists
                if os.path.exists(field_relations_file):
                    with open(field_relations_file, 'r', encoding='utf-8') as f:
                        field_relations = f.read()
                else:
                    st.warning(f"⚠️ Field relations file not found: {field_relations_file}")
                    field_relations = "No field relations available for this sheet."
            
            # Filter column_data based on sheet columns
            with st.spinner("📋 Filtering column metadata..."):
                # Check if data has a 'Metric' or 'Metric ' column (pivoted format)
                metric_col = None
                for col in df.columns:
                    if col.strip().lower() == 'metric':
                        metric_col = col
                        break
                
                # Also check for 'Category' column (alternative naming)
                if not metric_col:
                    for col in df.columns:
                        if col.strip().lower() == 'category':
                            metric_col = col
                            break
                
                if metric_col:
                    # Extract metric names from the Metric/Category column
                    metric_names = df[metric_col].tolist()
                    filtered_column_data = filter_column_data_by_sheet(metric_names, column_data)
                else:
                    # Use column names directly
                    filtered_column_data = filter_column_data_by_sheet(df, column_data)
                st.info(f"Found metadata for {len(filtered_column_data)} metrics in '{selected_sheet}'")
            
            # Generate insight with progress updates
            with st.spinner("Generating insight... The agent is analyzing your data and refining the response."):
                result = generate_insight(
                    query=query,
                    data=df,
                    max_retries=max_retries,
                    num_insights=num_insights,
                    field_relations=field_relations,
                    filtered_column_data=filtered_column_data
                )
                # Store result with query and sheet info
                st.session_state.result = result
                st.session_state.current_query = query
                st.session_state.current_sheet = selected_sheet
            
            # Display results directly (no placeholder needed)
            if True:
                st.success("✅ Insight Generated Successfully!")
                
                # Show data sheet used
                st.info(f"📊 Data Source: **{selected_sheet}** | Columns Analyzed: **{len(filtered_column_data)}**")
                
                # Show user input recap
                st.markdown("### 📥 Your Query")
                query_display = result.get("query", query)
                st.write(query_display)
                
                # Show summary with proper structure
                st.markdown("### 📊 Generated Insights")
                draft = result.get("draft", "No summary generated")
                
                # Parse and format insights if they are numbered
                import re
                insights = draft.split('\n')
                formatted_insights = []
                
                def make_numbers_bold(text):
                    """Make all numeric values bold in the text"""
                    # Pattern to match numbers with optional %, $, commas, decimals, and parentheses
                    pattern = r'([$]?[-]?[0-9]{1,3}(?:,[0-9]{3})*(?:\.[0-9]+)?[%]?|\([0-9,]+\)(?:\.\d+)?|\d+\.\d+%?)'
                    return re.sub(pattern, r'<strong>\1</strong>', text)
                
                def get_impact_class(impact_label):
                    """Get CSS class based on impact level"""
                    if 'Massive' in impact_label:
                        return 'impact-massive'
                    elif 'Significant' in impact_label:
                        return 'impact-significant'
                    elif 'Moderate' in impact_label:
                        return 'impact-moderate'
                    elif 'Minor' in impact_label:
                        return 'impact-minor'
                    else:
                        return 'impact-negligible'
                
                current_impact_label = None
                for line in insights:
                    line = line.strip()
                    # Check if line is an impact label
                    if line.startswith('[') and 'Impact' in line and 'Score:' in line:
                        current_impact_label = line
                        continue
                    
                    if line and line[0].isdigit() and '. ' in line:
                        # Extract number and text
                        parts = line.split('. ', 1)
                        if len(parts) == 2:
                            number = parts[0]
                            text = parts[1].replace('*', '')  # Remove asterisks
                            text_with_bold_numbers = make_numbers_bold(text)
                            
                            # Add impact label if available
                            impact_html = ''
                            if current_impact_label:
                                impact_class = get_impact_class(current_impact_label)
                                # Remove brackets from impact label
                                clean_label = current_impact_label.strip('[]')
                                impact_html = f'<div style="margin-bottom: 0.5rem;"><span class="impact-label {impact_class}">{clean_label}</span></div>'
                                current_impact_label = None  # Reset after use
                            
                            formatted_insights.append(f'<div class="insight-item">{impact_html}<span class="insight-number">{number}</span><span class="insight-text">{text_with_bold_numbers}</span></div>')
                        else:
                            formatted_insights.append(line.replace('*', ''))
                    elif line:
                        formatted_insights.append(line.replace('*', ''))
                
                if formatted_insights:
                    st.markdown('\n'.join(formatted_insights), unsafe_allow_html=True)
                else:
                    st.write(draft)
                
                # Show metadata in expandable section
                with st.expander("📈 Generation Details"):
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Iterations", result.get('retry_count', 0))
                    with col2:
                        evaluation = result.get('evaluation', '')
                        status = "✓ Passed" if evaluation.strip().upper() == "OK" else "⚠ Max Retries"
                        st.metric("Status", status)
                    with col3:
                        st.metric("Max Retries", result.get('max_retries', 3))
                    
                    if result.get('retry_count', 0) > 0 and result.get('reflexion_text'):
                        st.markdown("**🔄 Learning Process:**")
                        st.info(result.get('reflexion_text', ''))
            
        except Exception as e:
            st.error(f"❌ Error: {str(e)}")

# Show previous result if exists (when page loads)
elif st.session_state.result:
    result = st.session_state.result
    
    st.success("✅ Previous Result")
    
    # Show data sheet used if available
    if 'current_sheet' in st.session_state:
        st.info(f"📊 Data Source: **{st.session_state.current_sheet}**")
    
    # Show user input recap
    st.markdown("### 📥 Your Query")
    query_display = result.get("query", st.session_state.get("current_query", ""))
    st.write(query_display)
    
    # Show summary
    st.markdown("### 📊 Generated Insights")
    draft = result.get("draft", "No summary generated")
    
    # Parse and format insights if they are numbered
    import re
    insights = draft.split('\n')
    formatted_insights = []
    
    def make_numbers_bold(text):
        """Make all numeric values bold in the text"""
        # Pattern to match numbers with optional %, $, commas, decimals, and parentheses
        pattern = r'([$]?[-]?[0-9]{1,3}(?:,[0-9]{3})*(?:\.[0-9]+)?[%]?|\([0-9,]+\)(?:\.\d+)?|\d+\.\d+%?)'
        return re.sub(pattern, r'<strong>\1</strong>', text)
    
    def get_impact_class(impact_label):
        """Get CSS class based on impact level"""
        if 'Massive' in impact_label:
            return 'impact-massive'
        elif 'Significant' in impact_label:
            return 'impact-significant'
        elif 'Moderate' in impact_label:
            return 'impact-moderate'
        elif 'Minor' in impact_label:
            return 'impact-minor'
        else:
            return 'impact-negligible'
    
    current_impact_label = None
    for line in insights:
        line = line.strip()
        # Check if line is an impact label
        if line.startswith('[') and 'Impact' in line and 'Score:' in line:
            current_impact_label = line
            continue
        
        if line and line[0].isdigit() and '. ' in line:
            # Extract number and text
            parts = line.split('. ', 1)
            if len(parts) == 2:
                number = parts[0]
                text = parts[1].replace('*', '')  # Remove asterisks
                text_with_bold_numbers = make_numbers_bold(text)
                
                # Add impact label if available
                impact_html = ''
                if current_impact_label:
                    impact_class = get_impact_class(current_impact_label)
                    # Remove brackets from impact label
                    clean_label = current_impact_label.strip('[]')
                    impact_html = f'<div style="margin-bottom: 0.5rem;"><span class="impact-label {impact_class}">{clean_label}</span></div>'
                    current_impact_label = None  # Reset after use
                
                formatted_insights.append(f'<div class="insight-item">{impact_html}<span class="insight-number">{number}</span><span class="insight-text">{text_with_bold_numbers}</span></div>')
            else:
                formatted_insights.append(line.replace('*', ''))
        elif line:
            formatted_insights.append(line.replace('*', ''))
    
    if formatted_insights:
        st.markdown('\n'.join(formatted_insights), unsafe_allow_html=True)
    else:
        st.write(draft)
    
    # Show metadata in expandable section
    with st.expander("📈 Generation Details"):
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Iterations", result.get('retry_count', 0))
        with col2:
            evaluation = result.get('evaluation', '')
            status = "✓ Passed" if evaluation.strip().upper() == "OK" else "⚠ Max Retries"
            st.metric("Status", status)
        with col3:
            st.metric("Max Retries", result.get('max_retries', 3))
        
        if result.get('retry_count', 0) > 0 and result.get('reflexion_text'):
            st.markdown("**🔄 Learning Process:**")
            st.info(result.get('reflexion_text', ''))

# Footer
st.markdown("---")
st.markdown("""
<div style='text-align: center; color: #888; padding: 1rem;'>
    <p>Powered by LangGraph & OpenAI GPT-4 | Built with Streamlit</p>
</div>
""", unsafe_allow_html=True)
