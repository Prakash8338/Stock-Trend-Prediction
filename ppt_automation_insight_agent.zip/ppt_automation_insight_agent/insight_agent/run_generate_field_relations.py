"""
Script to trigger field relations generation for different data sheets.
This script allows you to generate field relations using filtered column data.
"""

import pandas as pd
from filter_column_data import filter_column_data_by_sheet
from generate_field_relations import main


def generate_for_sheet(file_path: str, sheet_name: str, data_name: str):
    """
    Generate field relations for a specific sheet.
    
    Args:
        file_path: Path to the Excel file
        sheet_name: Name of the sheet to process
        data_name: Name to use for the output file (e.g., 'sheet1' -> 'field_relations_sheet1.txt')
    """
    print(f"\n{'='*80}")
    print(f"Processing: {sheet_name}")
    print(f"{'='*80}\n")
    
    # Load the data
    df = pd.read_excel(file_path, sheet_name=sheet_name)
    print(f"Loaded {len(df)} rows and {len(df.columns)} columns from {sheet_name}")
    
    # Check if 'Metric' or 'Category' column exists (data in rows format)
    metric_col = None
    for col in ['Metric', 'Metrics', 'Category', 'Category ']:
        if col in df.columns:
            metric_col = col
            break
    
    if metric_col:
        # Extract metric names from the Metric/Category column and strip whitespace
        metric_names = [str(m).strip() for m in df[metric_col].tolist()]
        print(f"Found metrics in rows (column: '{metric_col}'): {metric_names}")
        
        # Filter column data based on the metric names
        filtered_data = filter_column_data_by_sheet(metric_names)
    else:
        # Original behavior: metrics are column names
        filtered_data = filter_column_data_by_sheet(df)
    
    print(f"Found metadata for {len(filtered_data)} columns")
    print(f"Metrics: {', '.join(filtered_data.keys())}\n")
    
    if len(filtered_data) == 0:
        print("⚠️  Warning: No matching metrics found. Skipping field relations generation.")
        return
    
    # Generate field relations
    main(filtered_column_data=filtered_data, data_name=data_name)


def generate_for_all_sheets(file_path: str):
    """
    Generate field relations for all sheets in an Excel file.
    
    Args:
        file_path: Path to the Excel file
    """
    # Get all sheet names
    xls = pd.ExcelFile(file_path)
    sheet_names = xls.sheet_names
    
    print(f"\nFound {len(sheet_names)} sheets in {file_path}")
    print(f"Sheets: {', '.join(sheet_names)}\n")
    
    # Generate for each sheet
    for sheet_name in sheet_names:
        # Use actual sheet name, replace spaces with underscores for filename
        data_name = sheet_name.replace(" ", "_")
        generate_for_sheet(file_path, sheet_name, data_name)


if __name__ == "__main__":
    # Generate field relations for a single sheet
    print("\n" + "="*80)
    print("GENERATING FIELD RELATIONS FOR SINGLE SHEET")
    print("="*80)
    
    file_path = "data/mockup_data_all.xlsx"
    sheet_name = "Data_3"
    data_name = sheet_name.replace(" ", "_")
    
    generate_for_sheet(file_path, sheet_name, data_name)
    
    print("\n" + "="*80)
    print("COMPLETED: Field relations generated")
    print("="*80)
    
    # Example: Generate for all sheets (uncomment to use)
    # print("\n" + "="*80)
    # print("GENERATING FIELD RELATIONS FOR ALL SHEETS")
    # print("="*80)
    # generate_for_all_sheets(file_path)
