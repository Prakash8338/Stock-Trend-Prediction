import React, { useState } from 'react'
import { pptService } from '../services/pptService'
import '../styles/GenerationControls.css'

interface Issuer {
  id: number
  name: string
  code: string
}

interface GenerationControlsProps {
  selectedIssuerId: number | null
  onPdfGenerated: (pdfUrl: string) => void
  onAllIssuersGenerated: (issuersData: any[]) => void
  onAIGeneration: (slideImages: string[], insights: Record<string, string[]>, issuerId: number, issuerName?: string, tokenCostInfo?: any, timingInfo?: any) => void
  hasPPTData: (issuerId: number) => boolean
  getPPTData: (issuerId: number) => any
  allIssuersGenerated: boolean
}

export const GenerationControls: React.FC<GenerationControlsProps> = ({
  selectedIssuerId,
  onPdfGenerated,
  onAllIssuersGenerated,
  onAIGeneration,
  hasPPTData,
  getPPTData,
  allIssuersGenerated,
}) => {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleGenerateAll = async () => {
    // Check if all issuers are already generated
    if (allIssuersGenerated) {
      return
    }
    
    try {
      setLoading(true)
      setError(null)
      const response = await pptService.generateAllIssuers()
      onAllIssuersGenerated(response.issuers_data)
    } catch (err) {
      setError('Failed to generate report for all issuers')
      console.error(err)
    } finally {
      setLoading(false)
    }
  }



  const handleDownloadPptx = async () => {
    if (selectedIssuerId === null) {
      setError('Please select an issuer first')
      return
    }

    try {
      setLoading(true)
      setError(null)
      await pptService.downloadPptx(selectedIssuerId)
    } catch (err) {
      setError(`Failed to download PowerPoint for issuer ${selectedIssuerId}`)
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const handleDownloadDefault = async () => {
    try {
      setLoading(true)
      setError(null)
      await pptService.downloadDefaultPptx()
    } catch (err) {
      setError('Failed to download default PowerPoint')
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const handleDownloadAllPptx = async () => {
    try {
      setLoading(true)
      setError(null)
      await pptService.downloadAllPptx()
    } catch (err) {
      setError('Failed to download all PowerPoint files')
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const handleGenerateWithAI = async () => {
    if (selectedIssuerId === null) {
      setError('Please select an issuer first')
      return
    }

    try {
      setLoading(true)
      setError(null)
      
      // Check if PPT data already exists in context
      if (hasPPTData(selectedIssuerId)) {
        const pptData = getPPTData(selectedIssuerId)
        if (pptData) {
          // Load from context instead of generating new
          onAIGeneration(pptData.slideImages, pptData.insights, selectedIssuerId, pptData.issuerName, pptData.tokenCostInfo, pptData.timingInfo)
          setLoading(false)
          return
        }
      }
      
      // Generate new PPT if not in context
      const response = await pptService.generateWithAI(selectedIssuerId)
      onAIGeneration(response.slide_images, response.insights, selectedIssuerId, response.issuer_name, response.token_cost_info, response.timing_info)
    } catch (err) {
      setError(`Failed to generate AI report for issuer ${selectedIssuerId}`)
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="generation-controls">
      <h3>Generate Report</h3>
      <div className="button-group">
        <button
          className="btn btn-primary"
          onClick={handleGenerateAll}
          disabled={loading || selectedIssuerId !== null}
        >
          {loading ? 'Generating...' : 'Generate for All Issuers'}
        </button>
        <button
          className="btn btn-ai"
          onClick={handleGenerateWithAI}
          disabled={loading || selectedIssuerId === null}
        >
          {loading ? 'Generating...' : 'Generate for Selected Issuer'}
        </button>
        <button
          className="btn btn-download"
          onClick={handleDownloadPptx}
          disabled={loading || selectedIssuerId === null || !hasPPTData(selectedIssuerId)}
        >
          {loading ? 'Downloading...' : 'Download Selected PowerPoint'}
        </button>
        <button
          className="btn btn-primary"
          onClick={handleDownloadAllPptx}
          disabled={loading || !allIssuersGenerated}
        >
          {loading ? 'Downloading...' : 'Download All PowerPoints (ZIP)'}
        </button>
        <button
          className="btn btn-default"
          onClick={handleDownloadDefault}
          disabled={loading}
        >
          {loading ? 'Downloading...' : 'Download Default Template'}
        </button>
      </div>
      {error && <div className="error-message">{error}</div>}
    </div>
  )
}
