import React, { useState, useEffect } from 'react'
import { feedbackService } from '../services/feedbackService'
import { pptService } from '../services/pptService'
import '../styles/SlideViewer.css'

interface SlideViewerProps {
  slideImages: string[]
  insights: Record<string, string[]>
  issuerId: number
  feedback: Record<number, number>
  onSlideRegenerated: (slideNum: number, newImages: string[], newInsights: string[], tokenCostInfo?: any, timingInfo?: any) => void
  onFeedbackUpdate: (slideIndex: number, score: number) => void
}

const SlideViewer: React.FC<SlideViewerProps> = ({ 
  slideImages, 
  insights, 
  issuerId,
  feedback,
  onSlideRegenerated,
  onFeedbackUpdate
}) => {
  const [regenerating, setRegenerating] = useState<Record<number, boolean>>({})
  const [imageKeys, setImageKeys] = useState<Record<number, number>>({})

  // Log when props change
  useEffect(() => {
    console.log('SlideViewer props changed:', {
      issuerId,
      slideImagesCount: slideImages.length,
      slideImagesUrls: slideImages,
      insightKeys: Object.keys(insights),
      feedbackKeys: Object.keys(feedback)
    })
  }, [slideImages, insights, issuerId, feedback])

  // Track when slideImages change to force image reload
  useEffect(() => {
    console.log('SlideViewer: slideImages changed', {
      count: slideImages.length,
      urls: slideImages,
      insightKeys: Object.keys(insights)
    })
    // Update image keys to force re-render of img elements
    const newKeys: Record<number, number> = {}
    const timestamp = Date.now()
    slideImages.forEach((_, index) => {
      newKeys[index] = timestamp + index
    })
    setImageKeys(newKeys)
  }, [slideImages, insights])

  const handleFeedback = async (slideIndex: number, score: number) => {
    // Skip feedback for first slide (title slide)
    if (slideIndex === 0) return

    const slideKey = `slide${slideIndex}`
    // Get all insights - send the full array as-is (matching Streamlit behavior)
    const insightsList = insights[slideKey] || []

    try {
      // Submit feedback - send the entire list including title
      await feedbackService.submitFeedback({
        slide_key: slideKey,
        insight: insightsList,  // Send as array
        score,
      })

      // Update feedback state in parent
      onFeedbackUpdate(slideIndex, score)

      // If thumbs down, regenerate the slide
      if (score === 0) {
        setRegenerating(prev => ({ ...prev, [slideIndex]: true }))
        
        try {
          // Convert array index to slide number (index 1 -> slide 2, index 2 -> slide 3, etc.)
          const slideNumber = slideIndex + 1
          console.log(`Regenerating slide at index ${slideIndex}, slideNumber: ${slideNumber}`)
          
          const result = await pptService.regenerateSlide(issuerId, slideNumber)
          console.log('Regeneration result:', result)
          
          // Notify parent component with token and timing info
          // Use slide_num (PPT position) not data_slide_num for the insights key
          // Backend returns slide_num which is the PPT position (1-based)
          onSlideRegenerated(result.slide_num, result.slide_images, result.new_insights, result.token_cost_info, result.timing_info)
          
        } catch (error) {
          console.error('Error regenerating slide:', error)
        } finally {
          setRegenerating(prev => ({ ...prev, [slideIndex]: false }))
        }
      }
    } catch (error) {
      console.error('Error handling feedback:', error)
      setRegenerating(prev => ({ ...prev, [slideIndex]: false }))
    }
  }

  return (
    <div className="slide-viewer">
      {slideImages.map((image, index) => {
        // Add extra cache buster to the image URL if it doesn't already have one
        const imageUrlWithCache = image.includes('?') 
          ? `${image}&cb=${imageKeys[index] || Date.now()}` 
          : `${image}?cb=${imageKeys[index] || Date.now()}`
        
        return (
          <div key={`slide-${index}-${imageKeys[index] || index}`} className="slide-container">
            <img 
              src={imageUrlWithCache} 
              alt={`Slide ${index + 1}`} 
              className="slide-image"
              key={`img-${imageKeys[index] || index}`}
            />
            
            {index > 0 && (
              <div className="feedback-buttons">
                <button
                  className={`feedback-btn thumbs-up ${feedback[index] === 1 ? 'active' : ''}`}
                  onClick={() => handleFeedback(index, 1)}
                  disabled={regenerating[index]}
                  title="Mark this slide as helpful"
                >
                  👍
                </button>
                <button
                  className={`feedback-btn thumbs-down ${feedback[index] === 0 ? 'active' : ''}`}
                  onClick={() => handleFeedback(index, 0)}
                  disabled={regenerating[index]}
                  title="Regenerate this slide"
                >
                  👎
                </button>
                {regenerating[index] && (
                  <span className="regenerating-text">Regenerating...</span>
                )}
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}

export default SlideViewer
