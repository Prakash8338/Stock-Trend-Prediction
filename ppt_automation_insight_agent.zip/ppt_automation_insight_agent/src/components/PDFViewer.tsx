import React, { useEffect, useState } from 'react'
import { Document, Page, pdfjs } from 'react-pdf'
import 'react-pdf/dist/esm/Page/AnnotationLayer.css'
import 'react-pdf/dist/esm/Page/TextLayer.css'
import '../styles/PDFViewer.css'
import { feedbackService } from '../services/feedbackService'
import { pptService } from '../services/pptService'

// Configure PDF.js worker
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`

interface PDFViewerProps {
  pdfUrl: string | null
  issuerId?: number
  insights?: Record<string, string[]>
  onSlideRegenerate?: (slideNum: number, newInsights: string[], slideImages: string[], tokenCostInfo?: any, timingInfo?: any) => void
}

export const PDFViewer: React.FC<PDFViewerProps> = ({ pdfUrl, issuerId, insights = {}, onSlideRegenerate }) => {
  const [numPages, setNumPages] = useState<number | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [feedback, setFeedback] = useState<Record<number, number>>({})
  const [submittingFeedback, setSubmittingFeedback] = useState<Record<number, boolean>>({})

  const onDocumentLoadSuccess = ({ numPages }: { numPages: number }) => {
    setNumPages(numPages)
    setError(null)
  }

  const onDocumentLoadError = (error: Error) => {
    console.error('Error loading PDF:', error)
    setError('Failed to load PDF')
  }

  const handleFeedback = async (pageNumber: number, score: number) => {
    if (!issuerId) {
      console.warn('Cannot submit feedback: No issuer ID provided')
      return
    }

    const slideKey = `slide${pageNumber}`
    const slideInsights = insights[slideKey] || []

    // Check if already submitted the same feedback
    if (feedback[pageNumber] === score) {
      return
    }

    setSubmittingFeedback(prev => ({ ...prev, [pageNumber]: true }))

    try {
      await feedbackService.submitFeedback({
        slide_key: slideKey,
        insight: slideInsights,
        score: score
      })

      // Update local feedback state
      setFeedback(prev => ({ ...prev, [pageNumber]: score }))
      console.log(`Feedback submitted for ${slideKey}: ${score === 1 ? 'thumbs up' : 'thumbs down'}`)

      // If thumbs down (score === 0), regenerate the slide
      if (score === 0) {
        console.log(`Regenerating slide ${pageNumber} due to thumbs down...`)
        try {
          const regenerateResult = await pptService.regenerateSlide(issuerId, pageNumber)
          console.log('Slide regenerated successfully:', regenerateResult)
          
          // Call the callback to update the parent component with new data
          // Use data_slide_num for the insights key to match backend format (slide1, slide2, etc.)
          if (onSlideRegenerate) {
            onSlideRegenerate(
              regenerateResult.data_slide_num, 
              regenerateResult.new_insights, 
              regenerateResult.slide_images,
              regenerateResult.token_cost_info,
              regenerateResult.timing_info
            )
          }
          
          // Show success message
          alert(`Slide ${pageNumber} has been regenerated successfully!`)
        } catch (regenerateError) {
          console.error('Error regenerating slide:', regenerateError)
          alert('Feedback submitted, but failed to regenerate slide. Please try again.')
        }
      }
    } catch (error) {
      console.error('Error submitting feedback:', error)
      alert('Failed to submit feedback. Please try again.')
    } finally {
      setSubmittingFeedback(prev => ({ ...prev, [pageNumber]: false }))
    }
  }

  if (!pdfUrl) {
    return (
      <div className="pdf-viewer empty">
        <p>No PDF loaded. Generate a report to view it here.</p>
      </div>
    )
  }

  return (
    <div className="pdf-viewer">
      {error && (
        <div className="pdf-error">
          <p>{error}</p>
        </div>
      )}
      <div className="pdf-document-slider">
        <Document 
          file={pdfUrl} 
          onLoadSuccess={onDocumentLoadSuccess}
          onLoadError={onDocumentLoadError}
          loading={<div className="pdf-loading">Loading PDF...</div>}
        >
          {numPages && Array.from(new Array(numPages), (el, index) => {
            const pageNumber = index + 1
            const currentFeedback = feedback[pageNumber]
            const isSubmitting = submittingFeedback[pageNumber]
            
            return (
              <div key={`page_${pageNumber}`} className="pdf-page-container">
                <Page 
                  pageNumber={pageNumber}
                  renderTextLayer={false}
                  renderAnnotationLayer={false}
                />
                {pageNumber > 1 && (
                  <div className="pdf-feedback-buttons">
                    <button
                      className={`pdf-feedback-btn thumbs-up ${currentFeedback === 1 ? 'active' : ''}`}
                      onClick={() => handleFeedback(pageNumber, 1)}
                      disabled={isSubmitting}
                      title="Thumbs Up"
                    >
                      👍
                    </button>
                    <button
                      className={`pdf-feedback-btn thumbs-down ${currentFeedback === 0 ? 'active' : ''}`}
                      onClick={() => handleFeedback(pageNumber, 0)}
                      disabled={isSubmitting}
                      title="Thumbs Down"
                    >
                      👎
                    </button>
                  </div>
                )}
              </div>
            )
          })}
        </Document>
      </div>
    </div>
  )
}
