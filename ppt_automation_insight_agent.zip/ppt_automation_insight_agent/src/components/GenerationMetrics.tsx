import React from 'react'
import '../styles/GenerationMetrics.css'

interface GenerationMetricsProps {
  tokenCostInfo?: any
  timingInfo?: any
  issuerName?: string
}

export const GenerationMetrics: React.FC<GenerationMetricsProps> = ({
  tokenCostInfo,
  timingInfo,
  issuerName
}) => {
  if (!tokenCostInfo && !timingInfo) {
    return null
  }

  const formatTime = (seconds: number): string => {
    if (seconds < 60) {
      return `${seconds.toFixed(2)}s`
    }
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes}m ${remainingSeconds.toFixed(0)}s`
  }

  const formatCurrency = (amount: number): string => {
    return `$${amount.toFixed(4)}`
  }

  const formatNumber = (num: number): string => {
    return num.toLocaleString()
  }

  return (
    <div className="generation-metrics">
      <div className="metrics-header">
        <h3>Generation Metrics {issuerName && `for ${issuerName}`}</h3>
        {tokenCostInfo?.is_estimated && (
          <div className="estimated-badge">
            <span title="Token counts are estimated based on text length">⚠️ ESTIMATED</span>
          </div>
        )}
      </div>

      <div className="metrics-grid">
        {/* Timing Information */}
        {timingInfo && (
          <div className="metric-card timing-card">
            <div className="metric-icon">⏱️</div>
            <div className="metric-content">
              <h4>Generation Time</h4>
              <div className="metric-value">{formatTime(timingInfo.total_time)}</div>
              <div className="metric-details">
                {timingInfo.slide_timings && Object.entries(timingInfo.slide_timings).map(([slide, time]: [string, any]) => (
                  <div key={slide} className="slide-metric">
                    <span>Slide {slide}:</span>
                    <span>{formatTime(time)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Token Usage Information */}
        {tokenCostInfo && (
          <div className="metric-card token-card">
            <div className="metric-icon">🔤</div>
            <div className="metric-content">
              <h4>Token Usage</h4>
              <div className="metric-value">{formatNumber(tokenCostInfo.total_tokens)}</div>
              <div className="metric-breakdown">
                <div className="breakdown-item">
                  <span>Input:</span>
                  <span>{formatNumber(tokenCostInfo.total_prompt_tokens)}</span>
                </div>
                <div className="breakdown-item">
                  <span>Output:</span>
                  <span>{formatNumber(tokenCostInfo.total_completion_tokens)}</span>
                </div>
              </div>
              {tokenCostInfo.slide_token_info && (
                <div className="metric-details">
                  {Object.entries(tokenCostInfo.slide_token_info).map(([slide, info]: [string, any]) => (
                    <div key={slide} className="slide-metric">
                      <span>Slide {slide}:</span>
                      <span>{formatNumber(info.total_tokens)} tokens</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Cost Information */}
        {tokenCostInfo && (
          <div className="metric-card cost-card">
            <div className="metric-icon">💰</div>
            <div className="metric-content">
              <h4>Estimated Cost</h4>
              <div className="metric-value">{formatCurrency(tokenCostInfo.total_cost)}</div>
              <div className="metric-subtitle">Model: {tokenCostInfo.model || 'gpt-4o-mini'}</div>
              {tokenCostInfo.slide_costs && (
                <div className="metric-details">
                  {Object.entries(tokenCostInfo.slide_costs).map(([slide, cost]: [string, any]) => (
                    <div key={slide} className="slide-metric">
                      <span>Slide {slide}:</span>
                      <span>{formatCurrency(cost)}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Summary Stats */}
      {tokenCostInfo && timingInfo && (
        <div className="metrics-summary">
          <div className="summary-item">
            <span className="summary-label">Avg. time per slide:</span>
            <span className="summary-value">
              {formatTime(timingInfo.total_time / Object.keys(timingInfo.slide_timings || {}).length)}
            </span>
          </div>
          <div className="summary-item">
            <span className="summary-label">Avg. tokens per slide:</span>
            <span className="summary-value">
              {formatNumber(Math.round(tokenCostInfo.total_tokens / Object.keys(tokenCostInfo.slide_token_info || {}).length))}
            </span>
          </div>
          <div className="summary-item">
            <span className="summary-label">Avg. cost per slide:</span>
            <span className="summary-value">
              {formatCurrency(tokenCostInfo.total_cost / Object.keys(tokenCostInfo.slide_costs || {}).length)}
            </span>
          </div>
        </div>
      )}
    </div>
  )
}
