import apiClient from './apiClient'

export interface FeedbackSubmission {
  slide_key: string
  insight: string | string[] // Can be string or array to match backend
  score: number // 1 for thumbs up, 0 for thumbs down
}

export interface FeedbackResponse {
  message: string
  slide_key: string
  score: number
}

export interface FeedbackData {
  slide_key: string
  feedback: Array<{
    Slide: string
    Insight: string
    Score: number
  }>
}

export const feedbackService = {
  // Submit feedback for a slide
  async submitFeedback(data: FeedbackSubmission): Promise<FeedbackResponse> {
    try {
      const response = await apiClient.post('/feedback/submit', data)
      return response.data
    } catch (error) {
      console.error('Error submitting feedback:', error)
      throw error
    }
  },

  // Get feedback for a specific slide
  async getFeedback(slideKey: string): Promise<FeedbackData> {
    try {
      const response = await apiClient.get(`/feedback/get/${slideKey}`)
      return response.data
    } catch (error) {
      console.error(`Error getting feedback for ${slideKey}:`, error)
      throw error
    }
  },
}
